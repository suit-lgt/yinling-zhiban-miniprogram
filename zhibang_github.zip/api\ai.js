/**
 * AI对话服务 - 支持多个国内大模型
 * 智谱GLM-4（默认）、阿里通义千问、百度文心一言
 */

import { storage } from '../common/rules/state-management'

const STORAGE_KEY = 'ai_conversation_history'
const MAX_HISTORY = 20

class AIService {
  constructor() {
    this.currentModel = 'zhipu' // zhipu | qwen | wenxin
    this.apiKeys = {
      zhipu: '', // 智谱API Key
      qwen: '',  // 阿里API Key
      wenxin: '' // 百度API Key
    }
    this.baseUrls = {
      zhipu: 'https://open.bigmodel.cn/api/paas/v4',
      qwen: 'https://dashscope.aliyuncs.com/api/v1',
      wenxin: 'https://aip.baidubce.com/rpc/2.0/ai_custom/v1'
    }
  }

  setApiKey(model, key) {
    this.apiKeys[model] = key
  }

  setModel(model) {
    this.currentModel = model
  }

  getHistory() {
    try {
      return JSON.parse(storage.get(STORAGE_KEY) || '[]')
    } catch {
      return []
    }
  }

  saveHistory(history) {
    const trimmed = history.slice(-MAX_HISTORY)
    storage.set(STORAGE_KEY, JSON.stringify(trimmed))
  }

  clearHistory() {
    storage.set(STORAGE_KEY, '[]')
  }

  async chat(message, systemPrompt = null) {
    const history = this.getHistory()
    
    const messages = []
    
    if (systemPrompt) {
      messages.push({ role: 'system', content: systemPrompt })
    } else {
      messages.push({
        role: 'system',
        content: `你是一位专门为老年人服务的智能助手。请用简单、温暖、易懂的语言回答问题。
        - 回答要简短，每段不超过50字
        - 使用常用词汇，避免专业术语
        - 适当使用表情符号让对话更生动
        - 回答要实用，给出具体建议
        - 语音朗读时语言要自然流畅`
      })
    }
    
    history.forEach(msg => {
      messages.push(msg)
    })
    
    messages.push({ role: 'user', content: message })

    let response
    
    switch (this.currentModel) {
      case 'qwen':
        response = await this.callQwen(messages)
        break
      case 'wenxin':
        response = await this.callWenxin(messages)
        break
      case 'zhipu':
      default:
        response = await this.callZhipu(messages)
    }

    history.push({ role: 'user', content: message })
    history.push({ role: 'assistant', content: response })
    this.saveHistory(history)

    return response
  }

  async callZhipu(messages) {
    const apiKey = this.apiKeys.zhipu
    
    if (!apiKey) {
      return this.getMockResponse(messages)
    }

    try {
      const response = await fetch(`${this.baseUrls.zhipu}/chat/completions`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${apiKey}`
        },
        body: JSON.stringify({
          model: 'glm-4-air',
          messages: messages,
          temperature: 0.7,
          max_tokens: 512
        })
      })

      if (!response.ok) {
        throw new Error(`API错误: ${response.status}`)
      }

      const data = await response.json()
      return data.choices[0].message.content
    } catch (error) {
      console.error('智谱API调用失败:', error)
      return this.getMockResponse(messages)
    }
  }

  async callQwen(messages) {
    const apiKey = this.apiKeys.qwen
    
    if (!apiKey) {
      return this.getMockResponse(messages)
    }

    try {
      const response = await fetch(`${this.baseUrls.qwen}/aigc/text-generation/generation`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${apiKey}`
        },
        body: JSON.stringify({
          model: 'qwen-turbo',
          input: { messages },
          parameters: {
            temperature: 0.7,
            max_tokens: 512,
            result_format: 'message'
          }
        })
      })

      if (!response.ok) {
        throw new Error(`API错误: ${response.status}`)
      }

      const data = await response.json()
      return data.output.choices[0].message.content
    } catch (error) {
      console.error('通义API调用失败:', error)
      return this.getMockResponse(messages)
    }
  }

  async callWenxin(messages) {
    const apiKey = this.apiKeys.wenxin
    
    if (!apiKey) {
      return this.getMockResponse(messages)
    }

    try {
      const response = await fetch(`${this.baseUrls.wenxin}/wenxin_ernie-lite-v1/chat_completion?access_token=${apiKey}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          messages
        })
      })

      if (!response.ok) {
        throw new Error(`API错误: ${response.status}`)
      }

      const data = await response.json()
      return data.result
    } catch (error) {
      console.error('文心API调用失败:', error)
      return this.getMockResponse(messages)
    }
  }

  getMockResponse(messages) {
    const lastMessage = messages[messages.length - 1].content.toLowerCase()
    
    const mockResponses = {
      default: '抱歉，我现在正在学习更多知识。请稍后再问我这个问题。您也可以尝试拨打官方客服获取帮助。',
      greeting: '您好！我是银龄智伴小助手，很高兴为您服务！请问有什么可以帮您的？',
      weather: '今天天气很不错呢！适合出去散步锻炼身体。记得按时喝水，保持好心情！',
      health: '保持健康最重要的是规律作息、均衡饮食、适度运动。如果身体有不适，建议及时就医检查。',
      medicine: '服药要按时按量，不要自行增减药量。如有疑问，可以咨询医生或药师。',
      help: '我可以帮您：查询天气、设置提醒、健康咨询、聊天陪伴等。您直接说出您的需求就行。'
    }

    if (lastMessage.includes('你好') || lastMessage.includes('您好') || lastMessage.includes('hello')) {
      return mockResponses.greeting
    } else if (lastMessage.includes('天气')) {
      return mockResponses.weather
    } else if (lastMessage.includes('健康') || lastMessage.includes('血压') || lastMessage.includes('血糖')) {
      return mockResponses.health
    } else if (lastMessage.includes('药')) {
      return mockResponses.medicine
    } else if (lastMessage.includes('帮助') || lastMessage.includes('能做什么')) {
      return mockResponses.help
    }

    return `您说"${lastMessage}"，我理解了。\n\n如果您有其他问题，可以继续问我，我会尽力帮助您！`
  }
}

export const aiService = new AIService()

export default aiService
