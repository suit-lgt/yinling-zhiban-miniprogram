/**
 * 健康数据相关 API
 */

import http from '../utils/http'
import { storage, STORAGE_KEYS } from '../common/rules/state-management'

export const healthAPI = {
  /**
   * 获取健康数据
   * @param {string} type - bloodPressure/bloodSugar/heartRate
   * @param {number} days - 获取天数
   */
  getHealthData(type, days = 7) {
    const cacheKey = `health_${type}_${days}`
    const cached = storage.get(cacheKey)
    
    if (cached) {
      return Promise.resolve(cached)
    }
    
    return http.get(`/health/${type}`, { days }).then(data => {
      storage.set(cacheKey, data)
      return data
    })
  },
  
  /**
   * 记录健康数据
   * @param {Object} data - { type, value, date, time, remark }
   */
  recordHealthData(data) {
    return http.post('/health/record', data).then(res => {
      const healthData = storage.get(STORAGE_KEYS.HEALTH_DATA, {})
      
      if (!healthData[data.type]) {
        healthData[data.type] = []
      }
      
      healthData[data.type].unshift({
        ...data,
        id: 'health_' + Date.now(),
        createTime: Date.now()
      })
      
      storage.set(STORAGE_KEYS.HEALTH_DATA, healthData)
      
      const cacheKey = `health_${data.type}_7`
      storage.remove(cacheKey)
      
      return res
    })
  },
  
  /**
   * 获取健康统计
   */
  getHealthStats() {
    const healthData = storage.get(STORAGE_KEYS.HEALTH_DATA, {})
    
    const stats = {
      bloodPressure: {
        latest: null,
        avg: null,
        trend: []
      },
      bloodSugar: {
        latest: null,
        avg: null,
        trend: []
      },
      heartRate: {
        latest: null,
        avg: null,
        trend: []
      }
    }
    
    Object.keys(healthData).forEach(type => {
      const data = healthData[type] || []
      if (data.length > 0) {
        stats[type].latest = data[0]
        stats[type].trend = data.slice(0, 7)
        
        if (data.length > 1) {
          const sum = data.reduce((acc, item) => acc + parseFloat(item.value), 0)
          stats[type].avg = (sum / data.length).toFixed(1)
        }
      }
    })
    
    return stats
  },
  
  /**
   * 删除健康记录
   * @param {string} id - 记录ID
   * @param {string} type - 数据类型
   */
  deleteRecord(id, type) {
    const healthData = storage.get(STORAGE_KEYS.HEALTH_DATA, {})
    
    if (healthData[type]) {
      healthData[type] = healthData[type].filter(item => item.id !== id)
      storage.set(STORAGE_KEYS.HEALTH_DATA, healthData)
    }
    
    return Promise.resolve({ success: true })
  }
}

export default healthAPI
