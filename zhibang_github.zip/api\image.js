import http from '../utils/http'

export const imageAPI = {
  uploadImage(filePath, options = {}) {
    return new Promise((resolve, reject) => {
      uni.uploadFile({
        url: options.uploadUrl || http.baseURL + '/api/upload',
        filePath: filePath,
        name: options.name || 'image',
        formData: options.formData || {},
        success: (res) => {
          if (res.statusCode === 200) {
            try {
              const data = JSON.parse(res.data)
              resolve(data)
            } catch (e) {
              resolve(res.data)
            }
          } else {
            reject({ errMsg: '上传失败', statusCode: res.statusCode })
          }
        },
        fail: (err) => {
          reject(err)
        }
      })
    })
  },
  
  getImageInfo(src) {
    return new Promise((resolve, reject) => {
      uni.getImageInfo({
        src: src,
        success: (res) => {
          resolve(res)
        },
        fail: (err) => {
          reject(err)
        }
      })
    })
  },
  
  compressImage(src, quality = 80) {
    return new Promise((resolve, reject) => {
      uni.compressImage({
        src: src,
        quality: quality,
        success: (res) => {
          resolve(res)
        },
        fail: (err) => {
          reject(err)
        }
      })
    })
  },
  
  saveImageToPhotosAlbum(filePath) {
    return new Promise((resolve, reject) => {
      uni.saveImageToPhotosAlbum({
        filePath: filePath,
        success: (res) => {
          resolve(res)
        },
        fail: (err) => {
          reject(err)
        }
      })
    })
  }
}

export default imageAPI