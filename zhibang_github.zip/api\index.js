/**
 * API 统一导出
 */

import userAPI from './user'
import weatherAPI from './weather'
import speechAPI from './speech'
import healthAPI from './health'
import memoAPI from './memo'
import aiService from './ai'
import imageAPI from './image'

export {
  userAPI,
  weatherAPI,
  speechAPI,
  healthAPI,
  memoAPI,
  aiService,
  imageAPI
}

export default {
  user: userAPI,
  weather: weatherAPI,
  speech: speechAPI,
  health: healthAPI,
  memo: memoAPI,
  ai: aiService,
  image: imageAPI
}
