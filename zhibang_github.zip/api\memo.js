/**
 * 备忘录相关 API
 */

import http from '../utils/http'
import { storage, STORAGE_KEYS } from '../common/rules/state-management'
import { stringUtils } from '../common/utils/index'

export const memoAPI = {
  /**
   * 获取备忘录列表
   * @param {string} category - 分类筛选
   */
  getMemoList(category = 'all') {
    const memoList = storage.get(STORAGE_KEYS.MEMO_LIST, [])
    
    if (category === 'all') {
      return Promise.resolve(memoList)
    }
    
    return Promise.resolve(memoList.filter(m => m.category === category))
  },
  
  /**
   * 获取今日备忘录
   */
  getTodayMemos() {
    const memoList = storage.get(STORAGE_KEYS.MEMO_LIST, [])
    const today = new Date().toISOString().split('T')[0]
    
    return Promise.resolve(
      memoList.filter(m => m.reminder_date === today)
    )
  },
  
  /**
   * 获取待办备忘录
   */
  getPendingMemos() {
    const memoList = storage.get(STORAGE_KEYS.MEMO_LIST, [])
    const today = new Date().toISOString().split('T')[0]
    
    return Promise.resolve(
      memoList.filter(m => !m.completed && m.reminder_date <= today)
    )
  },
  
  /**
   * 获取某日期的备忘录
   * @param {string} date - 日期 YYYY-MM-DD
   */
  getMemosByDate(date) {
    const memoList = storage.get(STORAGE_KEYS.MEMO_LIST, [])
    return Promise.resolve(
      memoList.filter(m => m.reminder_date === date)
    )
  },
  
  /**
   * 添加备忘录
   * @param {Object} memo - 备忘录对象
   */
  addMemo(memo) {
    const memoList = storage.get(STORAGE_KEYS.MEMO_LIST, [])
    
    const newMemo = {
      ...memo,
      _id: stringUtils.generateId(),
      completed: false,
      create_time: Date.now(),
      update_time: Date.now()
    }
    
    memoList.unshift(newMemo)
    storage.set(STORAGE_KEYS.MEMO_LIST, memoList)
    
    return Promise.resolve(newMemo)
  },
  
  /**
   * 更新备忘录
   * @param {string} id - 备忘录ID
   * @param {Object} data - 更新的数据
   */
  updateMemo(id, data) {
    const memoList = storage.get(STORAGE_KEYS.MEMO_LIST, [])
    const index = memoList.findIndex(m => m._id === id)
    
    if (index > -1) {
      memoList[index] = {
        ...memoList[index],
        ...data,
        update_time: Date.now()
      }
      storage.set(STORAGE_KEYS.MEMO_LIST, memoList)
      return Promise.resolve(memoList[index])
    }
    
    return Promise.reject(new Error('备忘录不存在'))
  },
  
  /**
   * 删除备忘录
   * @param {string} id - 备忘录ID
   */
  deleteMemo(id) {
    const memoList = storage.get(STORAGE_KEYS.MEMO_LIST, [])
    const newList = memoList.filter(m => m._id !== id)
    storage.set(STORAGE_KEYS.MEMO_LIST, newList)
    return Promise.resolve({ success: true })
  },
  
  /**
   * 切换备忘录完成状态
   * @param {string} id - 备忘录ID
   */
  toggleComplete(id) {
    const memoList = storage.get(STORAGE_KEYS.MEMO_LIST, [])
    const index = memoList.findIndex(m => m._id === id)
    
    if (index > -1) {
      memoList[index].completed = !memoList[index].completed
      memoList[index].update_time = Date.now()
      storage.set(STORAGE_KEYS.MEMO_LIST, memoList)
      return Promise.resolve(memoList[index])
    }
    
    return Promise.reject(new Error('备忘录不存在'))
  },
  
  /**
   * 搜索备忘录
   * @param {string} keyword - 关键词
   */
  searchMemos(keyword) {
    const memoList = storage.get(STORAGE_KEYS.MEMO_LIST, [])
    const lowerKeyword = keyword.toLowerCase()
    
    return Promise.resolve(
      memoList.filter(m => 
        m.title.toLowerCase().includes(lowerKeyword) ||
        m.content.toLowerCase().includes(lowerKeyword)
      )
    )
  },
  
  /**
   * 获取备忘录统计
   */
  getMemoStats() {
    const memoList = storage.get(STORAGE_KEYS.MEMO_LIST, [])
    const today = new Date().toISOString().split('T')[0]
    
    const stats = {
      total: memoList.length,
      completed: memoList.filter(m => m.completed).length,
      pending: memoList.filter(m => !m.completed).length,
      today: memoList.filter(m => m.reminder_date === today).length,
      categories: {}
    }
    
    memoList.forEach(m => {
      if (!stats.categories[m.category]) {
        stats.categories[m.category] = 0
      }
      stats.categories[m.category]++
    })
    
    return Promise.resolve(stats)
  }
}

export default memoAPI
