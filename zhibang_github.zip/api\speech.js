/**
 * 语音相关 API
 * 使用 js-audio-recorder 进行录音
 */

import http from '../utils/http'

export const speechAPI = {
  /**
   * 语音识别
   * @param {string} filePath - 录音文件路径
   */
  recognize(filePath) {
    return new Promise((resolve, reject) => {
      uni.uploadFile({
        url: 'https://api.example.com/speech/recognize',
        filePath: filePath,
        name: 'file',
        success: (res) => {
          if (res.statusCode === 200) {
            const data = JSON.parse(res.data)
            resolve(data)
          } else {
            reject({ message: '语音识别失败' })
          }
        },
        fail: (err) => {
          reject(err)
        }
      })
    })
  },

  /**
   * 语音合成
   * @param {string} text - 要转换的文本
   * @param {string} voice - 发音人
   */
  synthesize(text, voice = 'xiaoyan') {
    return http.post('/speech/synthesize', {
      text,
      voice,
      format: 'mp3'
    })
  },

  /**
   * AI 智能问答
   * @param {string} question - 问题
   * @param {string} context - 对话上下文
   */
  chat(question, context = '') {
    return http.post('/qa/chat', {
      question,
      context
    })
  },

  /**
   * 获取常见问题列表
   */
  getCommonQuestions() {
    return http.get('/qa/common-questions')
  },

  /**
   * 获取问题分类
   */
  getQuestionCategories() {
    return http.get('/qa/categories')
  },

  /**
   * 搜索问题
   * @param {string} keyword - 关键词
   */
  searchQuestions(keyword) {
    return http.get('/qa/search', { keyword })
  }
}

export default speechAPI
