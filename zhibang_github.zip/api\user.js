/**
 * 用户相关 API
 */

import http from '../utils/http'

export const userAPI = {
  /**
   * 登录
   * @param {Object} data - { phone, password }
   */
  login(data) {
    return http.post('/user/login', data)
  },

  /**
   * 注册
   * @param {Object} data - { phone, password, code }
   */
  register(data) {
    return http.post('/user/register', data)
  },

  /**
   * 获取用户信息
   * @param {string} id - 用户ID
   */
  getUserInfo(id) {
    return http.get(`/user/${id}`)
  },

  /**
   * 更新用户信息
   * @param {Object} data - 用户信息
   */
  updateUserInfo(data) {
    return http.put('/user/info', data)
  },

  /**
   * 获取登录天数
   * @param {string} userId - 用户ID
   */
  getLoginDays(userId) {
    return http.get(`/user/${userId}/login-days`)
  },

  /**
   * 发送验证码
   * @param {string} phone - 手机号
   */
  sendCode(phone) {
    return http.post('/user/sms/send', { phone })
  },

  /**
   * 验证验证码
   * @param {string} phone - 手机号
   * @param {string} code - 验证码
   */
  verifyCode(phone, code) {
    return http.post('/user/sms/verify', { phone, code })
  },

  /**
   * 退出登录
   */
  logout() {
    return http.post('/user/logout')
  }
}

export default userAPI
