/**
 * 天气相关 API
 */

import { storage, STORAGE_KEYS } from '../common/rules/state-management'

export const weatherAPI = {
  /**
   * 获取当前位置信息
   */
  async getCityInfo() {
    return new Promise((resolve) => {
      if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
          async (position) => {
            const { latitude, longitude } = position.coords
            try {
              const data = await this.reverseGeocode(latitude, longitude)
              resolve(data)
            } catch (e) {
              resolve({ location: '北京', cityId: 1 })
            }
          },
          () => {
            resolve({ location: '北京', cityId: 1 })
          }
        )
      } else {
        resolve({ location: '北京', cityId: 1 })
      }
    })
  },

  async reverseGeocode(lat, lng) {
    return { location: '北京', cityId: 1 }
  },

  /**
   * 获取当前天气
   * @param {string} city - 城市名称
   */
  async getWeatherNow(city = '北京') {
    const cached = this.getCachedWeather()
    if (cached && cached.now) {
      return cached.now
    }

    const mockData = this.getMockWeather()
    this.setCachedWeather({ now: mockData, forecast: [] })
    return mockData
  },

  /**
   * 获取天气预报
   * @param {string} city - 城市名称
   * @param {number} days - 天数
   */
  async getWeatherForecast(city = '北京', days = 7) {
    const cached = this.getCachedWeather()
    if (cached && cached.forecast) {
      return cached.forecast
    }

    const mockData = this.getMockForecast()
    this.setCachedWeather({ now: this.getMockWeather(), forecast: mockData })
    return mockData
  },

  getMockWeather() {
    const conditions = ['晴', '多云', '阴', '小雨', '晴']
    const condition = conditions[Math.floor(Math.random() * conditions.length)]
    const temp = Math.floor(Math.random() * 15) + 10

    return {
      temp,
      text: condition,
      humidity: Math.floor(Math.random() * 50) + 30,
      wind: Math.floor(Math.random() * 10) + 1,
      windDir: '北风',
      air: '良',
      airLevel: 2,
      updateTime: new Date().toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' })
    }
  },

  getMockForecast() {
    const days = []
    const conditions = ['晴', '多云', '阴', '小雨', '晴']
    const weekDays = ['周日', '周一', '周二', '周三', '周四', '周五', '周六']

    for (let i = 0; i < 7; i++) {
      const date = new Date()
      date.setDate(date.getDate() + i)
      
      days.push({
        date: `${date.getMonth() + 1}/${date.getDate()}`,
        week: weekDays[date.getDay()],
        tempMax: Math.floor(Math.random() * 10) + 20,
        tempMin: Math.floor(Math.random() * 10) + 5,
        text: conditions[Math.floor(Math.random() * conditions.length)],
        textNight: conditions[Math.floor(Math.random() * conditions.length)],
        wind: Math.floor(Math.random() * 8) + 1,
        windDir: '北风'
      })
    }

    return days
  },

  /**
   * 获取缓存的天气数据
   */
  getCachedWeather() {
    try {
      const cache = storage.get(STORAGE_KEYS.WEATHER_CACHE)
      if (cache) {
        const now = Date.now()
        if (now - cache.timestamp < STORAGE_KEYS.CACHE_EXPIRE) {
          return cache.data
        }
      }
    } catch (e) {
      console.log('获取天气缓存失败', e)
    }
    return null
  },

  /**
   * 缓存天气数据
   * @param {Object} data - 天气数据
   */
  setCachedWeather(data) {
    try {
      storage.set(STORAGE_KEYS.WEATHER_CACHE, {
        data,
        timestamp: Date.now()
      })
    } catch (e) {
      console.log('缓存天气数据失败', e)
    }
  }
}

export default weatherAPI
