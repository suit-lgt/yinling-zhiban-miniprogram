// app.js - 微信小程序入口文件
App({
  onLaunch() {
    console.log('App Launch')
    
    // 初始化云开发
    if (!wx.cloud) {
      console.error('请使用 2.2.3 或以上的基础库以使用云能力')
    } else {
      wx.cloud.init({
        env: 'cloud1-7gie265r077cfa4b', // 你的云开发环境ID
        traceUser: true
      })
      console.log('云开发初始化成功')
    }
  },
  onShow() {
    console.log('App Show')
  },
  onHide() {
    console.log('App Hide')
  },
  globalData: {
    userInfo: null
  }
})
