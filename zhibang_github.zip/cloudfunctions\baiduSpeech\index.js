const cloud = require('wx-server-sdk')
const crypto = require('crypto')
const https = require('https')
const querystring = require('querystring')

cloud.init()

// 百度语音识别配置
const BAIDU_CONFIG = {
  appId: '122625086',
  apiKey: 'WWyFxSXslFwzZxSDWTGLcZvY',
  secretKey: 'jQ41MXQnk5K3ILRZ85i8QtC4TDNTIi3i'
}

// 获取百度 Access Token
async function getAccessToken() {
  const options = {
    hostname: 'aip.baidubce.com',
    path: `/oauth/2.0/token?grant_type=client_credentials&client_id=${BAIDU_CONFIG.apiKey}&client_secret=${BAIDU_CONFIG.secretKey}`,
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Accept': 'application/json'
    }
  }

  return new Promise((resolve, reject) => {
    const req = https.request(options, (res) => {
      let data = ''
      res.on('data', (chunk) => data += chunk)
      res.on('end', () => {
        try {
          const result = JSON.parse(data)
          resolve(result.access_token)
        } catch (e) {
          reject(e)
        }
      })
    })
    req.on('error', reject)
    req.end()
  })
}

// 语音识别
async function recognizeSpeech(audioBuffer, token) {
  const params = querystring.stringify({
    'cuid': 'yinlingzhiban',
    'token': token,
    'dev_pid': 1537  // 普通话(纯中文识别)
  })

  const options = {
    hostname: 'vop.baidu.com',
    path: `/server_api?${params}`,
    method: 'POST',
    headers: {
      'Content-Type': 'audio/pcm;rate=16000',
      'Content-Length': audioBuffer.length
    }
  }

  return new Promise((resolve, reject) => {
    const req = https.request(options, (res) => {
      let data = ''
      res.on('data', (chunk) => data += chunk)
      res.on('end', () => {
        try {
          const result = JSON.parse(data)
          resolve(result)
        } catch (e) {
          reject(e)
        }
      })
    })
    req.on('error', reject)
    req.write(audioBuffer)
    req.end()
  })
}

exports.main = async (event, context) => {
  console.log('云函数被调用，event:', JSON.stringify(Object.keys(event)))
  
  const { audioBase64, audioData } = event
  
  // 兼容两种参数名
  const base64Audio = audioBase64 || audioData
  
  console.log('音频数据长度:', base64Audio ? base64Audio.length : 0)
  
  if (!base64Audio) {
    console.error('错误: 缺少音频数据')
    return {
      success: false,
      error: '缺少音频数据'
    }
  }

  try {
    // 检查配置
    if (!BAIDU_CONFIG.apiKey || !BAIDU_CONFIG.secretKey) {
      console.error('错误: 百度语音配置未填写')
      return {
        success: false,
        error: '百度语音配置未填写，请在云函数中配置 appId, apiKey, secretKey'
      }
    }

    console.log('开始获取 access token...')
    // 获取 access token
    const token = await getAccessToken()
    console.log('获取 token 成功')
    
    // 解码 base64 音频
    const audioBuffer = Buffer.from(base64Audio, 'base64')
    console.log('音频 buffer 长度:', audioBuffer.length)
    
    // 调用语音识别
    console.log('开始调用语音识别...')
    const result = await recognizeSpeech(audioBuffer, token)
    console.log('语音识别结果:', JSON.stringify(result))
    
    if (result.err_no === 0) {
      return {
        success: true,
        text: result.result[0]
      }
    } else {
      console.error('百度识别错误:', result.err_msg)
      return {
        success: false,
        error: `识别失败: ${result.err_msg}`
      }
    }
  } catch (error) {
    console.error('云函数执行错误:', error)
    return {
      success: false,
      error: error.message
    }
  }
}
