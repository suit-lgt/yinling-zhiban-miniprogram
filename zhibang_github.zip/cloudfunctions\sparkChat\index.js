/**
 * 云函数：讯飞星火大模型对话
 */

const crypto = require('crypto')
const WebSocket = require('ws')

// 生成鉴权URL
function generateAuthUrl(config) {
  const { appId, apiKey, apiSecret, host, uri } = config
  const hostUrl = `wss://${host}${uri}`
  
  const url = new URL(hostUrl)
  const date = new Date().toUTCString()
  
  const signatureOrigin = `host: ${url.host}\ndate: ${date}\nGET ${url.pathname} HTTP/1.1`
  
  const signature = crypto
    .createHmac('sha256', apiSecret)
    .update(signatureOrigin)
    .digest('base64')
  
  const authOrigin = `api_key="${apiKey}", algorithm="hmac-sha256", headers="host date request-line", signature="${signature}"`
  const authorization = Buffer.from(authOrigin).toString('base64')
  
  return `${hostUrl}?authorization=${encodeURIComponent(authorization)}&date=${encodeURIComponent(date)}&host=${url.host}`
}

// 主入口
exports.main = async (event, context) => {
  const { header, parameter, payload } = event
  
  // 从环境变量或配置中获取密钥
  const config = {
    appId: '30df6a34',
    apiKey: '923b69f82de716e00c292bfc0e38f2ae',
    apiSecret: 'MjNjZjA0MTJhNzZhOTE1MTUwZDhjNDA0',
    host: 'spark-api.xf-yun.com',
    uri: '/v1.1/chat'
  }
  
  return new Promise((resolve, reject) => {
    const authUrl = generateAuthUrl(config)
    const ws = new WebSocket(authUrl)
    
    let answer = ''
    let isComplete = false
    
    ws.on('open', () => {
      // 发送请求
      const request = {
        header: {
          app_id: config.appId,
          uid: header?.uid || 'anonymous'
        },
        parameter: parameter,
        payload: payload
      }
      ws.send(JSON.stringify(request))
    })
    
    ws.on('message', (data) => {
      try {
        const result = JSON.parse(data)
        
        if (result.header.code !== 0) {
          ws.close()
          resolve({
            code: result.header.code,
            message: result.header.message
          })
          return
        }
        
        // 拼接回答
        if (result.payload && result.payload.choices) {
          const text = result.payload.choices.text
          if (text && text.length > 0) {
            answer += text[0].content
          }
        }
        
        // 检查是否结束
        if (result.payload && result.payload.choices.status === 2) {
          isComplete = true
          ws.close()
          resolve({
            code: 0,
            data: answer,
            message: 'success'
          })
        }
      } catch (e) {
        console.error('解析消息失败', e)
      }
    })
    
    ws.on('error', (err) => {
      console.error('WebSocket错误', err)
      resolve({
        code: -1,
        message: '连接失败：' + err.message
      })
    })
    
    ws.on('close', () => {
      if (!isComplete) {
        resolve({
          code: 0,
          data: answer || '抱歉，我没有听清楚，请再说一遍。',
          message: 'completed'
        })
      }
    })
    
    // 超时处理
    setTimeout(() => {
      ws.close()
      resolve({
        code: -1,
        message: '请求超时'
      })
    }, 30000)
  })
}
