/**
 * 语音识别云函数 - 调用科大讯飞语音听写API
 */

const crypto = require('crypto')
const https = require('https')

// 生成鉴权URL (WebSocket方式)
function getAuthUrl(config) {
  const host = config.host || 'iat-api.xfyun.cn'
  const uri = config.uri || '/v2/iat'
  const apiKey = config.apiKey
  const apiSecret = config.apiSecret
  
  const date = new Date().toUTCString()
  const signatureOrigin = `host: ${host}\ndate: ${date}\nGET ${uri} HTTP/1.1`
  
  const signature = crypto
    .createHmac('sha256', apiSecret)
    .update(signatureOrigin)
    .digest('base64')
  
  const authorizationOrigin = `api_key="${apiKey}", algorithm="hmac-sha256", headers="host date request-line", signature="${signature}"`
  const authorization = Buffer.from(authorizationOrigin).toString('base64')
  
  return `wss://${host}${uri}?authorization=${encodeURIComponent(authorization)}&date=${encodeURIComponent(date)}&host=${encodeURIComponent(host)}`
}

// 主函数
exports.main = async (event, context) => {
  console.log('语音识别云函数被调用')
  
  const { audioBase64, config } = event
  
  if (!audioBase64) {
    return {
      code: -1,
      message: '缺少音频数据'
    }
  }
  
  try {
    const result = await recognizeSpeech(audioBase64, config)
    return {
      code: 0,
      data: result
    }
  } catch (err) {
    console.error('识别失败:', err)
    return {
      code: -1,
      message: err.message
    }
  }
}

// 使用WebSocket调用讯飞语音识别
function recognizeSpeech(audioBase64, config) {
  return new Promise((resolve, reject) => {
    const WebSocket = require('ws')
    const authUrl = getAuthUrl(config)
    
    console.log('连接WebSocket:', authUrl.substring(0, 100) + '...')
    
    const ws = new WebSocket(authUrl)
    
    let resultText = ''
    let isEnd = false
    
    ws.on('open', () => {
      console.log('WebSocket连接成功')
      
      // 发送第一帧
      const firstFrame = {
        common: {
          app_id: config.appId
        },
        business: {
          language: config.language || 'zh_cn',
          domain: config.domain || 'iat',
          accent: config.accent || 'mandarin',
          dwa: config.dwa || 'wpgs'
        },
        data: {
          status: 0,
          format: 'audio/L16;rate=16000',
          encoding: 'raw',
          audio: ''
        }
      }
      
      ws.send(JSON.stringify(firstFrame))
      console.log('发送第一帧')
      
      // 分片发送音频数据
      const chunkSize = 1280
      let offset = 0
      
      function sendNextChunk() {
        if (offset >= audioBase64.length) {
          // 发送最后一帧
          const lastFrame = {
            data: {
              status: 2,
              format: 'audio/L16;rate=16000',
              encoding: 'raw',
              audio: ''
            }
          }
          ws.send(JSON.stringify(lastFrame))
          console.log('发送最后一帧')
          return
        }
        
        const chunk = audioBase64.slice(offset, offset + chunkSize)
        offset += chunkSize
        
        const continueFrame = {
          data: {
            status: 1,
            format: 'audio/L16;rate=16000',
            encoding: 'raw',
            audio: chunk
          }
        }
        
        ws.send(JSON.stringify(continueFrame))
        
        // 继续发送下一片
        setTimeout(sendNextChunk, 40)
      }
      
      // 开始发送音频
      setTimeout(sendNextChunk, 100)
    })
    
    ws.on('message', (data) => {
      try {
        const result = JSON.parse(data)
        console.log('收到消息:', JSON.stringify(result).substring(0, 200))
        
        if (result.code !== 0) {
          console.error('识别错误:', result.message)
          reject(new Error(result.message || '识别失败'))
          ws.close()
          return
        }
        
        // 解析识别结果
        if (result.data && result.data.result) {
          const ws = result.data.result.ws || []
          const text = ws.map(item => item.cw.map(c => c.w).join('')).join('')
          resultText += text
          console.log('当前识别结果:', text)
        }
        
        // 检查是否结束
        if (result.data && result.data.status === 2) {
          isEnd = true
          console.log('识别完成，最终结果:', resultText)
          ws.close()
          resolve(resultText)
        }
      } catch (e) {
        console.error('解析消息失败:', e)
      }
    })
    
    ws.on('error', (err) => {
      console.error('WebSocket错误:', err)
      reject(new Error('WebSocket错误: ' + err.message))
    })
    
    ws.on('close', () => {
      console.log('WebSocket连接关闭')
      if (!isEnd) {
        resolve(resultText || '')
      }
    })
    
    // 设置超时
    setTimeout(() => {
      if (!isEnd) {
        ws.close()
        reject(new Error('识别超时'))
      }
    }, 30000)
  })
}
