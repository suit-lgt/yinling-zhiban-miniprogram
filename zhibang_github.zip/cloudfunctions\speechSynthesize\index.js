/**
 * 云函数：语音合成
 * 调用科大讯飞在线语音合成API
 */

const crypto = require('crypto')
const https = require('https')
const querystring = require('querystring')

// 生成鉴权URL
function assembleAuthUrl(hostUrl, apiKey, apiSecret) {
  try {
    const url = new URL(hostUrl)
    const date = new Date().toUTCString()
    
    const signatureOrigin = `host: ${url.host}\ndate: ${date}\nGET ${url.pathname} HTTP/1.1`
    
    const signature = crypto
      .createHmac('sha256', apiSecret)
      .update(signatureOrigin)
      .digest('base64')
    
    const authOrigin = `api_key="${apiKey}", algorithm="hmac-sha256", headers="host date request-line", signature="${signature}"`
    const authorization = Buffer.from(authOrigin).toString('base64')
    
    const params = {
      authorization: authorization,
      date: date,
      host: url.host
    }
    
    return `${hostUrl}?${querystring.stringify(params)}`
  } catch (e) {
    throw new Error('鉴权URL生成失败: ' + e.message)
  }
}

// 语音合成请求
function synthesizeSpeech(text, config) {
  return new Promise((resolve, reject) => {
    const { appId, apiKey, apiSecret, host, uri, voice } = config
    const hostUrl = `wss://${host}${uri}`
    
    const authUrl = assembleAuthUrl(hostUrl, apiKey, apiSecret)
    
    const WebSocket = require('ws')
    const ws = new WebSocket(authUrl)
    
    let audioData = Buffer.alloc(0)
    
    ws.on('open', () => {
      // 发送合成请求
      const request = {
        common: { app_id: appId },
        business: {
          aue: 'lame',        // MP3格式
          sfl: 1,             // 开启流式返回
          auf: 'audio/L16;rate=16000',
          vcn: voice || 'xiaoyan',
          speed: 50,          // 语速
          volume: 50,         // 音量
          pitch: 50,          // 音调
          bgs: 0,             // 背景音
          tte: 'UTF8'
        },
        data: {
          status: 2,
          text: Buffer.from(text).toString('base64')
        }
      }
      ws.send(JSON.stringify(request))
    })
    
    ws.on('message', (data) => {
      try {
        const result = JSON.parse(data)
        if (result.data && result.data.audio) {
          const audio = Buffer.from(result.data.audio, 'base64')
          audioData = Buffer.concat([audioData, audio])
        }
        
        // 合成完成
        if (result.data && result.data.status === 2) {
          ws.close()
          resolve(audioData)
        }
      } catch (e) {
        // 可能是二进制音频数据
        if (Buffer.isBuffer(data)) {
          audioData = Buffer.concat([audioData, data])
        }
      }
    })
    
    ws.on('error', (err) => {
      reject(err)
    })
    
    ws.on('close', () => {
      resolve(audioData)
    })
    
    setTimeout(() => {
      ws.close()
      reject(new Error('合成超时'))
    }, 30000)
  })
}

// 主入口
exports.main = async (event, context) => {
  const { text, config } = event
  
  if (!config || !config.appId) {
    return {
      code: -1,
      message: '未配置科大讯飞密钥'
    }
  }
  
  if (!text) {
    return {
      code: -1,
      message: '文本不能为空'
    }
  }
  
  try {
    // 调用语音合成
    const audioBuffer = await synthesizeSpeech(text, config)
    
    // 上传到云存储
    const cloud = require('wx-server-sdk')
    cloud.init()
    
    const fileName = `tts/${Date.now()}.mp3`
    const uploadRes = await cloud.uploadFile({
      cloudPath: fileName,
      fileContent: audioBuffer
    })
    
    // 获取临时链接
    const tempUrlRes = await cloud.getTempFileURL({
      fileList: [uploadRes.fileID]
    })
    
    return {
      code: 0,
      data: {
        audioUrl: tempUrlRes.fileList[0].tempFileURL,
        fileID: uploadRes.fileID
      },
      message: '合成成功'
    }
  } catch (err) {
    console.error('语音合成失败:', err)
    return {
      code: -1,
      message: err.message || '合成失败'
    }
  }
}
