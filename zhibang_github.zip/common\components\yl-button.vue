<template>
  <button
    class="yl-button"
    :class="[
      `yl-button--${type}`,
      `yl-button--${size}`,
      { 'yl-button--disabled': disabled },
      { 'yl-button--block': block }
    ]"
    :disabled="disabled"
    :loading="loading"
    :aria-label="ariaLabel"
    @click="handleClick"
  >
    <view v-if="loading" class="yl-button__loading"></view>
    <slot></slot>
  </button>
</template>

<script>
export default {
  name: 'yl-button',
  props: {
    type: {
      type: String,
      default: 'primary',
      validator: value => ['primary', 'secondary', 'danger', 'text'].includes(value)
    },
    size: {
      type: String,
      default: 'medium',
      validator: value => ['small', 'medium', 'large'].includes(value)
    },
    disabled: {
      type: Boolean,
      default: false
    },
    loading: {
      type: Boolean,
      default: false
    },
    block: {
      type: Boolean,
      default: false
    },
    ariaLabel: {
      type: String,
      default: ''
    }
  },
  methods: {
    handleClick(e) {
      if (!this.disabled && !this.loading) {
        this.$emit('click', e)
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.yl-button {
  display: inline-flex;
  justify-content: center;
  align-items: center;
  border: none;
  border-radius: 8px;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.2s ease;

  &:active:not(.yl-button--disabled) {
    transform: scale(0.98);
    opacity: 0.9;
  }

  &--small {
    min-width: 44px;
    min-height: 44px;
    padding: 8px 16px;
    font-size: 14px;
  }

  &--medium {
    min-width: 48px;
    min-height: 48px;
    padding: 12px 24px;
    font-size: 16px;
  }

  &--large {
    min-width: 56px;
    min-height: 56px;
    padding: 16px 32px;
    font-size: 18px;
  }

  &--block {
    width: 100%;
    display: flex;
  }

  &--primary {
    background-color: #3792ED;
    color: #FFFFFF;
  }

  &--secondary {
    background-color: #F5F5F5;
    color: #333333;
  }

  &--danger {
    background-color: #E74C3C;
    color: #FFFFFF;
  }

  &--text {
    background-color: transparent;
    color: #3792ED;
  }

  &--disabled {
    background-color: #CCCCCC;
    color: #999999;
    cursor: not-allowed;
    opacity: 0.5;
  }

  &__loading {
    width: 16px;
    height: 16px;
    border: 2px solid rgba(255, 255, 255, 0.3);
    border-top-color: #FFFFFF;
    border-radius: 50%;
    animation: spin 0.8s linear infinite;
    margin-right: 8px;
  }
}

@keyframes spin {
  to {
    transform: rotate(360deg);
  }
}
</style>
