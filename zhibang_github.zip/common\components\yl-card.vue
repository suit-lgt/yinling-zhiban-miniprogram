<template>
  <view class="yl-card" :class="{ 'yl-card--shadow': shadow }">
    <view v-if="title" class="yl-card__header">
      <text class="yl-card__title">{{ title }}</text>
      <slot name="extra"></slot>
    </view>
    <view class="yl-card__body" :class="{ 'yl-card__body--no-padding': noPadding }">
      <slot></slot>
    </view>
    <view v-if="$slots.footer" class="yl-card__footer">
      <slot name="footer"></slot>
    </view>
  </view>
</template>

<script>
export default {
  name: 'yl-card',
  props: {
    title: {
      type: String,
      default: ''
    },
    shadow: {
      type: Boolean,
      default: true
    },
    noPadding: {
      type: Boolean,
      default: false
    }
  }
}
</script>

<style lang="scss" scoped>
.yl-card {
  background-color: #FFFFFF;
  border-radius: 12px;
  overflow: hidden;

  &--shadow {
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
  }

  &__header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 16px;
    border-bottom: 1px solid #E5E5E5;
  }

  &__title {
    font-size: 18px;
    font-weight: 600;
    color: #333333;
  }

  &__body {
    padding: 16px;

    &--no-padding {
      padding: 0;
    }
  }

  &__footer {
    padding: 12px 16px;
    border-top: 1px solid #E5E5E5;
    background-color: #FAFAFA;
  }
}
</style>
