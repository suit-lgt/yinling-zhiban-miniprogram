<template>
  <view class="yl-input" :class="{ 'yl-input--error': error, 'yl-input--disabled': disabled }">
    <label v-if="label" :for="inputId" class="yl-input__label">
      {{ label }}
      <text v-if="required" class="yl-input__required">*</text>
    </label>
    <view class="yl-input__wrapper">
      <input
        :id="inputId"
        class="yl-input__field"
        :class="{ 'yl-input__field--right': clearable }"
        :type="type"
        :value="value"
        :placeholder="placeholder"
        :disabled="disabled"
        :maxlength="maxlength"
        :focus="focus"
        :aria-invalid="!!error"
        :aria-describedby="error ? errorId : ''"
        @input="handleInput"
        @focus="handleFocus"
        @blur="handleBlur"
        @confirm="handleConfirm"
      />
      <view
        v-if="clearable && value"
        class="yl-input__clear"
        @click="handleClear"
      >
        ✕
      </view>
    </view>
    <text
      v-if="error"
      :id="errorId"
      class="yl-input__error"
      role="alert"
    >
      {{ error }}
    </text>
    <text v-else-if="hint" class="yl-input__hint">
      {{ hint }}
    </text>
  </view>
</template>

<script>
export default {
  name: 'yl-input',
  props: {
    label: {
      type: String,
      default: ''
    },
    value: {
      type: [String, Number],
      default: ''
    },
    type: {
      type: String,
      default: 'text'
    },
    placeholder: {
      type: String,
      default: '请输入'
    },
    disabled: {
      type: Boolean,
      default: false
    },
    error: {
      type: String,
      default: ''
    },
    hint: {
      type: String,
      default: ''
    },
    required: {
      type: Boolean,
      default: false
    },
    maxlength: {
      type: Number,
      default: -1
    },
    clearable: {
      type: Boolean,
      default: false
    },
    focus: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      inputId: `yl-input-${Math.random().toString(36).substr(2, 9)}`,
      errorId: `yl-input-error-${Math.random().toString(36).substr(2, 9)}`
    }
  },
  methods: {
    handleInput(e) {
      const value = e.detail.value
      this.$emit('input', value)
    },
    handleFocus(e) {
      this.$emit('focus', e)
    },
    handleBlur(e) {
      this.$emit('blur', e)
    },
    handleConfirm(e) {
      this.$emit('confirm', e.detail.value)
    },
    handleClear() {
      this.$emit('input', '')
      this.$emit('clear')
    }
  }
}
</script>

<style lang="scss" scoped>
.yl-input {
  margin-bottom: 16px;

  &__label {
    display: block;
    font-size: 16px;
    color: #333333;
    margin-bottom: 8px;
  }

  &__required {
    color: #E74C3C;
    margin-left: 4px;
  }

  &__wrapper {
    position: relative;
    display: flex;
    align-items: center;
  }

  &__field {
    width: 100%;
    min-height: 48px;
    padding: 10px 16px;
    font-size: 18px;
    color: #333333;
    background-color: #FFFFFF;
    border: 1px solid #E5E5E5;
    border-radius: 8px;

    &--right {
      padding-right: 40px;
    }

    &:focus {
      border-color: #3792ED;
      outline: 3px solid rgba(55, 146, 237, 0.2);
      outline-offset: 1px;
    }
  }

  &__clear {
    position: absolute;
    right: 12px;
    width: 24px;
    height: 24px;
    display: flex;
    justify-content: center;
    align-items: center;
    font-size: 14px;
    color: #999999;
    background-color: #E5E5E5;
    border-radius: 50%;
  }

  &__error {
    display: block;
    margin-top: 8px;
    font-size: 14px;
    color: #E74C3C;
  }

  &__hint {
    display: block;
    margin-top: 8px;
    font-size: 14px;
    color: #999999;
  }

  &--error {
    .yl-input__field {
      border-color: #E74C3C;
    }
  }

  &--disabled {
    .yl-input__field {
      background-color: #F5F5F5;
      color: #999999;
    }
  }
}
</style>
