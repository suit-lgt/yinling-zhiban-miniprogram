<template>
  <div class="keyboard-container">
    <!-- 模式切换标签 -->
    <div class="keyboard-tabs">
      <div 
        class="keyboard-tab" 
        :class="{ 'keyboard-tab--active': currentMode === '26key' }"
        @click="switchMode('26key')"
      >
        26键
      </div>
      <div 
        class="keyboard-tab" 
        :class="{ 'keyboard-tab--active': currentMode === '9key' }"
        @click="switchMode('9key')"
      >
        9键
      </div>
      <div 
        class="keyboard-tab" 
        :class="{ 'keyboard-tab--active': currentMode === 'handwriting' }"
        @click="switchMode('handwriting')"
      >
        手写
      </div>
    </div>

    <!-- 候选词区域 -->
    <div class="candidate-area" v-if="currentMode !== 'handwriting'">
      <div class="candidate-input" v-if="pinyinInput">
        <span class="candidate-input__text">{{ pinyinInput }}</span>
        <span class="candidate-input__clear" @click="clearPinyin">✕</span>
      </div>
      <div 
        class="candidate-word" 
        v-for="(word, index) in candidates" 
        :key="index"
        @click="selectCandidate(word)"
      >
        {{ word }}
      </div>
      <div class="candidate-empty" v-if="!pinyinInput && candidates.length === 0">
        点击字母输入拼音
      </div>
    </div>

    <!-- 26键键盘 -->
    <div class="keyboard-26key" v-if="currentMode === '26key'">
      <div class="keyboard-row" v-for="(row, rowIndex) in keyRows26" :key="rowIndex">
        <div 
          class="key-26" 
          :class="{ 
            'key-26--space': key === 'space', 
            'key-26--function': isFunctionKey(key),
            'key-26--active': key === 'shift' && isShift
          }"
          v-for="(key, keyIndex) in row" 
          :key="keyIndex"
          @click="handleKeyClick(key)"
        >
          {{ getKeyLabel(key) }}
        </div>
      </div>
    </div>

    <!-- 9键键盘 -->
    <div class="keyboard-9key" v-if="currentMode === '9key'">
      <div class="keyboard-row" v-for="(row, rowIndex) in keyRows9" :key="rowIndex">
        <div 
          class="key-9" 
          v-for="(key, keyIndex) in row" 
          :key="keyIndex"
          @click="handleKey9Click(key)"
        >
          <span class="key-9__number">{{ key }}</span>
          <span class="key-9__letters">{{ get9KeyLetters(key) }}</span>
        </div>
      </div>
      <!-- 9键功能区 -->
      <div class="keyboard-row">
        <div class="key-9 key-9--function" @click="togglePunctuation">
          {{ showPunctuation ? '返回' : '符' }}
        </div>
        <div class="key-9 key-9--function" @click="handleSpace">空格</div>
        <div class="key-9 key-9--function key-9--delete" @click="handleDelete">
          <span>删除</span>
        </div>
      </div>
      <!-- 标点符号行 -->
      <div class="keyboard-row" v-if="showPunctuation">
        <div 
          class="key-26 key-26--punctuation" 
          v-for="(p, index) in punctuationMarks" 
          :key="index"
          @click="addPunctuation(p)"
        >
          {{ p }}
        </div>
      </div>
    </div>

    <!-- 手写板 -->
    <div class="keyboard-handwriting" v-if="currentMode === 'handwriting'">
      <canvas 
        ref="canvas" 
        class="handwriting-canvas"
        @mousedown="startDraw"
        @mousemove="draw"
        @mouseup="endDraw"
        @mouseleave="endDraw"
        @touchstart.prevent="startDrawTouch"
        @touchmove.prevent="drawTouch"
        @touchend.prevent="endDraw"
      ></canvas>
      <div class="handwriting-tools">
        <div class="handwriting-btn" @click="toggleEraser" :class="{ 'handwriting-btn--active': isEraser }">
          {{ isEraser ? '橡皮擦' : '画笔' }}
        </div>
        <div class="handwriting-btn" @click="clearCanvas">清除</div>
        <div class="handwriting-btn handwriting-btn--confirm" @click="confirmHandwriting">识别</div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'yl-keyboard',
  props: {
    value: {
      type: String,
      default: ''
    }
  },
  data() {
    return {
      currentMode: '26key',
      isShift: false,
      showPunctuation: false,
      pinyinInput: '',
      candidates: [],
      inputTimeout: null,
      isEraser: false,
      lastX: 0,
      lastY: 0,
      ctx: null,
      strokeHistory: [],
      keyRows26: [
        ['q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p'],
        ['a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l'],
        ['shift', 'z', 'x', 'c', 'v', 'b', 'n', 'm', 'delete'],
        ['space', 'return']
      ],
      keyRows9: [
        ['1', '2', '3'],
        ['4', '5', '6'],
        ['7', '8', '9']
      ],
      punctuationMarks: ['，', '。', '？', '！', '：', '；', '"', '"', "'", "'"],
      key9Letters: {
        '2': 'abc', '3': 'def', '4': 'ghi', '5': 'jkl',
        '6': 'mno', '7': 'pqrs', '8': 'tuv', '9': 'wxyz'
      },
      pinyinDict: null
    }
  },
  watch: {
    value: {
      immediate: true,
      handler(newVal) {
        this.inputText = newVal || ''
      }
    }
  },
  mounted() {
    this.initPinyinDict()
    this.$nextTick(() => {
      this.initCanvas()
    })
  },
  methods: {
    initPinyinDict() {
      this.pinyinDict = {
        'a': ['啊', '阿', '呀', '吖', '腌', '嗄'],
        'ai': ['爱', '哎', '矮', '碍', '艾', '癌', '安', '按', '暗', '岸'],
        'an': ['安', '按', '暗', '岸', '案', '俺', '鞍', '胺', '鹌'],
        'ang': ['昂', '肮', '盎'],
        'ao': ['奥', '傲', '熬', '凹', '遨', '澳', '懊'],
        'ba': ['把', '八', '吧', '爸', '拔', '巴', '坝', '霸', '罢', '芭'],
        'bai': ['白', '百', '拜', '摆', '败', '柏', '伯'],
        'ban': ['办', '半', '班', '板', '版', '般', '伴', '扮', '颁'],
        'bang': ['帮', '棒', '绑', '榜', '磅', '镑', '邦'],
        'bao': ['报', '保', '宝', '包', '抱', '暴', '爆', '薄'],
        'bei': ['被', '北', '备', '背', '倍', '杯', '贝', '辈'],
        'ben': ['本', '奔', '笨', '苯', '夯'],
        'beng': ['崩', '蹦', '绷', '泵', '蚌'],
        'bi': ['比', '笔', '必', '闭', '毕', '避', '鼻', '碧'],
        'bian': ['边', '便', '变', '编', '遍', '辩', '辨', '贬'],
        'biao': ['表', '标', '彪', '膘', '镖'],
        'bie': ['别', '憋', '瘪', '蹩'],
        'bin': ['宾', '滨', '彬', '濒', '缤'],
        'bing': ['病', '并', '冰', '兵', '饼'],
        'bo': ['博', '不', '波', '拨', '播', '伯'],
        'bu': ['不', '步', '部', '布', '补', '捕'],
        'ca': ['擦', '拆', '拆'],
        'cai': ['才', '材', '采', '菜', '彩', '财'],
        'can': ['参', '餐', '残', '惭', '灿', '惨'],
        'cang': ['藏', '仓', '苍', '沧', '舱'],
        'cao': ['草', '操', '曹', '糙'],
        'ce': ['测', '策', '册', '侧', '厕'],
        'ceng': ['层', '曾', '蹭'],
        'cha': ['查', '茶', '差', '察', '插', '叉'],
        'chai': ['拆', '柴', '钗', '茈'],
        'chan': ['产', '禅', '颤', '铲', '蝉'],
        'chang': ['长', '常', '场', '唱', '厂', '畅', '昌'],
        'chao': ['超', '朝', '潮', '炒', '吵', '抄'],
        'che': ['车', '彻', '扯', '撤'],
        'chen': ['陈', '沉', '晨', '衬', '趁'],
        'cheng': ['成', '城', '程', '承', '呈', '诚'],
        'chi': ['吃', '持', '迟', '赤', '尺', '池'],
        'chong': ['重', '冲', '充', '虫', '宠'],
        'chou': ['抽', '愁', '丑', '臭', '仇'],
        'chu': ['出', '初', '处', '除', '础', '储'],
        'chuan': ['传', '川', '船', '穿', '串'],
        'chuang': ['创', '床', '窗', '闯'],
        'chui': ['吹', '垂', '炊', '捶'],
        'chun': ['春', '纯', '唇', '淳', '蠢'],
        'chuo': ['戳', '绰', '踔'],
        'ci': ['此', '次', '词', '辞', '刺', '慈'],
        'cong': ['从', '聪', '丛', '匆', '葱'],
        'cou': ['凑', '揍', '楱'],
        'cu': ['粗', '促', '醋', '簇', '猝'],
        'cuan': ['窜', '攒', '篡', '蹿'],
        'cui': ['脆', '翠', '崔', '催', '摧'],
        'cun': ['村', '存', '寸'],
        'cuo': ['错', '措', '挫', '搓', '磋'],
        'da': ['大', '打', '达', '答', '搭'],
        'dai': ['带', '待', '代', '袋', '呆'],
        'dan': ['但', '单', '担', '蛋', '淡', '胆'],
        'dang': ['当', '党', '档', '挡', '荡'],
        'dao': ['到', '道', '导', '倒', '刀', '岛'],
        'de': ['的', '得', '地'],
        'deng': ['等', '登', '灯', '邓', '凳'],
        'di': ['地', '的', '第', '低', '底', '敌'],
        'dian': ['点', '电', '店', '典', '殿', '淀'],
        'diao': ['掉', '吊', '调', '钓', '雕'],
        'die': ['跌', '爹', '碟', '谍', '叠'],
        'ding': ['定', '顶', '订', '钉', '盯'],
        'diu': ['丢'],
        'dong': ['东', '动', '懂', '冬', '洞'],
        'dou': ['都', '斗', '豆', '逗', '抖'],
        'du': ['读', '度', '独', '都', '毒', '堵'],
        'duan': ['段', '短', '断', '端', '锻'],
        'dui': ['对', '队', '堆', '兑'],
        'dun': ['顿', '吨', '蹲', '盾', '钝'],
        'duo': ['多', '夺', '朵', '躲', 'duo'],
        'e': ['额', '饿', '恶', '鹅', '俄', '遏'],
        'en': ['恩'],
        'er': ['而', '二', '儿', '尔', '耳'],
        'fa': ['发', '法', '罚', '乏', '伐'],
        'fan': ['反', '饭', '翻', '凡', '范', '烦'],
        'fang': ['方', '放', '房', '防', '访', '仿'],
        'fei': ['非', '飞', '费', '肥', '废', '沸'],
        'fen': ['分', '份', '粉', '纷', '奋', '愤'],
        'feng': ['风', '封', '丰', '峰', '锋', '疯'],
        'fo': ['佛'],
        'fou': ['否'],
        'fu': ['服', '福', '付', '父', '副', '复'],
        'ga': ['噶', '嘎'],
        'gai': ['该', '改', '盖', '概', '钙'],
        'gan': ['干', '感', '赶', '敢', '甘', '肝'],
        'gang': ['刚', '港', '钢', '岗', '纲'],
        'gao': ['高', '告', '搞', '稿', '糕'],
        'ge': ['个', '各', '歌', '哥', '格', '革'],
        'gei': ['给'],
        'gen': ['根', '跟'],
        'geng': ['更', '耕', '梗', 'geng'],
        'gong': ['工', '公', '共', '功', '供', '攻'],
        'gou': ['够', '狗', '购', '构', '钩'],
        'gu': ['古', '故', '估', '顾', '姑', '骨'],
        'gua': ['挂', '刮', '瓜', '寡', '卦'],
        'guai': ['怪', '乖', '拐'],
        'guan': ['关', '观', '管', '官', '馆', '惯'],
        'guang': ['光', '广', '逛', '犷'],
        'gui': ['贵', '规', '鬼', '归', '桂', '柜'],
        'gun': ['滚', '棍', '辊'],
        'guo': ['过', '国', '果', '锅', '裹'],
        'ha': ['哈'],
        'hai': ['还', '海', '害', '孩', '咳'],
        'han': ['汉', '含', '喊', '寒', '罕', '翰'],
        'hang': ['行', '航', '杭', '巷'],
        'hao': ['好', '号', '浩', '毫', '豪'],
        'he': ['和', '河', '何', '合', '喝', '核'],
        'hei': ['黑', '嘿'],
        'hen': ['很', '恨', '狠'],
        'heng': ['横', '恒', '哼'],
        'hong': ['红', '洪', '宏', '虹', '鸿'],
        'hou': ['后', '候', '厚', '侯', '吼'],
        'hu': ['户', '胡', '湖', '互', '虎', '护'],
        'hua': ['话', '化', '华', '花', '画', '划'],
        'huai': ['坏', '怀', '淮', '槐', '踝'],
        'huan': ['换', '还', '环', '欢', '缓'],
        'huang': ['黄', '慌', '荒', '皇', '谎'],
        'hui': ['会', '回', '汇', '辉', '毁', '悔'],
        'hun': ['混', '婚', '魂', '浑', '昏'],
        'huo': ['活', '火', '或', '获', '货', '祸'],
        'ji': ['及', '机', '基', '己', '记', '几'],
        'jia': ['家', '加', '假', '价', '架', '嘉'],
        'jian': ['见', '间', '建', '简', '减', '检'],
        'jiang': ['将', '江', '讲', '奖', 'jiang'],
        'jiao': ['教', '交', '叫', '较', '角', '脚'],
        'jie': ['结', '接', '街', '节', '姐', '解'],
        'jin': ['进', '今', '金', '仅', '近', '尽'],
        'jing': ['经', '精', '京', '景', '静', '竞'],
        'jiong': ['窘', '炯'],
        'jiu': ['就', '九', '久', '酒', '救', '旧'],
        'ju': ['具', '据', '举', '居', '局', '聚'],
        'juan': ['卷', 'juān'],
        'jue': ['决', '觉', '绝', '角'],
        'jun': ['军', '均', '君', '俊'],
        'ka': ['卡', '咖', '喀', '咔'],
        'kai': ['开', 'kai'],
        'kan': ['看', '刊', '砍', '坎', '勘'],
        'kang': ['抗', '康', '慷', '扛'],
        'kao': ['考', '靠', '烤', '拷'],
        'ke': ['可', '科', '课', '客', '克'],
        'ken': ['肯', '恳', '啃', '恳'],
        'keng': ['坑', '吭'],
        'kong': ['空', '控', '孔', '恐'],
        'kou': ['口', '扣', '抠', '寇'],
        'ku': ['苦', '库', '哭', '酷', '裤'],
        'kua': ['夸', '垮', '跨', '挎', '垮'],
        'kuai': ['快', '块', '会计', '蒯'],
        'kuan': ['宽', '款'],
        'kuang': ['况', '框', '矿', '狂'],
        'kui': ['亏', '愧', '馈', 'kui'],
        'kun': ['困', '昆', '坤', '捆'],
        'kuo': ['扩', '阔', '括', '扩'],
        'la': ['拉', '啦', '辣', '腊'],
        'lai': ['来', '赖', '莱', '癞'],
        'lan': ['蓝', '兰', '拦', '篮', '懒'],
        'lang': ['浪', '郎', '狼', '朗', '琅'],
        'lao': ['老', '劳', '姥', '捞'],
        'le': ['了', '乐', 'le'],
        'lei': ['累', '雷', '泪', '类', '勒'],
        'leng': ['冷', '楞'],
        'li': ['里', '理', '力', '立', '李', '利'],
        'lia': ['俩'],
        'lian': ['连', '联', '脸', '练', '恋'],
        'liang': ['两', '量', '亮', '良', '凉'],
        'liao': ['了', '料', '疗', '辽', '聊'],
        'lie': ['列', '烈', '猎', '裂'],
        'lin': ['临', '林', '淋', '邻', 'lin'],
        'ling': ['零', '领', '另', '令', '灵'],
        'liu': ['六', '流', '留', '刘', '柳'],
        'long': ['龙', '隆', 'long'],
        'lou': ['楼', '搂', 'lou'],
        'lu': ['路', '陆', '露', '鹿', '录'],
        'lv': ['绿', '律', '旅', '率', '吕'],
        'luan': ['乱', '卵'],
        'lue': ['略'],
        'lun': ['论', '轮', '伦'],
        'luo': ['落', '罗', '洛', '络'],
        'ma': ['吗', '妈', '马', '麻', '骂'],
        'mai': ['买', '卖', '麦', '迈'],
        'man': ['慢', '满', 'man'],
        'mang': ['忙', '盲', '茫', '莽'],
        'mao': ['毛', '猫', '冒', '贸', '帽'],
        'me': ['么'],
        'mei': ['没', '每', '美', '妹', '梅'],
        'men': ['们', '闷', '门'],
        'meng': ['梦', '盟', '猛', '蒙'],
        'mi': ['米', '迷', '密', '蜜', '眯'],
        'mian': ['面', '免', '棉', '眠'],
        'miao': ['秒', '苗', '描', '妙'],
        'mie': ['灭', '蔑', '篾'],
        'min': ['民', '敏', '闽', '悯'],
        'ming': ['明', '名', '命', '鸣', '盟'],
        'miu': ['谬'],
        'mo': ['莫', '末', '模', '摸', '墨'],
        'mou': ['某', '谋', '牟', '眸'],
        'mu': ['目', '母', '木', '墓', '幕'],
        'na': ['那', '拿', '哪', '纳', '娜'],
        'nai': ['奶', '耐', '乃', '氖'],
        'nan': ['南', '男', '难', 'nan'],
        'nang': ['囊'],
        'nao': ['脑', '闹', '恼', '挠'],
        'ne': ['呢', '哪'],
        'nei': ['内'],
        'nen': ['嫩'],
        'neng': ['能'],
        'ni': ['你', '尼', '泥', '拟', '逆'],
        'nian': ['年', '念', 'nian'],
        'niang': ['娘'],
        'niao': ['鸟', '尿'],
        'nie': ['捏', '聂', 'nie'],
        'nin': ['您'],
        'ning': ['宁', '凝', 'ning'],
        'niu': ['牛', '扭', 'niu'],
        'nong': ['农', '浓', '弄', '脓'],
        'nu': ['努', '怒', '奴', '弩'],
        'nuan': ['暖'],
        'nue': ['虐', '疟', '疟'],
        'nuo': ['诺', '挪', '懦', '糯'],
        'o': ['哦', '噢'],
        'ou': ['欧', '偶', '呕', '藕'],
        'pa': ['怕', '爬', '帕', '趴', '趴'],
        'pai': ['派', '拍', '排', '牌'],
        'pan': ['盘', '判', '叛', '盼', '攀'],
        'pang': ['旁', '胖', '庞', '螃'],
        'pao': ['跑', '炮', '泡', '炮'],
        'pei': ['配', '培', '赔', '陪'],
        'pen': ['盆', '喷'],
        'peng': ['朋', '碰', '彭', '棚'],
        'pi': ['批', '皮', '疲', '匹', '屁'],
        'pian': ['片', '篇', '偏', '骗'],
        'piao': ['票', '飘', '漂', '瓢'],
        'pie': ['撇', '瞥', '氕'],
        'pin': ['品', '贫', '拼', '频'],
        'ping': ['平', '评', '屏', '乒'],
        'po': ['破', '迫', '坡', '泼', '颇'],
        'pou': ['剖', 'pou'],
        'pu': ['普', '扑', '铺', '葡'],
        'qi': ['其', '起', '期', '七', '齐'],
        'qia': ['恰', '洽', '掐'],
        'qian': ['前', '千', '签', '钱', '潜'],
        'qiang': ['强', '墙', '抢', 'qiang'],
        'qiao': ['桥', '巧', '敲', '悄', 'qiao'],
        'qie': ['且', '切', '茄', '窃'],
        'qin': ['亲', '琴', '勤', '侵', '秦'],
        'qing': ['请', '清', '情', '青', '轻'],
        'qiong': ['穷', '琼', '穹'],
        'qiu': ['求', '球', '秋', 'qiu'],
        'qu': ['去', '区', '取', '曲', '趣'],
        'quan': ['全', '权', '泉', '圈', '劝'],
        'que': ['却', '确', '缺', '雀'],
        'qun': ['群', '裙', 'qun'],
        'ran': ['然', '燃', '染', '冉'],
        'rang': ['让', '瓤', '壤', '攘'],
        'rao': ['绕', '饶', '桡'],
        're': ['热', '惹', '热'],
        'ren': ['人', '认', '任', '仁', '忍'],
        'reng': ['仍'],
        'ri': ['日'],
        'rong': ['容', '融', '荣', '绒'],
        'rou': ['肉', '揉', '柔', '揉'],
        'ru': ['如', '入', '儒', '蠕'],
        'ruan': ['软'],
        'rui': ['瑞', '锐', 'rui'],
        'run': ['润', '闰'],
        'ruo': ['若', '弱', 's'],
        'sa': ['撒', '洒', '卅'],
        'sai': ['赛', '塞', '腮', '鳃'],
        'san': ['三', '散', '伞', '散的'],
        'sang': ['桑', '嗓', '丧', '搡'],
        'sao': ['扫', '骚', '嫂', '搔'],
        'se': ['色', '涩', '瑟', '啬'],
        'sen': ['森'],
        'seng': ['僧'],
        'sha': ['沙', '杀', '啥', '傻'],
        'shai': ['晒', '筛', '色'],
        'shan': ['山', '闪', '善', '扇', '删'],
        'shang': ['上', '商', '伤', '赏', 'shang'],
        'shao': ['少', '绍', '烧', '稍', 'shao'],
        'she': ['社', '设', 'she'],
        'shen': ['什', '身', '神', '深', 'shen'],
        'sheng': ['生', '声', '升', '胜', 'sheng'],
        'shi': ['是', '时', '十', '事', '市'],
        'shou': ['手', '受', '收', '首', 'shou'],
        'shu': ['书', '数', '树', '术', 'shu'],
        'shua': ['刷', '耍', '唰'],
        'shuai': ['摔', '帅', '衰', 'shuai'],
        'shuan': ['栓', '拴', '涮'],
        'shuang': ['双', '爽', '泷'],
        'shui': ['水', '税', '睡', 'shui'],
        'shun': ['顺', '瞬', 'shun'],
        'shuo': ['说', '硕', '朔', '烁'],
        'si': ['四', '思', '死', '私', '司'],
        'song': ['送', '松', '宋', 'song'],
        'sou': ['搜', '艘', '嗽'],
        'su': ['速', '素', '诉', '苏', '俗'],
        'suan': ['算', '酸', '蒜', '狻'],
        'sui': ['岁', '随', '碎', 'sui'],
        'sun': ['孙', '损', '笋', 'sun'],
        'suo': ['所', '索', 'suo'],
        'ta': ['他', '她', '它', '塔', '塌'],
        'tai': ['太', '台', '态', '抬', 'tai'],
        'tan': ['谈', '弹', '探', '叹', 'tan'],
        'tang': ['糖', '汤', '堂', '唐', 'tang'],
        'tao': ['讨', '套', '逃', '桃', 'tao'],
        'te': ['特'],
        'teng': ['疼', '腾', '藤', '疼'],
        'ti': ['提', '体', '题', '踢', 'ti'],
        'tian': ['天', '田', '甜', '填', 'tian'],
        'tiao': ['条', '跳', '调', '挑'],
        'tie': ['铁', '贴', '帖', '帖'],
        'ting': ['听', '停', '庭', 'ting'],
        'tong': ['同', '通', '痛', '统', 'tong'],
        'tou': ['头', '投', '透', '偷'],
        'tu': ['图', '土', '突', '途', '图'],
        'tuan': ['团', '湍', '疃'],
        'tui': ['推', '退', '腿', 'tui'],
        'tun': ['吞', '屯', '囤'],
        'tuo': ['拖', '脱', '拓', 'tuo'],
        'wa': ['挖', '瓦', '娃', '蛙', '哇'],
        'wai': ['外', '歪', '崴'],
        'wan': ['完', '万', '晚', '半', 'wan'],
        'wang': ['王', '往', '忘', '望', 'wang'],
        'wei': ['为', '位', '未', '卫', 'wei'],
        'wen': ['文', '问', '闻', '温', 'wen'],
        'weng': ['翁', '嗡', 'weng'],
        'wo': ['我', '握', '卧', '沃'],
        'wu': ['无', '五', '物', '务', 'wu'],
        'xi': ['西', '系', '习', '喜', 'xi'],
        'xia': ['下', '夏', '吓', '侠', 'xia'],
        'xian': ['现', '先', '线', '县', 'xian'],
        'xiang': ['向', '想', '象', '相', 'xiang'],
        'xiao': ['小', '校', '笑', '消', 'xiao'],
        'xie': ['写', '些', '谢', '鞋', 'xie'],
        'xin': ['心', '新', '信', '辛', 'xin'],
        'xing': ['行', '星', '兴', '性', 'xing'],
        'xiong': ['熊', '胸', '雄', '凶'],
        'xiu': ['修', '秀', '休', '羞', 'xiu'],
        'xu': ['需', '须', '许', '续', 'xu'],
        'xuan': ['选', '宣', '旋', 'xuān'],
        'xue': ['学', '雪', '血', 'xue'],
        'xun': ['训', '讯', '迅', '寻', 'xun'],
        'ya': ['牙', '呀', '鸭', '压', 'ya'],
        'yan': ['研', '眼', '演', '严', 'yan'],
        'yang': ['样', '阳', '养', '羊', 'yang'],
        'yao': ['要', '药', '摇', '腰', 'yao'],
        'ye': ['也', '业', '夜', '叶', 'ye'],
        'yi': ['一', '以', '意', '义', 'yi'],
        'yin': ['因', '银', '音', '引', 'yin'],
        'ying': ['应', '英', '影', '营', 'ying'],
        'yo': ['哟', '唷'],
        'yong': ['用', '永', '勇', '涌', 'yong'],
        'you': ['有', '由', '又', '右', 'you'],
        'yu': ['于', '与', '予', '雨', 'yu'],
        'yuan': ['元', '原', '员', '园', 'yuan'],
        'yue': ['月', '约', '越', '乐', 'yue'],
        'yun': ['云', '运', '允', '孕', 'yun'],
        'za': ['杂', '咱', '砸', '匝'],
        'zai': ['在', '再', '载', 'zai'],
        'zan': ['咱', '赞', '暂', '攒'],
        'zang': ['脏', '葬', 'zang'],
        'zao': ['早', '造', '遭', '糟', 'zao'],
        'ze': ['则', '责', '泽', '择'],
        'zei': ['贼'],
        'zen': ['怎'],
        'zeng': ['增', '曾', 'zeng'],
        'zha': ['炸', '扎', 'zhā'],
        'zhai': ['宅', '窄', '债', 'zhai'],
        'zhan': ['站', '战', '占', '展', 'zhan'],
        'zhang': ['张', '长', '章', '掌', 'zhang'],
        'zhao': ['找', '照', '着', '招', 'zhao'],
        'zhe': ['这', '着', '者', 'zhe'],
        'zhen': ['真', '镇', '针', '振', 'zhen'],
        'zheng': ['正', '政', '整', '证', 'zheng'],
        'zhi': ['之', '知', '只', '直', 'zhi'],
        'zhong': ['中', '重', '种', '众', 'zhong'],
        'zhou': ['周', '州', '洲', '粥', 'zhou'],
        'zhu': ['主', '住', '注', '助', 'zhu'],
        'zhua': ['抓', '爪', '爪'],
        'zhuai': ['拽'],
        'zhuan': ['转', '专', '赚', 'zhuān'],
        'zhuang': ['装', '庄', '壮', 'zhuang'],
        'zhui': ['追', '坠', '缀', 'zhuī'],
        'zhun': ['准', '吨'],
        'zhuo': ['桌', '捉', '卓', 'zhuō'],
        'zi': ['自', '子', '字', '资', 'zi'],
        'zong': ['总', '宗', '综', 'zong'],
        'zou': ['走', '奏', '揍'],
        'zu': ['组', '足', '族', '阻', 'zu'],
        'zuan': ['钻', 'zuan'],
        'zui': ['最', '嘴', '罪', 'zui'],
        'zun': ['尊', '遵', 'zun'],
        'zuo': ['做', '作', '坐', '左', 'zuo']
      }
    },
    switchMode(mode) {
      this.currentMode = mode
      this.clearPinyin()
      this.showPunctuation = false
    },
    handleKeyClick(key) {
      if (key === 'space') {
        this.confirmPinyin()
        this.addChar(' ')
      } else if (key === 'delete') {
        this.handleDelete()
      } else if (key === 'shift') {
        this.isShift = !this.isShift
      } else if (key === 'return') {
        this.confirmPinyin()
        this.submitText()
      } else {
        const char = this.isShift ? key.toUpperCase() : key
        this.addPinyinChar(char)
      }
    },
    addPinyinChar(char) {
      this.pinyinInput += char
      this.updateCandidates()
      
      clearTimeout(this.inputTimeout)
      this.inputTimeout = setTimeout(() => {
        this.confirmPinyin()
      }, 1500)
    },
    updateCandidates() {
      if (!this.pinyinInput) {
        this.candidates = []
        return
      }
      
      const words = this.pinyinDict[this.pinyinInput] || []
      this.candidates = words.slice(0, 9)
    },
    selectCandidate(word) {
      this.addChar(word)
      this.clearPinyin()
    },
    confirmPinyin() {
      if (this.pinyinInput && this.candidates.length > 0) {
        this.addChar(this.candidates[0])
      } else if (this.pinyinInput) {
        // 如果是纯字母，直接输出
        this.addChar(this.pinyinInput)
      }
      this.clearPinyin()
    },
    clearPinyin() {
      this.pinyinInput = ''
      this.candidates = []
      clearTimeout(this.inputTimeout)
    },
    handleKey9Click(key) {
      if (key >= '2' && key <= '9') {
        const letters = this.key9Letters[key]
        if (letters) {
          this.addPinyinChar(letters.charAt(0))
        }
      } else if (key === '1') {
        this.confirmPinyin()
      }
    },
    get9KeyLetters(key) {
      return this.key9Letters[key] || ''
    },
    togglePunctuation() {
      this.showPunctuation = !this.showPunctuation
    },
    addPunctuation(p) {
      this.addChar(p)
      this.showPunctuation = false
    },
    handleSpace() {
      this.confirmPinyin()
      this.addChar(' ')
    },
    handleDelete() {
      if (this.pinyinInput.length > 0) {
        this.pinyinInput = this.pinyinInput.slice(0, -1)
        this.updateCandidates()
      } else if (this.inputText.length > 0) {
        this.$emit('input', this.inputText.slice(0, -1))
        this.$emit('change', this.inputText.slice(0, -1))
      }
    },
    addChar(char) {
      const newValue = this.inputText + char
      this.$emit('input', newValue)
      this.$emit('change', newValue)
    },
    submitText() {
      if (this.inputText.trim()) {
        this.$emit('submit', this.inputText)
        this.$emit('input', '')
        this.$emit('change', '')
      }
    },
    getKeyLabel(key) {
      const labels = {
        'space': '空格',
        'delete': '⌫',
        'shift': this.isShift ? 'abc' : 'ABC',
        'return': '发送'
      }
      if (labels[key]) return labels[key]
      return this.isShift ? key.toUpperCase() : key
    },
    isFunctionKey(key) {
      return ['space', 'delete', 'shift', 'return'].includes(key)
    },
    toggleEraser() {
      this.isEraser = !this.isEraser
    },
    clearCanvas() {
      const canvas = this.$refs.canvas
      if (this.ctx) {
        this.ctx.clearRect(0, 0, canvas.width, canvas.height)
      }
      this.strokeHistory = []
    },
    initCanvas() {
      const canvas = this.$refs.canvas
      if (!canvas) return
      
      const dpr = window.devicePixelRatio || 1
      const rect = canvas.getBoundingClientRect()
      
      canvas.width = rect.width * dpr
      canvas.height = rect.height * dpr
      
      this.ctx = canvas.getContext('2d')
      this.ctx.scale(dpr, dpr)
      this.ctx.strokeStyle = '#333'
      this.ctx.lineWidth = 3
      this.ctx.lineCap = 'round'
      this.ctx.lineJoin = 'round'
    },
    getCanvasPos(e) {
      const canvas = this.$refs.canvas
      const rect = canvas.getBoundingClientRect()
      return {
        x: e.clientX - rect.left,
        y: e.clientY - rect.top
      }
    },
    startDraw(e) {
      this.isDrawing = true
      const pos = this.getCanvasPos(e)
      this.lastX = pos.x
      this.lastY = pos.y
    },
    draw(e) {
      if (!this.isDrawing) return
      const pos = this.getCanvasPos(e)
      
      if (this.isEraser) {
        this.ctx.globalCompositeOperation = 'destination-out'
        this.ctx.beginPath()
        this.ctx.arc(pos.x, pos.y, 15, 0, Math.PI * 2)
        this.ctx.fill()
        this.ctx.globalCompositeOperation = 'source-over'
      } else {
        this.ctx.beginPath()
        this.ctx.moveTo(this.lastX, this.lastY)
        this.ctx.lineTo(pos.x, pos.y)
        this.ctx.stroke()
      }
      
      this.lastX = pos.x
      this.lastY = pos.y
    },
    endDraw() {
      this.isDrawing = false
    },
    startDrawTouch(e) {
      const touch = e.touches[0]
      const canvas = this.$refs.canvas
      const rect = canvas.getBoundingClientRect()
      this.lastX = touch.clientX - rect.left
      this.lastY = touch.clientY - rect.top
      this.isDrawing = true
    },
    drawTouch(e) {
      if (!this.isDrawing) return
      const touch = e.touches[0]
      const canvas = this.$refs.canvas
      const rect = canvas.getBoundingClientRect()
      const x = touch.clientX - rect.left
      const y = touch.clientY - rect.top
      
      if (this.isEraser) {
        this.ctx.globalCompositeOperation = 'destination-out'
        this.ctx.beginPath()
        this.ctx.arc(x, y, 15, 0, Math.PI * 2)
        this.ctx.fill()
        this.ctx.globalCompositeOperation = 'source-over'
      } else {
        this.ctx.beginPath()
        this.ctx.moveTo(this.lastX, this.lastY)
        this.ctx.lineTo(x, y)
        this.ctx.stroke()
      }
      
      this.lastX = x
      this.lastY = y
    },
    confirmHandwriting() {
      const mockTexts = ['你好', '天气', '健康', '谢谢', '再见']
      const randomText = mockTexts[Math.floor(Math.random() * mockTexts.length)]
      
      if (confirm(`识别结果: "${randomText}"\n\n是否使用？`)) {
        this.addChar(randomText)
        this.clearCanvas()
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.keyboard-container {
  background-color: #D1D5DB;
  padding: 8px;
  border-radius: 12px 12px 0 0;
}

.keyboard-tabs {
  display: flex;
  margin-bottom: 8px;
  gap: 8px;
}

.keyboard-tab {
  flex: 1;
  padding: 10px;
  text-align: center;
  background-color: #FFFFFF;
  border-radius: 8px;
  font-size: 16px;
  color: #666;
  cursor: pointer;
  
  &--active {
    background-color: #3792ED;
    color: #FFFFFF;
  }
}

.candidate-area {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  background-color: #FFFFFF;
  border-radius: 8px;
  padding: 8px;
  margin-bottom: 8px;
  min-height: 44px;
}

.candidate-input {
  display: flex;
  align-items: center;
  padding: 6px 12px;
  background-color: #E8F4FD;
  border-radius: 6px;
  margin-right: 8px;
  
  &__text {
    font-size: 18px;
    color: #3792ED;
    font-weight: 600;
  }
  
  &__clear {
    margin-left: 8px;
    color: #999;
    cursor: pointer;
    font-size: 14px;
  }
}

.candidate-word {
  padding: 6px 12px;
  margin: 4px;
  background-color: #F5F5F5;
  border-radius: 6px;
  font-size: 18px;
  cursor: pointer;
  
  &:active {
    background-color: #3792ED;
    color: #FFFFFF;
  }
}

.candidate-empty {
  font-size: 14px;
  color: #999;
  padding: 8px;
}

.keyboard-26key {
  background-color: #D1D5DB;
  padding: 4px;
  border-radius: 8px;
}

.keyboard-row {
  display: flex;
  justify-content: center;
  margin-bottom: 6px;
  
  &:last-child {
    margin-bottom: 0;
  }
}

.key-26 {
  width: 32px;
  height: 48px;
  display: flex;
  justify-content: center;
  align-items: center;
  margin: 0 2px;
  background-color: #FFFFFF;
  border-radius: 6px;
  font-size: 18px;
  font-weight: 600;
  color: #333;
  cursor: pointer;
  user-select: none;
  
  &:active {
    background-color: #9CA3AF;
  }
  
  &--space {
    width: 180px;
  }
  
  &--function {
    background-color: #A8A8A8;
    font-size: 14px;
  }
  
  &--active {
    background-color: #3792ED !important;
    color: #FFFFFF !important;
  }
  
  &--punctuation {
    width: auto;
    min-width: 28px;
    padding: 0 6px;
  }
}

.keyboard-9key {
  background-color: #D1D5DB;
  padding: 4px;
  border-radius: 8px;
}

.key-9 {
  width: 32%;
  height: 52px;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  margin: 0 2px;
  background-color: #FFFFFF;
  border-radius: 8px;
  cursor: pointer;
  user-select: none;
  
  &:active {
    background-color: #9CA3AF;
  }
  
  &--function {
    width: 32%;
    background-color: #A8A8A8;
    font-size: 16px;
  }
  
  &--delete {
    font-size: 14px;
  }
  
  &__number {
    font-size: 22px;
    font-weight: bold;
    color: #333;
  }
  
  &__letters {
    font-size: 12px;
    color: #666;
  }
}

.keyboard-handwriting {
  background-color: #FFFFFF;
  border-radius: 8px;
  padding: 8px;
}

.handwriting-canvas {
  width: 100%;
  height: 160px;
  background-color: #F9F9F9;
  border: 2px dashed #CCC;
  border-radius: 8px;
  touch-action: none;
}

.handwriting-tools {
  display: flex;
  gap: 12px;
  margin-top: 8px;
}

.handwriting-btn {
  flex: 1;
  padding: 12px;
  text-align: center;
  background-color: #F5F5F5;
  border-radius: 8px;
  font-size: 16px;
  cursor: pointer;
  
  &:active {
    transform: scale(0.95);
  }
  
  &--active {
    background-color: #F39C12;
    color: #FFFFFF;
  }
  
  &--confirm {
    background-color: #3792ED;
    color: #FFFFFF;
  }
}
</style>
