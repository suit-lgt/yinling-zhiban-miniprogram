<template>
  <div class="candidate-area" :class="{ 'candidate-area--empty': !pinyin && candidates.length === 0 }">
    <!-- 拼音输入显示 -->
    <div class="candidate-pinyin" v-if="pinyin">
      <span class="candidate-pinyin__text">{{ pinyin }}</span>
      <span class="candidate-pinyin__clear" @click="handleClear">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <line x1="18" y1="6" x2="6" y2="18"></line>
          <line x1="6" y1="6" x2="18" y2="18"></line>
        </svg>
      </span>
    </div>

    <!-- 候选词列表 -->
    <div class="candidate-list" ref="candidateList">
      <div 
        class="candidate-word" 
        v-for="(word, index) in displayCandidates" 
        :key="index"
        @click="handleSelect(word)"
      >
        {{ word }}
      </div>
    </div>

    <!-- 页码指示器 -->
    <div class="candidate-page" v-if="totalPages > 1">
      <span class="candidate-page__current">{{ currentPage }}</span>
      <span class="candidate-page__separator">/</span>
      <span class="candidate-page__total">{{ totalPages }}</span>
    </div>

    <!-- 空状态提示 -->
    <div class="candidate-empty" v-if="!pinyin && candidates.length === 0">
      {{ placeholder }}
    </div>
  </div>
</template>

<script>
export default {
  name: 'yl-candidate',
  props: {
    value: {
      type: String,
      default: ''
    },
    candidates: {
      type: Array,
      default: () => []
    },
    placeholder: {
      type: String,
      default: '点击字母输入拼音'
    },
    pageSize: {
      type: Number,
      default: 9
    }
  },
  data() {
    return {
      currentPage: 1
    }
  },
  computed: {
    pinyin() {
      return this.value
    },
    totalPages() {
      return Math.ceil(this.candidates.length / this.pageSize)
    },
    displayCandidates() {
      const start = (this.currentPage - 1) * this.pageSize
      const end = start + this.pageSize
      return this.candidates.slice(start, end)
    }
  },
  watch: {
    candidates: {
      handler() {
        this.currentPage = 1
      }
    },
    value: {
      handler() {
        this.currentPage = 1
      }
    }
  },
  methods: {
    handleSelect(word) {
      this.$emit('select', word)
    },
    handleClear() {
      this.$emit('clear')
    },
    nextPage() {
      if (this.currentPage < this.totalPages) {
        this.currentPage++
      } else {
        this.currentPage = 1
      }
    },
    prevPage() {
      if (this.currentPage > 1) {
        this.currentPage--
      } else {
        this.currentPage = this.totalPages
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.candidate-area {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  background-color: var(--kb-candidate-bg, #E8F4FD);
  border-radius: var(--kb-key-radius, 8px);
  padding: 8px 12px;
  margin-bottom: 8px;
  min-height: 52px;
  position: relative;

  &--empty {
    justify-content: center;
  }
}

.candidate-pinyin {
  display: flex;
  align-items: center;
  padding: 6px 12px;
  background-color: var(--kb-pinyin-bg, #D0E8FA);
  border-radius: 6px;
  margin-right: 8px;

  &__text {
    font-size: var(--kb-font-size, 20px);
    font-weight: 600;
    color: var(--kb-pinyin-text, #3792ED);
  }

  &__clear {
    margin-left: 8px;
    color: var(--kb-tab-text, #999);
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 2px;
    border-radius: 50%;
    transition: all 0.2s;

    &:hover {
      background-color: rgba(0, 0, 0, 0.1);
    }

    &:active {
      transform: scale(0.9);
    }
  }
}

.candidate-list {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  flex: 1;
  gap: 4px;
}

.candidate-word {
  padding: 8px 14px;
  margin: 2px;
  background-color: var(--kb-key-bg, #FFFFFF);
  border-radius: 6px;
  font-size: var(--kb-font-size, 20px);
  color: var(--kb-text-primary, #333);
  cursor: pointer;
  transition: all 0.15s ease;
  user-select: none;

  &:hover {
    background-color: var(--kb-candidate-selected, #D0E8FA);
  }

  &:active {
    transform: scale(0.95);
    background-color: var(--kb-accent, #3792ED);
    color: var(--kb-tab-active-text, #FFFFFF);
  }
}

.candidate-page {
  position: absolute;
  right: 12px;
  bottom: 8px;
  display: flex;
  align-items: center;
  font-size: 14px;
  color: var(--kb-tab-text, #999);

  &__current {
    color: var(--kb-accent, #3792ED);
    font-weight: 600;
  }

  &__separator {
    margin: 0 2px;
  }

  &__total {
    color: var(--kb-tab-text, #999);
  }
}

.candidate-empty {
  font-size: 16px;
  color: var(--kb-tab-text, #999);
  text-align: center;
  width: 100%;
}
</style>
