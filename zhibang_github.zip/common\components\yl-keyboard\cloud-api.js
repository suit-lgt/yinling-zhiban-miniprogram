/**
 * 云端API封装 - 银龄智伴键盘
 * 提供词库同步、候选词搜索等功能
 */

class CloudAPI {
  constructor() {
    // API配置
    this.config = {
      baseURL: 'https://api.yinling-zhiban.com/v1', // 实际使用时替换为真实API地址
      timeout: 5000,
      cacheTime: 86400000, // 24小时缓存
      storageKey: 'yl-keyboard-cloud-vocab',
      versionKey: 'yl-keyboard-cloud-version'
    }

    // 缓存的词库数据
    this.cachedVocab = new Map()
    
    // 当前词库版本
    this.currentVersion = ''

    // 加载缓存数据
    this.loadCache()
  }

  /**
   * 加载本地缓存
   */
  loadCache() {
    try {
      const stored = localStorage.getItem(this.config.storageKey)
      const version = localStorage.getItem(this.config.versionKey)
      
      if (stored) {
        const data = JSON.parse(stored)
        const now = Date.now()
        
        // 检查缓存是否过期
        if (now - data.timestamp < this.config.cacheTime) {
          this.cachedVocab = new Map(Object.entries(data.vocab || {}))
          this.currentVersion = data.version || ''
        }
      }
    } catch (e) {
      console.warn('加载云端词库缓存失败:', e)
    }
  }

  /**
   * 保存缓存
   */
  saveCache() {
    try {
      const data = {
        vocab: Object.fromEntries(this.cachedVocab),
        version: this.currentVersion,
        timestamp: Date.now()
      }
      localStorage.setItem(this.config.storageKey, JSON.stringify(data))
      localStorage.setItem(this.config.versionKey, this.currentVersion)
    } catch (e) {
      console.warn('保存云端词库缓存失败:', e)
    }
  }

  /**
   * 同步词库
   * @param {string} currentVersion 当前版本号
   * @returns {Promise<{hasUpdate: boolean, words: Array}>}
   */
  async syncVocab(currentVersion = '') {
    try {
      // 模拟API请求（实际使用时替换为真实API调用）
      const response = await this.mockSyncRequest(currentVersion)
      
      if (response.hasUpdate) {
        // 更新缓存
        for (const item of response.words) {
          if (item.pinyin && item.word) {
            this.cachedVocab.set(item.pinyin, item.word)
          }
        }
        this.currentVersion = response.version
        this.saveCache()
      }
      
      return response
    } catch (error) {
      console.error('词库同步失败:', error)
      return { hasUpdate: false, words: [], version: currentVersion }
    }
  }

  /**
   * 模拟同步请求（实际使用时替换为真实API调用）
   * @param {string} currentVersion 当前版本
   * @returns {Promise<Object>}
   */
  async mockSyncRequest(currentVersion) {
    // 模拟延迟
    await new Promise(resolve => setTimeout(resolve, 100))

    // 示例云端词库数据（实际使用时从服务器获取）
    const cloudWords = [
      { pinyin: 'tianq', word: '天气', freq: 950 },
      { pinyin: 'tianq', word: '天晴', freq: 800 },
      { pinyin: 'tianq', word: '天前', freq: 600 },
      { pinyin: 'jiank', word: '健康', freq: 900 },
      { pinyin: 'jiank', word: '监控', freq: 500 },
      { pinyin: 'yibao', word: '医保', freq: 850 },
      { pinyin: 'yibao', word: '预报', freq: 700 },
      { pinyin: 'feich', word: '非常', freq: 950 },
      { pinyin: 'zhongy', word: '重要', freq: 900 },
      { pinyin: 'zhongy', word: '中医', freq: 750 },
      { pinyin: 'yuany', word: '原因', freq: 850 },
      { pinyin: 'yuany', word: '愿意', freq: 600 },
      { pinyin: 'bingli', word: '病例', freq: 800 },
      { pinyin: 'bingli', word: '病历', freq: 700 },
      { pinyin: 'zhend', word: '诊断', freq: 850 },
      { pinyin: 'zhend', word: '真的', freq: 600 },
      { pinyin: 'zhend', word: '震动', freq: 500 },
      { pinyin: 'zhiliao', word: '治疗', freq: 900 },
      { pinyin: 'yaodian', word: '药店', freq: 850 },
      { pinyin: 'yisheng', word: '医生', freq: 950 },
      { pinyin: 'hushi', word: '护士', freq: 900 },
      { pinyin: 'tijian', word: '体检', freq: 850 },
      { pinyin: 'baojian', word: '保健', freq: 800 },
      { pinyin: 'yangsheng', word: '养生', freq: 750 },
      { pinyin: 'yundong', word: '运动', freq: 900 },
      { pinyin: 'duanlian', word: '锻炼', freq: 850 },
      { pinyin: 'yinse', word: '饮食', freq: 800 },
      { pinyin: 'shuijiao', word: '睡觉', freq: 900 },
      { pinyin: 'xiuxi', word: '休息', freq: 850 },
      { pinyin: 'fangxin', word: '放心', freq: 700 },
      { pinyin: 'fangxin', word: '防锈', freq: 300 },
      { pinyin: 'zhuyi', word: '主意', freq: 700 },
      { pinyin: 'zhuyi', word: '注意', freq: 800 },
      { pinyin: 'zhidao', word: '知道', freq: 950 },
      { pinyin: 'mingbai', word: '明白', freq: 900 },
      { pinyin: 'zhidao', word: '指导', freq: 700 },
      { pinyin: 'bangzhu', word: '帮助', freq: 900 },
      { pinyin: 'xiaoyao', word: '逍遥', freq: 500 },
      { pinyin: 'xiaoyao', word: '小药', freq: 400 },
      { pinyin: 'kaixin', word: '开心', freq: 850 },
      { pinyin: 'ganga', word: '尴尬', freq: 600 },
      { pinyin: 'tongyi', word: '同意', freq: 850 },
      { pinyin: 'tongyi', word: '统一', freq: 700 },
      { pinyin: 'butong', word: '不同', freq: 850 },
      { pinyin: 'butong', word: '不通', freq: 400 },
      { pinyin: 'hela', word: '和啦', freq: 200 },
      { pinyin: 'henhao', word: '很好', freq: 950 },
      { pinyin: 'feichang', word: '非常', freq: 950 },
      { pinyin: 'zhende', word: '真的', freq: 900 },
      { pinyin: 'shizai', word: '实在', freq: 800 },
      { pinyin: 'shizai', word: '是在', freq: 600 },
      { pinyin: 'bushihao', word: '不是好', freq: 500 },
      { pinyin: 'zenmeban', word: '怎么办', freq: 850 },
      { pinyin: 'zenmeyang', word: '怎么样', freq: 850 },
      { pinyin: 'zhendefu', word: '真的吗', freq: 900 },
      { pinyin: 'qingwen', word: '请问', freq: 950 },
      { pinyin: 'duibuqi', word: '对不起', freq: 900 },
      { pinyin: 'ganxie', word: '感谢', freq: 900 },
      { pinyin: 'zhidao', word: '知道', freq: 950 },
      { pinyin: 'bushihao', word: '不好', freq: 600 },
      { pinyin: 'hennan', word: '很难', freq: 700 },
      { pinyin: 'henjiandan', word: '很简单', freq: 800 },
      { pinyin: 'jintian', word: '今天', freq: 950 },
      { pinyin: 'mingtian', word: '明天', freq: 950 },
      { pinyin: 'zuotian', word: '昨天', freq: 900 },
      { pinyin: 'houtian', word: '后天', freq: 850 },
      { pinyin: 'xianzai', word: '现在', freq: 950 },
      { pinyin: 'yihou', word: '以后', freq: 900 },
      { pinyin: 'yihou', word: '以后', freq: 900 },
      { pinyin: 'zaowan', word: '早晚', freq: 800 },
      { pinyin: 'zaoshang', word: '早上', freq: 900 },
      { pinyin: 'wanshang', word: '晚上', freq: 900 },
      { pinyin: 'zhongwu', word: '中午', freq: 850 },
      { pinyin: 'xiawu', word: '下午', freq: 850 },
      { pinyin: 'wendu', word: '温度', freq: 850 },
      { pinyin: 'tianqi', word: '天气', freq: 950 },
      { pinyin: 'yubao', word: '预报', freq: 850 },
      { pinyin: 'qing', word: '晴', freq: 700 },
      { pinyin: 'yu', word: '雨', freq: 800 },
      { pinyin: 'xue', word: '雪', freq: 700 },
      { pinyin: 'feng', word: '风', freq: 700 },
      { pinyin: 'wu', word: '雾', freq: 600 },
      { pinyin: 'le', word: '了', freq: 900 },
      { pinyin: 'de', word: '的', freq: 950 },
      { pinyin: 'shi', word: '是', freq: 950 },
      { pinyin: 'zai', word: '在', freq: 950 },
      { pinyin: 'you', word: '有', freq: 950 },
      { pinyin: 'wo', word: '我', freq: 950 },
      { pinyin: 'ni', word: '你', freq: 950 },
      { pinyin: 'ta', word: '他', freq: 900 },
      { pinyin: 'ta', word: '她', freq: 900 },
      { pinyin: 'ta', word: '它', freq: 900 },
      { pinyin: 'women', word: '我们', freq: 950 },
      { pinyin: 'nimen', word: '你们', freq: 900 },
      { pinyin: 'tamen', word: '他们', freq: 900 },
      { pinyin: 'jia', word: '家', freq: 900 },
      { pinyin: 'zheli', word: '这里', freq: 900 },
      { pinyin: 'nali', word: '哪里', freq: 850 },
      { pinyin: 'zenme', word: '怎么', freq: 900 },
      { pinyin: 'shenme', word: '什么', freq: 900 },
      { pinyin: 'duoshao', word: '多少', freq: 850 },
      { pinyin: 'haobujia', word: '好不好', freq: 850 },
      { pinyin: 'keyi', word: '可以', freq: 900 },
      { pinyin: 'bujian', word: '不见', freq: 700 },
      { pinyin: 'bushao', word: '不少', freq: 700 },
      { pinyin: 'zhidaole', word: '知道了', freq: 900 },
      { pinyin: 'tingdong', word: '挺懂', freq: 600 },
      { pinyin: 'tingle', word: '挺了', freq: 600 },
      { pinyin: 'shengri', word: '生日', freq: 850 },
      { pinyin: 'kuaile', word: '快乐', freq: 900 },
      { pinyin: 'jiankang', word: '健康', freq: 950 },
      { pinyin: 'pingan', word: '平安', freq: 850 },
      { pinyin: 'xingfu', word: '幸福', freq: 850 },
      { pinyin: 'changming', word: '长命', freq: 700 },
      { pinyin: 'changshou', word: '长寿', freq: 800 },
      { pinyin: 'gongzuo', word: '工作', freq: 850 },
      { pinyin: 'shenghuo', word: '生活', freq: 900 },
      { pinyin: 'xuexi', word: '学习', freq: 850 },
      { pinyin: 'lianxi', word: '练习', freq: 750 },
      { pinyin: 'dianhua', word: '电话', freq: 900 },
      { pinyin: 'shouji', word: '手机', freq: 900 },
      { pinyin: 'wangluo', word: '网络', freq: 850 },
      { pinyin: 'xinwen', word: '新闻', freq: 850 },
      { pinyin: 'shijian', word: '时间', freq: 950 },
      { pinyin: 'kongjian', word: '空间', freq: 750 },
      { pinyin: 'bangzhu', word: '帮助', freq: 900 },
      { pinyin: 'zhidao', word: '知道', freq: 950 },
      { pinyin: 'zhidao', word: '指导', freq: 750 },
    ]

    const version = '1.0.0'

    return {
      hasUpdate: version !== currentVersion,
      words: cloudWords,
      version: version
    }
  }

  /**
   * 搜索候选词
   * @param {string} pinyin 拼音
   * @returns {Promise<Array>}
   */
  async search(pinyin) {
    if (!pinyin) return []

    const pinyinLower = pinyin.toLowerCase()

    // 先从缓存搜索
    if (this.cachedVocab.has(pinyinLower)) {
      return this.cachedVocab.get(pinyinLower)
    }

    // 模拟API搜索（实际使用时从服务器获取）
    try {
      await new Promise(resolve => setTimeout(resolve, 50))
      // 返回空，实际应该从服务器获取
      return []
    } catch (error) {
      console.error('搜索候选词失败:', error)
      return []
    }
  }

  /**
   * 获取热词
   * @returns {Promise<Array>}
   */
  async getHotWords() {
    // 模拟API请求
    await new Promise(resolve => setTimeout(resolve, 50))

    return [
      '天气', '健康', '医保', '医生', '医院',
      '吃药', '运动', '体检', '平安', '快乐'
    ]
  }

  /**
   * 获取缓存数据
   * @returns {Map}
   */
  getCachedVocab() {
    return this.cachedVocab
  }

  /**
   * 清除缓存
   */
  clearCache() {
    this.cachedVocab.clear()
    localStorage.removeItem(this.config.storageKey)
    localStorage.removeItem(this.config.versionKey)
  }

  /**
   * 获取当前版本
   * @returns {string}
   */
  getVersion() {
    return this.currentVersion
  }
}

// 单例模式
let instance = null

export function getCloudAPI() {
  if (!instance) {
    instance = new CloudAPI()
  }
  return instance
}

export default CloudAPI
