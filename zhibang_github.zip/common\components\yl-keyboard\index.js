/**
 * 银龄智伴键盘组件 - 搜狗风格输入法
 * 
 * @description 
 * 基于uni-app (Vue 2) 开发的老年人友好型智能输入法键盘
 * 参考搜狗输入法核心功能：智能联想、中英文混合、Emoji、符号等
 * 
 * @features
 * - 26键全键盘输入
 * - 9键拼音输入
 * - 智能拼音联想（云端+本地混合词库）
 * - 用户词频学习
 * - Emoji表情键盘（7类精简分类）
 * - 数字符号键盘
 * - 浅色/深色双主题
 * 
 * @author 银龄智伴开发团队
 * @version 1.0.0
 */

// 主面板组件
export { default as Panel } from './panel.vue'

// 26键键盘组件
export { default as Keyboard26 } from './keyboard-26.vue'

// 9键键盘组件
export { default as Keyboard9 } from './keyboard-9.vue'

// 符号键盘组件
export { default as KeyboardSymbol } from './keyboard-symbol.vue'

// Emoji键盘组件
export { default as KeyboardEmoji } from './keyboard-emoji.vue'

// 候选词组件
export { default as Candidate } from './candidate.vue'

// 拼音引擎
export { getPinyinEngine, default as PinyinEngine } from './pinyin-engine.js'

// 云端API
export { getCloudAPI, default as CloudAPI } from './cloud-api.js'

// 版本信息
export const VERSION = '1.0.0'

// 组件名称映射
export const KeyboardComponents = {
  Panel: 'yl-keyboard-panel',
  Keyboard26: 'yl-keyboard-26',
  Keyboard9: 'yl-keyboard-9',
  KeyboardSymbol: 'yl-keyboard-symbol',
  KeyboardEmoji: 'yl-keyboard-emoji',
  Candidate: 'yl-candidate'
}

// 键盘类型
export const KeyboardTypes = {
  KEYBOARD_26: '26key',
  KEYBOARD_9: '9key',
  SYMBOL: 'symbol',
  EMOJI: 'emoji'
}

// 主题类型
export const ThemeTypes = {
  LIGHT: 'light',
  DARK: 'dark',
  AUTO: 'auto'
}

// 安装函数（用于Vue.use）
export function install(Vue) {
  // 注册所有组件
  Vue.component('yl-keyboard-panel', require('./panel.vue').default)
  Vue.component('yl-keyboard-26', require('./keyboard-26.vue').default)
  Vue.component('yl-keyboard-9', require('./keyboard-9.vue').default)
  Vue.component('yl-keyboard-symbol', require('./keyboard-symbol.vue').default)
  Vue.component('yl-keyboard-emoji', require('./keyboard-emoji.vue').default)
  Vue.component('yl-candidate', require('./candidate.vue').default)
}

// 默认导出主面板
export default {
  install,
  VERSION,
  KeyboardComponents,
  KeyboardTypes,
  ThemeTypes
}
