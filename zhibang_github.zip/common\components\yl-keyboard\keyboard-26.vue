<template>
  <div class="keyboard-26">
    <!-- 候选词区域 -->
    <div class="keyboard-candidate">
      <slot name="candidate">
        <yl-candidate
          :value="pinyinInput"
          :candidates="candidates"
          @select="handleCandidateSelect"
          @clear="handleCandidateClear"
        />
      </slot>
    </div>

    <!-- 键盘主体 -->
    <div class="keyboard-body">
      <!-- 第一行：q w e r t y u i o p -->
      <div class="keyboard-row">
        <div 
          v-for="key in row1" 
          :key="key"
          class="key-26"
          :class="getKeyClass(key)"
          @click="handleKeyClick(key)"
          @touchstart.prevent="handleTouchStart(key)"
          @touchend.prevent="handleTouchEnd(key)"
          @mousedown="handleMouseDown(key)"
          @mouseup="handleMouseUp(key)"
          @mouseleave="handleMouseUp(key)"
        >
          <span class="key-26__label">{{ getKeyLabel(key) }}</span>
        </div>
      </div>

      <!-- 第二行：a s d f g h j k l -->
      <div class="keyboard-row">
        <div 
          v-for="key in row2" 
          :key="key"
          class="key-26"
          :class="getKeyClass(key)"
          @click="handleKeyClick(key)"
          @touchstart.prevent="handleTouchStart(key)"
          @touchend.prevent="handleTouchEnd(key)"
          @mousedown="handleMouseDown(key)"
          @mouseup="handleMouseUp(key)"
          @mouseleave="handleMouseUp(key)"
        >
          <span class="key-26__label">{{ getKeyLabel(key) }}</span>
        </div>
      </div>

      <!-- 第三行：shift z x c v b n m delete -->
      <div class="keyboard-row">
        <div 
          class="key-26 key-26--function"
          :class="{ 'key-26--active': isShift }"
          @click="handleShift"
          @touchstart.prevent="handleTouchStart('shift')"
          @touchend.prevent="handleTouchEnd('shift')"
        >
          <span class="key-26__label">{{ isShift ? 'ABC' : '⇧' }}</span>
        </div>
        <div 
          v-for="key in row3" 
          :key="key"
          class="key-26"
          :class="getKeyClass(key)"
          @click="handleKeyClick(key)"
          @touchstart.prevent="handleTouchStart(key)"
          @touchend.prevent="handleTouchEnd(key)"
          @mousedown="handleMouseDown(key)"
          @mouseup="handleMouseUp(key)"
          @mouseleave="handleMouseUp(key)"
        >
          <span class="key-26__label">{{ getKeyLabel(key) }}</span>
        </div>
        <div 
          class="key-26 key-26--function key-26--delete"
          :class="{ 'key-26--deleting': isDeleting }"
          @click="handleDelete"
          @touchstart.prevent="handleDeleteTouchStart"
          @touchend.prevent="handleDeleteTouchEnd"
        >
          <span class="key-26__label">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M21 4H8l-7 8 7 8h13a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2z"></path>
              <line x1="18" y1="9" x2="12" y2="15"></line>
              <line x1="12" y1="9" x2="18" y2="15"></line>
            </svg>
          </span>
        </div>
      </div>

      <!-- 第四行：数字 符号 emoji 空格 发送 -->
      <div class="keyboard-row">
        <div 
          class="key-26 key-26--function key-26--tool"
          @click="handleSwitchTo('symbol')"
        >
          <span class="key-26__label">123</span>
        </div>
        <div 
          class="key-26 key-26--function key-26--tool"
          @click="handleSwitchTo('emoji')"
        >
          <span class="key-26__icon">😀</span>
        </div>
        <div 
          class="key-26 key-26--function key-26--tool"
          @click="handleSwitchTo('9key')"
        >
          <span class="key-26__label">9键</span>
        </div>
        <div 
          class="key-26 key-26--space"
          @click="handleSpace"
          @touchstart.prevent="handleTouchStart('space')"
          @touchend.prevent="handleTouchEnd('space')"
        >
          <span class="key-26__label">空格</span>
        </div>
        <div 
          class="key-26 key-26--function key-26--return"
          :class="{ 'key-26--active': hasInput }"
          @click="handleReturn"
        >
          <span class="key-26__label">{{ hasInput ? '发送' : '换行' }}</span>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import ylCandidate from './candidate.vue'
import { getPinyinEngine } from './pinyin-engine.js'

export default {
  name: 'yl-keyboard-26',
  components: {
    ylCandidate
  },
  props: {
    value: {
      type: String,
      default: ''
    }
  },
  data() {
    return {
      // 按键行
      row1: ['q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p'],
      row2: ['a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l'],
      row3: ['z', 'x', 'c', 'v', 'b', 'n', 'm'],
      
      // 状态
      isShift: false,
      shiftLock: false,
      pinyinInput: '',
      candidates: [],
      
      // 长按删除
      isDeleting: false,
      deleteInterval: null,
      deleteTimeout: null,
      
      // 触摸状态
      touchTimer: null,
      
      // 拼音引擎
      pinyinEngine: null
    }
  },
  computed: {
    inputText() {
      return this.value || ''
    },
    hasInput() {
      return this.inputText.trim().length > 0
    }
  },
  watch: {
    value: {
      immediate: true,
      handler(newVal) {
        this.internalText = newVal || ''
      }
    }
  },
  created() {
    this.pinyinEngine = getPinyinEngine()
  },
  beforeDestroy() {
    this.clearDeleteTimer()
  },
  methods: {
    // 获取按键样式类
    getKeyClass(key) {
      const classes = []
      if (['space'].includes(key)) {
        classes.push('key-26--space')
      }
      if (['shift', 'delete', 'space', 'return'].includes(key)) {
        classes.push('key-26--function')
      }
      if (key === 'shift' && this.isShift) {
        classes.push('key-26--active')
      }
      return classes.join(' ')
    },

    // 获取按键标签
    getKeyLabel(key) {
      if (this.isShift && /^[a-z]$/.test(key)) {
        return key.toUpperCase()
      }
      
      const labels = {
        'space': '空格',
        'delete': '⌫',
        'shift': this.isShift ? 'ABC' : '⇧'
      }
      
      return labels[key] || key
    },

    // 按键点击处理
    handleKeyClick(key) {
      if (this.isShift && !this.shiftLock && /^[a-z]$/.test(key)) {
        // 单击Shift后输入一个大写字母
        const char = key.toUpperCase()
        this.addPinyinChar(char)
        this.isShift = false
      } else if (/^[a-z]$/.test(key)) {
        this.addPinyinChar(key)
      }
    },

    // 添加拼音字符
    addPinyinChar(char) {
      this.pinyinInput += char
      this.updateCandidates()
      
      // 自动确认（1.5秒无输入）
      clearTimeout(this.autoConfirmTimer)
      this.autoConfirmTimer = setTimeout(() => {
        this.confirmPinyin()
      }, 1500)
    },

    // 更新候选词
    updateCandidates() {
      if (!this.pinyinInput) {
        this.candidates = []
        return
      }
      
      this.candidates = this.pinyinEngine.search(this.pinyinInput)
    },

    // 选择候选词
    handleCandidateSelect(word) {
      this.addChar(word)
      this.clearPinyin()
    },

    // 清除拼音输入
    handleCandidateClear() {
      this.clearPinyin()
    },

    // 清除拼音
    clearPinyin() {
      this.pinyinInput = ''
      this.candidates = []
      clearTimeout(this.autoConfirmTimer)
    },

    // 确认拼音并输入
    confirmPinyin() {
      if (this.pinyinInput && this.candidates.length > 0) {
        this.addChar(this.candidates[0])
      } else if (this.pinyinInput) {
        // 如果是纯英文字母，直接输出
        this.addChar(this.pinyinInput)
      }
      this.clearPinyin()
    },

    // 添加字符
    addChar(char) {
      const newValue = this.inputText + char
      this.$emit('input', newValue)
      this.$emit('change', newValue)
      
      // 更新用户词频
      if (char.length === 1 && /[\u4e00-\u9fa5]/.test(char)) {
        this.pinyinEngine.increaseFrequency(char)
      } else if (char.length > 1) {
        this.pinyinEngine.increaseFrequency(char)
      }
    },

    // Shift切换
    handleShift() {
      this.isShift = !this.isShift
      this.shiftLock = this.isShift
    },

    // 删除处理
    handleDelete() {
      if (this.pinyinInput.length > 0) {
        this.pinyinInput = this.pinyinInput.slice(0, -1)
        this.updateCandidates()
      } else if (this.inputText.length > 0) {
        const newValue = this.inputText.slice(0, -1)
        this.$emit('input', newValue)
        this.$emit('change', newValue)
      }
    },

    // 长按删除开始
    handleDeleteTouchStart() {
      this.deleteTimeout = setTimeout(() => {
        this.isDeleting = true
        this.deleteInterval = setInterval(() => {
          this.handleDelete()
        }, 100)
      }, 500)
    },

    // 长按删除结束
    handleDeleteTouchEnd() {
      this.clearDeleteTimer()
    },

    // 鼠标按下（用于桌面端长按）
    handleMouseDown(key) {
      if (key === 'delete') {
        this.handleDeleteTouchStart()
      }
    },

    // 鼠标释放
    handleMouseUp(key) {
      if (key === 'delete') {
        this.handleDeleteTouchEnd()
      }
    },

    // 清除删除定时器
    clearDeleteTimer() {
      clearTimeout(this.deleteTimeout)
      clearInterval(this.deleteInterval)
      this.deleteTimeout = null
      this.deleteInterval = null
      this.isDeleting = false
    },

    // 触摸开始
    handleTouchStart(key) {
      // 预留扩展
    },

    // 触摸结束
    handleTouchEnd(key) {
      // 预留扩展
    },

    // 空格
    handleSpace() {
      this.confirmPinyin()
      this.addChar(' ')
    },

    // 发送/换行
    handleReturn() {
      if (this.hasInput) {
        this.$emit('submit', this.inputText)
        this.$emit('input', '')
        this.$emit('change', '')
        this.clearPinyin()
      } else {
        this.addChar('\n')
      }
    },

    // 切换键盘类型
    handleSwitchTo(type) {
      this.confirmPinyin()
      this.$emit('switch', type)
    }
  }
}
</script>

<style lang="scss" scoped>
.keyboard-26 {
  padding: 6px 4px;
}

.keyboard-candidate {
  margin-bottom: 6px;
}

.keyboard-body {
  background-color: var(--kb-bg, #D1D5DB);
  border-radius: var(--kb-container-radius, 12px);
  padding: 4px;
}

.keyboard-row {
  display: flex;
  justify-content: center;
  margin-bottom: 6px;

  &:last-child {
    margin-bottom: 0;
  }
}

.key-26 {
  width: var(--kb-key-size, 48px);
  height: var(--kb-key-height, 52px);
  display: flex;
  justify-content: center;
  align-items: center;
  margin: 0 2px;
  background-color: var(--kb-key-bg, #FFFFFF);
  border-radius: var(--kb-key-radius, 8px);
  font-size: var(--kb-font-size, 20px);
  font-weight: 600;
  color: var(--kb-key-text, #333333);
  cursor: pointer;
  user-select: none;
  transition: all 0.1s ease;
  box-shadow: 0 2px 4px var(--kb-key-shadow, rgba(0, 0, 0, 0.15));

  &:active {
    background-color: var(--kb-key-active, #C8C8C8);
    transform: scale(0.95);
  }

  &--function {
    background-color: var(--kb-key-function-bg, #A8A8A8);
    color: var(--kb-text-primary, #333333);

    &:active {
      background-color: var(--kb-key-active, #909090);
    }
  }

  &--space {
    width: 160px;
    font-size: 18px;
  }

  &--return {
    width: 100px;
    font-size: 18px;
    
    &.key-26--active {
      background-color: var(--kb-accent, #3792ED);
      color: var(--kb-tab-active-text, #FFFFFF);
    }
  }

  &--tool {
    width: 64px;
    font-size: 16px;
  }

  &--delete {
    width: 64px;

    svg {
      width: 22px;
      height: 22px;
    }
  }

  &--active {
    background-color: var(--kb-accent, #3792ED) !important;
    color: var(--kb-tab-active-text, #FFFFFF) !important;
  }

  &--deleting {
    background-color: var(--kb-danger, #E74C3C) !important;
    color: #FFFFFF !important;
  }

  &__label {
    display: flex;
    align-items: center;
    justify-content: center;
  }

  &__icon {
    font-size: 24px;
  }
}
</style>
