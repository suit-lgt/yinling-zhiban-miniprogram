<template>
  <div class="keyboard-9">
    <!-- 候选词区域 -->
    <div class="keyboard-candidate">
      <slot name="candidate">
        <yl-candidate
          :value="pinyinInput"
          :candidates="candidates"
          @select="handleCandidateSelect"
          @clear="handleCandidateClear"
        />
      </slot>
    </div>

    <!-- 键盘主体 -->
    <div class="keyboard-body">
      <!-- 第一行：1 2 3 -->
      <div class="keyboard-row">
        <div class="key-9 key-9--function" @click="handlePageUp">
          <span class="key-9__label">▲</span>
        </div>
        <div 
          class="key-9 key-9--number"
          :class="{ 'key-9--active': activeKey === '2' }"
          @click="handleKeyClick('2')"
        >
          <span class="key-9__number">2</span>
          <span class="key-9__letters">{{ keyLetters['2'] }}</span>
        </div>
        <div 
          class="key-9 key-9--number"
          :class="{ 'key-9--active': activeKey === '3' }"
          @click="handleKeyClick('3')"
        >
          <span class="key-9__number">3</span>
          <span class="key-9__letters">{{ keyLetters['3'] }}</span>
        </div>
      </div>

      <!-- 第二行：4 5 6 -->
      <div class="keyboard-row">
        <div 
          class="key-9 key-9--number"
          :class="{ 'key-9--active': activeKey === '4' }"
          @click="handleKeyClick('4')"
        >
          <span class="key-9__number">4</span>
          <span class="key-9__letters">{{ keyLetters['4'] }}</span>
        </div>
        <div 
          class="key-9 key-9--number"
          :class="{ 'key-9--active': activeKey === '5' }"
          @click="handleKeyClick('5')"
        >
          <span class="key-9__number">5</span>
          <span class="key-9__letters">{{ keyLetters['5'] }}</span>
        </div>
        <div 
          class="key-9 key-9--number"
          :class="{ 'key-9--active': activeKey === '6' }"
          @click="handleKeyClick('6')"
        >
          <span class="key-9__number">6</span>
          <span class="key-9__letters">{{ keyLetters['6'] }}</span>
        </div>
      </div>

      <!-- 第三行：7 8 9 -->
      <div class="keyboard-row">
        <div 
          class="key-9 key-9--number"
          :class="{ 'key-9--active': activeKey === '7' }"
          @click="handleKeyClick('7')"
        >
          <span class="key-9__number">7</span>
          <span class="key-9__letters">{{ keyLetters['7'] }}</span>
        </div>
        <div 
          class="key-9 key-9--number"
          :class="{ 'key-9--active': activeKey === '8' }"
          @click="handleKeyClick('8')"
        >
          <span class="key-9__number">8</span>
          <span class="key-9__letters">{{ keyLetters['8'] }}</span>
        </div>
        <div 
          class="key-9 key-9--number"
          :class="{ 'key-9--active': activeKey === '9' }"
          @click="handleKeyClick('9')"
        >
          <span class="key-9__number">9</span>
          <span class="key-9__letters">{{ keyLetters['9'] }}</span>
        </div>
      </div>

      <!-- 第四行：符号 空格 删除 -->
      <div class="keyboard-row">
        <div 
          class="key-9 key-9--function"
          @click="handleSwitchTo('symbol')"
        >
          <span class="key-9__label">{{ showPunctuation ? '返回' : '符' }}</span>
        </div>
        <div 
          class="key-9 key-9--space"
          @click="handleSpace"
        >
          <span class="key-9__label">空格</span>
        </div>
        <div 
          class="key-9 key-9--function key-9--delete"
          :class="{ 'key-9--deleting': isDeleting }"
          @click="handleDelete"
          @touchstart.prevent="handleDeleteTouchStart"
          @touchend.prevent="handleDeleteTouchEnd"
        >
          <span class="key-9__label">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M21 4H8l-7 8 7 8h13a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2z"></path>
              <line x1="18" y1="9" x2="12" y2="15"></line>
              <line x1="12" y1="9" x2="18" y2="15"></line>
            </svg>
          </span>
        </div>
      </div>

      <!-- 第五行（可选）：切换键盘类型 -->
      <div class="keyboard-row keyboard-row--tools" v-if="showTools">
        <div class="key-9 key-9--function key-9--tool" @click="handleSwitchTo('26key')">
          <span class="key-9__label">26键</span>
        </div>
        <div class="key-9 key-9--function key-9--tool" @click="handleSwitchTo('emoji')">
          <span class="key-9__icon">😀</span>
        </div>
        <div 
          class="key-9 key-9--function key-9--return"
          :class="{ 'key-9--active': hasInput }"
          @click="handleReturn"
        >
          <span class="key-9__label">{{ hasInput ? '发送' : '' }}</span>
        </div>
      </div>
    </div>

    <!-- 标点符号面板 -->
    <div class="keyboard-punctuation" v-if="showPunctuation">
      <div class="punctuation-grid">
        <div 
          class="punctuation-key"
          v-for="(p, index) in punctuationMarks" 
          :key="index"
          @click="addPunctuation(p)"
        >
          {{ p }}
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import ylCandidate from './candidate.vue'
import { getPinyinEngine } from './pinyin-engine.js'

export default {
  name: 'yl-keyboard-9',
  components: {
    ylCandidate
  },
  props: {
    value: {
      type: String,
      default: ''
    },
    showTools: {
      type: Boolean,
      default: true
    }
  },
  data() {
    return {
      // 按键字母映射
      keyLetters: {
        '2': 'abc',
        '3': 'def',
        '4': 'ghi',
        '5': 'jkl',
        '6': 'mno',
        '7': 'pqrs',
        '8': 'tuv',
        '9': 'wxyz'
      },
      
      // 标点符号
      punctuationMarks: ['，', '。', '？', '！', '：', '；', '"', '"', "'", "'"],
      
      // 状态
      pinyinInput: '',
      candidates: [],
      activeKey: null,
      activeKeyCount: 0,
      keyTimeout: null,
      autoConfirmTimer: null,
      
      // 标点符号
      showPunctuation: false,
      
      // 长按删除
      isDeleting: false,
      deleteTimeout: null,
      deleteInterval: null,
      
      // 拼音引擎
      pinyinEngine: null
    }
  },
  computed: {
    inputText() {
      return this.value || ''
    },
    hasInput() {
      return this.inputText.trim().length > 0
    }
  },
  created() {
    this.pinyinEngine = getPinyinEngine()
  },
  beforeDestroy() {
    this.clearTimers()
  },
  methods: {
    // 按键点击处理
    handleKeyClick(key) {
      if (key === '1') {
        // 翻页
        this.$refs.candidate && this.$refs.candidate.nextPage()
        return
      }
      
      if (key === '0') {
        // 切换标点
        this.showPunctuation = !this.showPunctuation
        return
      }
      
      const letters = this.keyLetters[key]
      if (!letters) return
      
      // 如果按的是同一个键
      if (this.activeKey === key) {
        this.activeKeyCount++
        
        // 如果已经循环到末尾，选择最后一个字母
        if (this.activeKeyCount >= letters.length) {
          this.addPinyinChar(letters[letters.length - 1])
          this.activeKey = null
          this.activeKeyCount = 0
        }
      } else {
        // 先确认之前的拼音
        if (this.activeKey !== null) {
          this.addPinyinChar(letters[0])
        }
        
        this.activeKey = key
        this.activeKeyCount = 0
        this.addPinyinChar(letters[0])
      }
      
      // 设置超时，自动确认
      clearTimeout(this.keyTimeout)
      this.keyTimeout = setTimeout(() => {
        this.activeKey = null
        this.activeKeyCount = 0
      }, 800)
    },

    // 添加拼音字符
    addPinyinChar(char) {
      this.pinyinInput += char
      this.updateCandidates()
      
      // 自动确认
      clearTimeout(this.autoConfirmTimer)
      this.autoConfirmTimer = setTimeout(() => {
        this.confirmPinyin()
      }, 1500)
    },

    // 更新候选词
    updateCandidates() {
      if (!this.pinyinInput) {
        this.candidates = []
        return
      }
      
      this.candidates = this.pinyinEngine.search(this.pinyinInput)
    },

    // 选择候选词
    handleCandidateSelect(word) {
      this.addChar(word)
      this.clearPinyin()
    },

    // 清除拼音输入
    handleCandidateClear() {
      this.clearPinyin()
    },

    // 清除拼音
    clearPinyin() {
      this.pinyinInput = ''
      this.candidates = []
      this.activeKey = null
      this.activeKeyCount = 0
      clearTimeout(this.autoConfirmTimer)
      clearTimeout(this.keyTimeout)
    },

    // 确认拼音并输入
    confirmPinyin() {
      if (this.pinyinInput && this.candidates.length > 0) {
        this.addChar(this.candidates[0])
      } else if (this.pinyinInput) {
        this.addChar(this.pinyinInput)
      }
      this.clearPinyin()
    },

    // 添加字符
    addChar(char) {
      const newValue = this.inputText + char
      this.$emit('input', newValue)
      this.$emit('change', newValue)
      
      // 更新用户词频
      if (char.length === 1 && /[\u4e00-\u9fa5]/.test(char)) {
        this.pinyinEngine.increaseFrequency(char)
      } else if (char.length > 1) {
        this.pinyinEngine.increaseFrequency(char)
      }
    },

    // 空格
    handleSpace() {
      this.confirmPinyin()
      this.addChar(' ')
    },

    // 删除
    handleDelete() {
      if (this.pinyinInput.length > 0) {
        this.pinyinInput = this.pinyinInput.slice(0, -1)
        this.updateCandidates()
      } else if (this.inputText.length > 0) {
        const newValue = this.inputText.slice(0, -1)
        this.$emit('input', newValue)
        this.$emit('change', newValue)
      }
    },

    // 长按删除
    handleDeleteTouchStart() {
      this.deleteTimeout = setTimeout(() => {
        this.isDeleting = true
        this.deleteInterval = setInterval(() => {
          this.handleDelete()
        }, 100)
      }, 500)
    },

    // 长按删除结束
    handleDeleteTouchEnd() {
      this.clearDeleteTimer()
    },

    // 清除删除定时器
    clearDeleteTimer() {
      clearTimeout(this.deleteTimeout)
      clearInterval(this.deleteInterval)
      this.deleteTimeout = null
      this.deleteInterval = null
      this.isDeleting = false
    },

    // 发送
    handleReturn() {
      if (this.hasInput) {
        this.$emit('submit', this.inputText)
        this.$emit('input', '')
        this.$emit('change', '')
        this.clearPinyin()
      }
    },

    // 翻页
    handlePageUp() {
      this.$emit('pageup')
    },

    // 切换标点
    togglePunctuation() {
      this.showPunctuation = !this.showPunctuation
    },

    // 添加标点
    addPunctuation(p) {
      this.addChar(p)
      this.showPunctuation = false
    },

    // 切换键盘类型
    handleSwitchTo(type) {
      this.confirmPinyin()
      this.$emit('switch', type)
    },

    // 清除所有定时器
    clearTimers() {
      clearTimeout(this.keyTimeout)
      clearTimeout(this.autoConfirmTimer)
      this.clearDeleteTimer()
    }
  }
}
</script>

<style lang="scss" scoped>
.keyboard-9 {
  padding: 6px 4px;
}

.keyboard-candidate {
  margin-bottom: 6px;
}

.keyboard-body {
  background-color: var(--kb-bg, #D1D5DB);
  border-radius: var(--kb-container-radius, 12px);
  padding: 4px;
}

.keyboard-row {
  display: flex;
  justify-content: center;
  margin-bottom: 6px;

  &:last-child {
    margin-bottom: 0;
  }

  &--tools {
    margin-top: 4px;
  }
}

.key-9 {
  width: var(--kb-key-size, 48px);
  height: var(--kb-key-height, 52px);
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  margin: 0 2px;
  background-color: var(--kb-key-bg, #FFFFFF);
  border-radius: var(--kb-key-radius, 8px);
  cursor: pointer;
  user-select: none;
  transition: all 0.1s ease;
  box-shadow: 0 2px 4px var(--kb-key-shadow, rgba(0, 0, 0, 0.15));

  &:active {
    background-color: var(--kb-key-active, #C8C8C8);
    transform: scale(0.95);
  }

  &--number {
    .key-9__number {
      font-size: 24px;
      font-weight: bold;
      color: var(--kb-key-text, #333333);
    }
    
    .key-9__letters {
      font-size: 12px;
      color: var(--kb-tab-text, #666666);
      margin-top: -2px;
    }
  }

  &--function {
    background-color: var(--kb-key-function-bg, #A8A8A8);
  }

  &--space {
    width: 120px;
    font-size: 18px;
  }

  &--delete {
    width: 80px;
    
    svg {
      width: 22px;
      height: 22px;
    }
  }

  &--return {
    width: 80px;
    font-size: 16px;
    
    &.key-9--active {
      background-color: var(--kb-accent, #3792ED);
      color: var(--kb-tab-active-text, #FFFFFF);
    }
  }

  &--tool {
    width: 80px;
    font-size: 14px;
  }

  &--active {
    background-color: var(--kb-accent, #3792ED) !important;
    
    .key-9__number,
    .key-9__letters,
    .key-9__label {
      color: #FFFFFF !important;
    }
  }

  &--deleting {
    background-color: var(--kb-danger, #E74C3C) !important;
    color: #FFFFFF !important;
  }

  &__label {
    font-size: 18px;
    font-weight: 600;
    color: var(--kb-text-primary, #333333);
  }

  &__icon {
    font-size: 24px;
  }
}

// 标点符号面板
.keyboard-punctuation {
  margin-top: 6px;
  background-color: var(--kb-bg, #D1D5DB);
  border-radius: var(--kb-container-radius, 12px);
  padding: 6px;
}

.punctuation-grid {
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
  gap: 4px;
}

.punctuation-key {
  width: 48px;
  height: 44px;
  display: flex;
  justify-content: center;
  align-items: center;
  background-color: var(--kb-key-bg, #FFFFFF);
  border-radius: 6px;
  font-size: 20px;
  color: var(--kb-key-text, #333333);
  cursor: pointer;
  user-select: none;

  &:active {
    background-color: var(--kb-key-active, #C8C8C8);
    transform: scale(0.95);
  }
}
</style>
