<template>
  <div class="keyboard-emoji">
    <!-- Tab导航 -->
    <div class="emoji-tabs">
      <div 
        class="emoji-tab"
        :class="{ 'emoji-tab--active': activeTab === 'recent' }"
        @click="activeTab = 'recent'"
      >
        <span class="emoji-tab__icon">🕐</span>
      </div>
      <div 
        class="emoji-tab"
        :class="{ 'emoji-tab--active': activeTab === 'smile' }"
        @click="activeTab = 'smile'"
      >
        <span class="emoji-tab__icon">😄</span>
      </div>
      <div 
        class="emoji-tab"
        :class="{ 'emoji-tab--active': activeTab === 'people' }"
        @click="activeTab = 'people'"
      >
        <span class="emoji-tab__icon">👨</span>
      </div>
      <div 
        class="emoji-tab"
        :class="{ 'emoji-tab--active': activeTab === 'heart' }"
        @click="activeTab = 'heart'"
      >
        <span class="emoji-tab__icon">❤️</span>
      </div>
      <div 
        class="emoji-tab"
        :class="{ 'emoji-tab--active': activeTab === 'nature' }"
        @click="activeTab = 'nature'"
      >
        <span class="emoji-tab__icon">🌸</span>
      </div>
      <div 
        class="emoji-tab"
        :class="{ 'emoji-tab--active': activeTab === 'food' }"
        @click="activeTab = 'food'"
      >
        <span class="emoji-tab__icon">🍎</span>
      </div>
      <div 
        class="emoji-tab"
        :class="{ 'emoji-tab--active': activeTab === 'health' }"
        @click="activeTab = 'health'"
      >
        <span class="emoji-tab__icon">🏥</span>
      </div>
      <div 
        class="emoji-tab"
        :class="{ 'emoji-tab--active': activeTab === 'symbol' }"
        @click="activeTab = 'symbol'"
      >
        <span class="emoji-tab__icon">🔤</span>
      </div>
    </div>

    <!-- Emoji网格 -->
    <div class="emoji-grid-container">
      <div class="emoji-grid" ref="emojiGrid">
        <!-- 最近使用 -->
        <template v-if="activeTab === 'recent'">
          <div 
            class="emoji-item"
            v-for="(emoji, index) in recentEmojis" 
            :key="'recent-' + index"
            @click="handleEmojiClick(emoji)"
          >
            {{ emoji }}
          </div>
          <div class="emoji-empty" v-if="recentEmojis.length === 0">
            暂无最近使用的表情
          </div>
        </template>

        <!-- 笑脸 -->
        <template v-else-if="activeTab === 'smile'">
          <div 
            class="emoji-item"
            v-for="(emoji, index) in smileEmojis" 
            :key="'smile-' + index"
            @click="handleEmojiClick(emoji)"
          >
            {{ emoji }}
          </div>
        </template>

        <!-- 人物 -->
        <template v-else-if="activeTab === 'people'">
          <div 
            class="emoji-item"
            v-for="(emoji, index) in peopleEmojis" 
            :key="'people-' + index"
            @click="handleEmojiClick(emoji)"
          >
            {{ emoji }}
          </div>
        </template>

        <!-- 爱心 -->
        <template v-else-if="activeTab === 'heart'">
          <div 
            class="emoji-item"
            v-for="(emoji, index) in heartEmojis" 
            :key="'heart-' + index"
            @click="handleEmojiClick(emoji)"
          >
            {{ emoji }}
          </div>
        </template>

        <!-- 自然 -->
        <template v-else-if="activeTab === 'nature'">
          <div 
            class="emoji-item"
            v-for="(emoji, index) in natureEmojis" 
            :key="'nature-' + index"
            @click="handleEmojiClick(emoji)"
          >
            {{ emoji }}
          </div>
        </template>

        <!-- 食物 -->
        <template v-else-if="activeTab === 'food'">
          <div 
            class="emoji-item"
            v-for="(emoji, index) in foodEmojis" 
            :key="'food-' + index"
            @click="handleEmojiClick(emoji)"
          >
            {{ emoji }}
          </div>
        </template>

        <!-- 健康 -->
        <template v-else-if="activeTab === 'health'">
          <div 
            class="emoji-item"
            v-for="(emoji, index) in healthEmojis" 
            :key="'health-' + index"
            @click="handleEmojiClick(emoji)"
          >
            {{ emoji }}
          </div>
        </template>

        <!-- 符号 -->
        <template v-else-if="activeTab === 'symbol'">
          <div 
            class="emoji-item"
            v-for="(emoji, index) in symbolEmojis" 
            :key="'symbol-' + index"
            @click="handleEmojiClick(emoji)"
          >
            {{ emoji }}
          </div>
        </template>
      </div>
    </div>

    <!-- 底部工具栏 -->
    <div class="emoji-tools">
      <div class="tool-btn" @click="handleSwitchTo('26key')">
        <span class="tool-btn__icon">中</span>
        <span class="tool-btn__text">拼音</span>
      </div>
      <div class="tool-btn" @click="handleSwitchTo('9key')">
        <span class="tool-btn__icon">9</span>
        <span class="tool-btn__text">9键</span>
      </div>
      <div class="tool-btn" @click="handleSwitchTo('symbol')">
        <span class="tool-btn__icon">123</span>
        <span class="tool-btn__text">符号</span>
      </div>
    </div>
  </div>
</template>

<script>
const STORAGE_KEY = 'yl-keyboard-recent-emoji'
const MAX_RECENT = 16

export default {
  name: 'yl-keyboard-emoji',
  props: {
    value: {
      type: String,
      default: ''
    }
  },
  data() {
    return {
      // 当前激活的Tab
      activeTab: 'smile',
      
      // 最近使用
      recentEmojis: [],
      
      // 笑脸分类
      smileEmojis: [
        '😀', '😃', '😄', '😁', '😆', '😅', '😂', '🤣',
        '😊', '😇', '🙂', '🙃', '😉', '😌', '😍', '🥰',
        '😘', '😗', '😙', '😚', '😋', '😛', '😜', '🤪',
        '😝', '🤑', '🤗', '🤭', '🤫', '🤔', '🤐', '🤨',
        '😐', '😑', '😶', '😏', '😒', '🙄', '😬', '🤥',
        '😔', '😪', '🤤', '😴', '😷', '🤒', '🤕', '🤢',
        '🤮', '🤧', '🥵', '🥶', '🥴', '😵', '🤯', '🤠',
        '🥳', '😎', '🤓', '🧐', '😕', '😟', '🙁', '☹️'
      ],
      
      // 人物分类
      peopleEmojis: [
        '👋', '🤚', '🖐️', '✋', '🖖', '👌', '🤌', '🤏',
        '✌️', '🤞', '🤟', '🤘', '🤙', '👈', '👉', '👆',
        '🖕', '👇', '☝️', '👍', '👎', '✊', '👊', '🤛',
        '🤜', '👏', '🙌', '👐', '🤲', '🤝', '🙏', '✍️',
        '💅', '🤳', '💪', '🦾', '🦿', '🦵', '🦶', '👂',
        '🦻', '👃', '🧠', '🫀', '🫁', '🦷', '🦴', '👀',
        '👁️', '👅', '👄', '👶', '🧒', '👦', '👧', '🧑',
        '👱', '👨', '🧔', '👩', '🧓', '👴', '👵', '🙍'
      ],
      
      // 爱心分类
      heartEmojis: [
        '❤️', '🧡', '💛', '💚', '💙', '💜', '🖤', '🤍',
        '🤎', '💔', '❣️', '💕', '💞', '💓', '💗', '💖',
        '💘', '💝', '💟', '♥️', '💌', '🫀', '💝', '❤️‍🔥',
        '❤️‍🩹', '🩷', '🩵', '🩶', '🩵', '🤍', '🖤', '🤎'
      ],
      
      // 自然分类
      natureEmojis: [
        '☀️', '🌙', '⭐', '🌟', '💫', '✨', '⚡', '🔥',
        '💥', '❄️', '🌈', '☁️', '⛅', '🌤️', '⛈️', '🌦️',
        '🌸', '🌺', '🌻', '🌹', '🥀', '🌼', '🌷', '🪻',
        '🌱', '🌲', '🌳', '🌴', '🌵', '🌾', '🌿', '☘️',
        '🍀', '🍁', '🍂', '🍃', '🪹', '🪺', '🍄', '🌰',
        '🦀', '🦞', '🦐', '🦑', '🐙', '🦀', '🐝', '🐛',
        '🦋', '🐌', '🐞', '🐜', '🪲', '🪳', '🦆', '🐤'
      ],
      
      // 食物分类
      foodEmojis: [
        '🍎', '🍐', '🍊', '🍋', '🍌', '🍉', '🍇', '🍓',
        '🫐', '🍈', '🍒', '🍑', '🥭', '🍍', '🥥', '🥝',
        '🍅', '🍆', '🥑', '🥦', '🥬', '🥒', '🌶️', '🫑',
        '🍜', '🍝', '🍕', '🍔', '🍟', '🌭', '🥪', '🌮',
        '🥙', '🧆', '🥗', '🥘', '🫕', '🍚', '�粥', '🍜',
        '🍢', '🍣', '🍱', '🍲', '🍡', '🍦', '🍨', '🍧',
        '🧁', '🎂', '🍰', '🍮', '🍭', '🍬', '🍫', '🍿'
      ],
      
      // 健康分类
      healthEmojis: [
        '💊', '🏥', '🩺', '🩻', '🩭', '🩸', '🩼', '🩮',
        '❤️', '🫀', '🧠', '🦴', '🦷', '👁️', '👂', '👃',
        '💉', '💊', '🩹', '🩼', '🩺', '🩻', '🧬', '🧫',
        '🧪', '🧴', '🧷', '🧹', '🧺', '🧻', '🚑', '🚒',
        '🚑️', '🏥', '🩺', '❤️‍🩹', '❤️‍🔥', '😷', '🤒', '🤕',
        '🤢', '🤮', '🤧', '🥵', '🥶', '😵', '🤯', '💊'
      ],
      
      // 符号分类
      symbolEmojis: [
        '✅', '❌', '⭕', '❗', '❓', '💡', '🔔', '📢',
        '👆', '☝️', '👍', '👎', '👊', '✊', '👏', '🙌',
        '⭐', '🌟', '✨', '💫', '🔥', '💥', '💢', '💦',
        '💤', '🔇', '🔕', '📳', '🔇', '♻️', '⚜️', '🔱',
        '🏧', '🚮', '📶', '🔋', '🔌', '💻', '📱', '☎️',
        '⏰', '⏱️', '⏲️', '🕐', '📅', '📆', '🗓️', '📇',
        '🔑', '🗝️', '🔒', '🔓', '🔐', '🔏', '🛡️', '⚖️'
      ]
    }
  },
  mounted() {
    this.loadRecentEmojis()
  },
  methods: {
    // 加载最近使用的表情
    loadRecentEmojis() {
      try {
        const stored = localStorage.getItem(STORAGE_KEY)
        if (stored) {
          this.recentEmojis = JSON.parse(stored)
        }
      } catch (e) {
        console.warn('加载最近表情失败:', e)
      }
    },

    // 保存最近使用的表情
    saveRecentEmojis() {
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(this.recentEmojis))
      } catch (e) {
        console.warn('保存最近表情失败:', e)
      }
    },

    // 添加到最近使用
    addToRecent(emoji) {
      const index = this.recentEmojis.indexOf(emoji)
      if (index > -1) {
        this.recentEmojis.splice(index, 1)
      }
      this.recentEmojis.unshift(emoji)
      if (this.recentEmojis.length > MAX_RECENT) {
        this.recentEmojis.pop()
      }
      this.saveRecentEmojis()
    },

    // 点击表情
    handleEmojiClick(emoji) {
      this.addToRecent(emoji)
      const newValue = this.value + emoji
      this.$emit('input', newValue)
      this.$emit('change', newValue)
    },

    // 切换键盘类型
    handleSwitchTo(type) {
      this.$emit('switch', type)
    }
  }
}
</script>

<style lang="scss" scoped>
.keyboard-emoji {
  display: flex;
  flex-direction: column;
  padding: 6px 4px;
}

.emoji-tabs {
  display: flex;
  justify-content: center;
  gap: 4px;
  padding: 4px 0;
  margin-bottom: 6px;
  overflow-x: auto;
  
  &::-webkit-scrollbar {
    display: none;
  }
}

.emoji-tab {
  width: 40px;
  height: 40px;
  display: flex;
  justify-content: center;
  align-items: center;
  background-color: var(--kb-tab-bg, #FFFFFF);
  border-radius: 8px;
  cursor: pointer;
  transition: all 0.2s ease;
  flex-shrink: 0;

  &:hover {
    background-color: var(--kb-key-active, #E0E0E0);
  }

  &--active {
    background-color: var(--kb-accent, #3792ED);
    
    .emoji-tab__icon {
      transform: scale(1.1);
    }
  }

  &__icon {
    font-size: 22px;
  }
}

.emoji-grid-container {
  flex: 1;
  overflow-y: auto;
  background-color: var(--kb-bg, #D1D5DB);
  border-radius: var(--kb-container-radius, 12px);
  padding: 6px;
  min-height: 180px;
  max-height: 220px;

  &::-webkit-scrollbar {
    width: 4px;
  }

  &::-webkit-scrollbar-thumb {
    background-color: var(--kb-key-function-bg, #A8A8A8);
    border-radius: 2px;
  }
}

.emoji-grid {
  display: flex;
  flex-wrap: wrap;
  justify-content: flex-start;
  gap: 2px;
}

.emoji-item {
  width: 44px;
  height: 44px;
  display: flex;
  justify-content: center;
  align-items: center;
  font-size: 28px;
  cursor: pointer;
  border-radius: 8px;
  transition: all 0.15s ease;
  user-select: none;

  &:hover {
    background-color: var(--kb-key-active, #C8C8C8);
    transform: scale(1.1);
  }

  &:active {
    transform: scale(0.95);
    background-color: var(--kb-accent, #3792ED);
  }
}

.emoji-empty {
  width: 100%;
  text-align: center;
  padding: 40px;
  color: var(--kb-tab-text, #999);
  font-size: 14px;
}

.emoji-tools {
  display: flex;
  justify-content: center;
  gap: 16px;
  margin-top: 8px;
  padding: 8px;
  background-color: var(--kb-toolbar-bg, #FFFFFF);
  border-radius: var(--kb-key-radius, 8px);
}

.tool-btn {
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 8px 16px;
  background-color: var(--kb-tab-bg, #F5F5F5);
  border-radius: 8px;
  cursor: pointer;
  transition: all 0.2s ease;

  &:active {
    transform: scale(0.95);
    background-color: var(--kb-accent, #3792ED);
    
    .tool-btn__text {
      color: #FFFFFF;
    }
  }

  &__icon {
    font-size: 20px;
    margin-bottom: 2px;
  }

  &__text {
    font-size: 12px;
    color: var(--kb-tab-text, #666666);
  }
}
</style>
