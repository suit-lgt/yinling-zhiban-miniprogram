<template>
  <div class="keyboard-symbol">
    <!-- 快捷符号区域 -->
    <div class="quick-symbols" v-if="showQuickSymbols">
      <div 
        class="quick-symbol"
        v-for="(symbol, index) in quickSymbols" 
        :key="index"
        @click="handleSymbolClick(symbol)"
      >
        {{ symbol }}
      </div>
    </div>

    <!-- 键盘主体 -->
    <div class="keyboard-body">
      <!-- 第一行：数字 1-0 -->
      <div class="keyboard-row">
        <div 
          class="key-symbol"
          v-for="key in row1" 
          :key="key"
          @click="handleKeyClick(key)"
        >
          {{ key }}
        </div>
      </div>

      <!-- 第二行：常用符号 -->
      <div class="keyboard-row">
        <div 
          class="key-symbol"
          v-for="key in row2" 
          :key="key"
          @click="handleKeyClick(key)"
        >
          {{ key }}
        </div>
      </div>

      <!-- 第三行：其他符号 -->
      <div class="keyboard-row">
        <div 
          class="key-symbol"
          v-for="key in row3" 
          :key="key"
          @click="handleKeyClick(key)"
        >
          {{ key }}
        </div>
      </div>

      <!-- 第四行：功能键 -->
      <div class="keyboard-row">
        <div 
          class="key-symbol key-symbol--function key-symbol--more"
          @click="toggleQuickSymbols"
          :class="{ 'key-symbol--active': showQuickSymbols }"
        >
          <span>更多</span>
          <span class="key-symbol__arrow">{{ showQuickSymbols ? '▲' : '▼' }}</span>
        </div>
        <div 
          class="key-symbol key-symbol--function key-symbol--delete"
          :class="{ 'key-symbol--deleting': isDeleting }"
          @click="handleDelete"
          @touchstart.prevent="handleDeleteTouchStart"
          @touchend.prevent="handleDeleteTouchEnd"
        >
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M21 4H8l-7 8 7 8h13a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2z"></path>
            <line x1="18" y1="9" x2="12" y2="15"></line>
            <line x1="12" y1="9" x2="18" y2="15"></line>
          </svg>
        </div>
        <div 
          class="key-symbol key-symbol--space"
          @click="handleSpace"
        >
          空格
        </div>
        <div 
          class="key-symbol key-symbol--function key-symbol--return"
          :class="{ 'key-symbol--active': hasInput }"
          @click="handleReturn"
        >
          {{ hasInput ? '发送' : '换行' }}
        </div>
      </div>
    </div>

    <!-- 切换键盘类型 -->
    <div class="keyboard-tools">
      <div class="tool-btn" @click="handleSwitchTo('26key')">
        <span class="tool-btn__icon">中</span>
        <span class="tool-btn__text">拼音</span>
      </div>
      <div class="tool-btn" @click="handleSwitchTo('9key')">
        <span class="tool-btn__icon">9</span>
        <span class="tool-btn__text">9键</span>
      </div>
      <div class="tool-btn" @click="handleSwitchTo('emoji')">
        <span class="tool-btn__icon">😀</span>
        <span class="tool-btn__text">表情</span>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'yl-keyboard-symbol',
  props: {
    value: {
      type: String,
      default: ''
    }
  },
  data() {
    return {
      // 数字行
      row1: ['1', '2', '3', '4', '5', '6', '7', '8', '9', '0'],
      
      // 常用符号行
      row2: ['-', '/', ':', ';', '(', ')', '$', '&', '@', '"'],
      
      // 其他符号行
      row3: ['.', ',', '?', '!', "'", '"', '[', ']', '{', '}'],
      
      // 快捷符号
      quickSymbols: ['，', '。', '？', '！', '：', '；', '"', '"', '、', '…', '—', '·', '《', '》', '【', '】', '～'],
      
      // 状态
      showQuickSymbols: false,
      isDeleting: false,
      deleteTimeout: null,
      deleteInterval: null
    }
  },
  computed: {
    inputText() {
      return this.value || ''
    },
    hasInput() {
      return this.inputText.trim().length > 0
    }
  },
  beforeDestroy() {
    this.clearDeleteTimer()
  },
  methods: {
    // 按键点击
    handleKeyClick(key) {
      this.addChar(key)
    },

    // 符号点击
    handleSymbolClick(symbol) {
      this.addChar(symbol)
    },

    // 添加字符
    addChar(char) {
      const newValue = this.inputText + char
      this.$emit('input', newValue)
      this.$emit('change', newValue)
    },

    // 切换快捷符号显示
    toggleQuickSymbols() {
      this.showQuickSymbols = !this.showQuickSymbols
    },

    // 删除
    handleDelete() {
      if (this.inputText.length > 0) {
        const newValue = this.inputText.slice(0, -1)
        this.$emit('input', newValue)
        this.$emit('change', newValue)
      }
    },

    // 长按删除开始
    handleDeleteTouchStart() {
      this.deleteTimeout = setTimeout(() => {
        this.isDeleting = true
        this.deleteInterval = setInterval(() => {
          this.handleDelete()
        }, 100)
      }, 500)
    },

    // 长按删除结束
    handleDeleteTouchEnd() {
      this.clearDeleteTimer()
    },

    // 清除删除定时器
    clearDeleteTimer() {
      clearTimeout(this.deleteTimeout)
      clearInterval(this.deleteInterval)
      this.deleteTimeout = null
      this.deleteInterval = null
      this.isDeleting = false
    },

    // 空格
    handleSpace() {
      this.addChar(' ')
    },

    // 发送/换行
    handleReturn() {
      if (this.hasInput) {
        this.$emit('submit', this.inputText)
        this.$emit('input', '')
        this.$emit('change', '')
      } else {
        this.addChar('\n')
      }
    },

    // 切换键盘类型
    handleSwitchTo(type) {
      this.$emit('switch', type)
    }
  }
}
</script>

<style lang="scss" scoped>
.keyboard-symbol {
  padding: 6px 4px;
}

.quick-symbols {
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
  gap: 4px;
  padding: 8px;
  background-color: var(--kb-bg, #D1D5DB);
  border-radius: var(--kb-key-radius, 8px);
  margin-bottom: 6px;
}

.quick-symbol {
  width: 44px;
  height: 40px;
  display: flex;
  justify-content: center;
  align-items: center;
  background-color: var(--kb-key-bg, #FFFFFF);
  border-radius: 6px;
  font-size: 18px;
  color: var(--kb-key-text, #333333);
  cursor: pointer;
  user-select: none;
  transition: all 0.1s ease;

  &:active {
    background-color: var(--kb-key-active, #C8C8C8);
    transform: scale(0.95);
  }
}

.keyboard-body {
  background-color: var(--kb-bg, #D1D5DB);
  border-radius: var(--kb-container-radius, 12px);
  padding: 4px;
}

.keyboard-row {
  display: flex;
  justify-content: center;
  margin-bottom: 6px;

  &:last-child {
    margin-bottom: 0;
  }
}

.key-symbol {
  width: var(--kb-key-size, 48px);
  height: var(--kb-key-height, 52px);
  display: flex;
  justify-content: center;
  align-items: center;
  margin: 0 2px;
  background-color: var(--kb-key-bg, #FFFFFF);
  border-radius: var(--kb-key-radius, 8px);
  font-size: var(--kb-font-size, 20px);
  font-weight: 600;
  color: var(--kb-key-text, #333333);
  cursor: pointer;
  user-select: none;
  transition: all 0.1s ease;
  box-shadow: 0 2px 4px var(--kb-key-shadow, rgba(0, 0, 0, 0.15));

  &:active {
    background-color: var(--kb-key-active, #C8C8C8);
    transform: scale(0.95);
  }

  &--function {
    background-color: var(--kb-key-function-bg, #A8A8A8);
    font-size: 16px;
  }

  &--space {
    width: 120px;
    font-size: 18px;
  }

  &--return {
    width: 80px;
    font-size: 16px;
    
    &.key-symbol--active {
      background-color: var(--kb-accent, #3792ED);
      color: var(--kb-tab-active-text, #FFFFFF);
    }
  }

  &--more {
    width: 80px;
    font-size: 14px;
    flex-direction: column;
    
    .key-symbol__arrow {
      font-size: 10px;
      margin-top: -2px;
    }
  }

  &--delete {
    width: 80px;
    
    svg {
      width: 22px;
      height: 22px;
    }
  }

  &--active {
    background-color: var(--kb-accent, #3792ED) !important;
    color: var(--kb-tab-active-text, #FFFFFF) !important;
  }

  &--deleting {
    background-color: var(--kb-danger, #E74C3C) !important;
    color: #FFFFFF !important;
  }
}

.keyboard-tools {
  display: flex;
  justify-content: center;
  gap: 16px;
  margin-top: 8px;
  padding: 8px;
  background-color: var(--kb-toolbar-bg, #FFFFFF);
  border-radius: var(--kb-key-radius, 8px);
}

.tool-btn {
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 8px 16px;
  background-color: var(--kb-tab-bg, #F5F5F5);
  border-radius: 8px;
  cursor: pointer;
  transition: all 0.2s ease;

  &:active {
    transform: scale(0.95);
    background-color: var(--kb-accent, #3792ED);
    
    .tool-btn__text {
      color: #FFFFFF;
    }
  }

  &__icon {
    font-size: 20px;
    margin-bottom: 2px;
  }

  &__text {
    font-size: 12px;
    color: var(--kb-tab-text, #666666);
  }
}
</style>
