<template>
  <div 
    class="keyboard-panel"
    :class="themeClass"
    v-if="visible"
  >
    <!-- 26键键盘 -->
    <yl-keyboard-26
      v-if="keyboardType === '26key'"
      :value="inputText"
      @input="handleInput"
      @change="handleChange"
      @submit="handleSubmit"
      @switch="handleSwitch"
    />

    <!-- 9键键盘 -->
    <yl-keyboard-9
      v-else-if="keyboardType === '9key'"
      :value="inputText"
      @input="handleInput"
      @change="handleChange"
      @submit="handleSubmit"
      @switch="handleSwitch"
    />

    <!-- 符号键盘 -->
    <yl-keyboard-symbol
      v-else-if="keyboardType === 'symbol'"
      :value="inputText"
      @input="handleInput"
      @change="handleChange"
      @submit="handleSubmit"
      @switch="handleSwitch"
    />

    <!-- Emoji键盘 -->
    <yl-keyboard-emoji
      v-else-if="keyboardType === 'emoji'"
      :value="inputText"
      @input="handleInput"
      @change="handleChange"
      @switch="handleSwitch"
    />
  </div>
</template>

<script>
import ylKeyboard26 from './keyboard-26.vue'
import ylKeyboard9 from './keyboard-9.vue'
import ylKeyboardSymbol from './keyboard-symbol.vue'
import ylKeyboardEmoji from './keyboard-emoji.vue'
import { getPinyinEngine } from './pinyin-engine.js'
import { getCloudAPI } from './cloud-api.js'

export default {
  name: 'yl-keyboard-panel',
  components: {
    ylKeyboard26,
    ylKeyboard9,
    ylKeyboardSymbol,
    ylKeyboardEmoji
  },
  props: {
    value: {
      type: String,
      default: ''
    },
    visible: {
      type: Boolean,
      default: true
    },
    type: {
      type: String,
      default: '26key',
      validator: (value) => ['26key', '9key', 'symbol', 'emoji'].includes(value)
    },
    theme: {
      type: String,
      default: 'light',
      validator: (value) => ['light', 'dark', 'auto'].includes(value)
    }
  },
  data() {
    return {
      keyboardType: '26key',
      currentTheme: 'light',
      inputText: '',
      pinyinEngine: null,
      cloudAPI: null
    }
  },
  computed: {
    themeClass() {
      return `theme-${this.currentTheme}`
    }
  },
  watch: {
    value: {
      immediate: true,
      handler(newVal) {
        this.inputText = newVal || ''
      }
    },
    type: {
      immediate: true,
      handler(newVal) {
        this.keyboardType = newVal
      }
    },
    theme: {
      immediate: true,
      handler() {
        this.updateTheme()
      }
    }
  },
  created() {
    this.initEngine()
  },
  mounted() {
    this.updateTheme()
    
    // 监听系统主题变化
    if (this.theme === 'auto') {
      this.mediaQuery = window.matchMedia('(prefers-color-scheme: dark)')
      this.mediaQuery.addEventListener('change', this.handleThemeChange)
    }
  },
  beforeDestroy() {
    if (this.mediaQuery) {
      this.mediaQuery.removeEventListener('change', this.handleThemeChange)
    }
  },
  methods: {
    // 初始化拼音引擎和云端API
    initEngine() {
      this.pinyinEngine = getPinyinEngine()
      this.cloudAPI = getCloudAPI()
      
      // 尝试同步云端词库
      this.syncCloudVocab()
    },

    // 同步云端词库
    async syncCloudVocab() {
      try {
        const localVersion = localStorage.getItem('yl-keyboard-cloud-version') || ''
        const result = await this.cloudAPI.syncVocab(localVersion)
        
        if (result.hasUpdate && result.words) {
          this.pinyinEngine.syncCloudVocab(result.words)
        }
      } catch (e) {
        console.warn('云端词库同步失败:', e)
      }
    },

    // 更新主题
    updateTheme() {
      if (this.theme === 'auto') {
        const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches
        this.currentTheme = prefersDark ? 'dark' : 'light'
      } else {
        this.currentTheme = this.theme
      }
    },

    // 主题变化处理
    handleThemeChange(e) {
      if (e.matches) {
        this.currentTheme = 'dark'
      } else {
        this.currentTheme = 'light'
      }
    },

    // 输入处理
    handleInput(value) {
      this.inputText = value
      this.$emit('input', value)
    },

    // 变化处理
    handleChange(value) {
      this.$emit('change', value)
    },

    // 提交处理
    handleSubmit(value) {
      this.$emit('submit', value)
      this.$emit('close')
    },

    // 切换键盘类型
    handleSwitch(type) {
      this.keyboardType = type
      this.$emit('type-change', type)
    },

    // 手动设置主题
    setTheme(theme) {
      this.$emit('theme-change', theme)
    },

    // 清空输入
    clear() {
      this.inputText = ''
      this.$emit('input', '')
      this.$emit('change', '')
    },

    // 获取焦点
    focus() {
      this.$emit('focus')
    },

    // 失去焦点
    blur() {
      this.$emit('blur')
    }
  }
}
</script>

<style lang="scss" scoped>
// 浅色主题（默认）
.keyboard-panel {
  @import './styles/_light.scss';
  
  &.theme-light {
    @import './styles/_light.scss';
  }
  
  &.theme-dark {
    @import './styles/_dark.scss';
  }
}
</style>

<style lang="scss">
// 全局样式（不使用scoped）
@import './styles/_light.scss';
@import './styles/_dark.scss';
</style>
