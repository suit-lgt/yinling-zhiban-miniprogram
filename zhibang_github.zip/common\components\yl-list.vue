<template>
  <view class="yl-list">
    <view
      v-for="(item, index) in data"
      :key="item.id || index"
      class="yl-list-item"
      :class="{ 'yl-list-item--arrow': arrow }"
      :style="{ paddingLeft: `${padding}px`, paddingRight: `${padding}px` }"
      @click="handleClick(item, index)"
    >
      <view v-if="$slots.prepend || item.icon" class="yl-list-item__left">
        <slot name="prepend" :item="item"></slot>
        <image
          v-if="item.icon"
          :src="item.icon"
          class="yl-list-item__icon"
          mode="aspectFit"
        />
      </view>
      <view class="yl-list-item__content">
        <text class="yl-list-item__title">{{ item.title }}</text>
        <text v-if="item.subtitle" class="yl-list-item__subtitle">{{ item.subtitle }}</text>
      </view>
      <view v-if="$slots.append || item.extra || arrow" class="yl-list-item__right">
        <slot name="append" :item="item"></slot>
        <text v-if="item.extra" class="yl-list-item__extra">{{ item.extra }}</text>
        <text v-if="arrow" class="yl-list-item__arrow">></text>
      </view>
    </view>
  </view>
</template>

<script>
export default {
  name: 'yl-list',
  props: {
    data: {
      type: Array,
      default: () => []
    },
    arrow: {
      type: Boolean,
      default: true
    },
    padding: {
      type: Number,
      default: 16
    }
  },
  methods: {
    handleClick(item, index) {
      this.$emit('click', { item, index })
    }
  }
}
</script>

<style lang="scss" scoped>
.yl-list {
  background-color: #FFFFFF;
}

.yl-list-item {
  display: flex;
  align-items: center;
  min-height: 60px;
  padding: 12px 16px;
  border-bottom: 1px solid #E5E5E5;

  &:last-child {
    border-bottom: none;
  }

  &:active {
    background-color: #F5F5F5;
  }

  &--arrow {
    padding-right: 8px;
  }

  &__left {
    display: flex;
    align-items: center;
    margin-right: 12px;
  }

  &__icon {
    width: 40px;
    height: 40px;
  }

  &__content {
    flex: 1;
    display: flex;
    flex-direction: column;
    justify-content: center;
  }

  &__title {
    font-size: 16px;
    color: #333333;
  }

  &__subtitle {
    font-size: 14px;
    color: #999999;
    margin-top: 4px;
  }

  &__right {
    display: flex;
    align-items: center;
    margin-left: 12px;
  }

  &__extra {
    font-size: 14px;
    color: #999999;
  }

  &__arrow {
    font-size: 16px;
    color: #CCCCCC;
    margin-left: 8px;
  }
}
</style>
