<template>
  <view v-if="visible" class="yl-modal" @click="handleMaskClick">
    <view class="yl-modal__content" :class="`yl-modal__content--${type}`" @click.stop>
      <view v-if="showTitle" class="yl-modal__header">
        <text class="yl-modal__title">{{ title }}</text>
        <view v-if="closable" class="yl-modal__close" @click="handleClose">✕</view>
      </view>
      <view class="yl-modal__body">
        <slot></slot>
      </view>
      <view v-if="showFooter" class="yl-modal__footer">
        <slot name="footer">
          <button class="yl-modal__btn yl-modal__btn--cancel" @click="handleCancel">
            {{ cancelText }}
          </button>
          <button class="yl-modal__btn yl-modal__btn--confirm" @click="handleConfirm">
            {{ confirmText }}
          </button>
        </slot>
      </view>
    </view>
  </view>
</template>

<script>
export default {
  name: 'yl-modal',
  props: {
    visible: {
      type: Boolean,
      default: false
    },
    title: {
      type: String,
      default: '提示'
    },
    type: {
      type: String,
      default: 'center',
      validator: value => ['center', 'bottom'].includes(value)
    },
    closable: {
      type: Boolean,
      default: true
    },
    maskClosable: {
      type: Boolean,
      default: true
    },
    showTitle: {
      type: Boolean,
      default: true
    },
    showFooter: {
      type: Boolean,
      default: true
    },
    cancelText: {
      type: String,
      default: '取消'
    },
    confirmText: {
      type: String,
      default: '确定'
    }
  },
  methods: {
    handleClose() {
      this.$emit('close')
    },
    handleCancel() {
      this.$emit('cancel')
    },
    handleConfirm() {
      this.$emit('confirm')
    },
    handleMaskClick() {
      if (this.maskClosable) {
        this.handleClose()
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.yl-modal {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  z-index: 105;
  display: flex;
  align-items: center;
  justify-content: center;
  background-color: rgba(0, 0, 0, 0.5);

  &__content {
    width: 600rpx;
    max-width: 80%;
    background-color: #FFFFFF;
    border-radius: 12px;
    overflow: hidden;

    &--bottom {
      position: absolute;
      bottom: 0;
      left: 0;
      right: 0;
      width: 100%;
      max-width: 100%;
      border-radius: 24px 24px 0 0;
    }
  }

  &__header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 16px 20px;
    border-bottom: 1px solid #E5E5E5;
  }

  &__title {
    font-size: 18px;
    font-weight: 600;
    color: #333333;
  }

  &__close {
    width: 32px;
    height: 32px;
    display: flex;
    justify-content: center;
    align-items: center;
    font-size: 18px;
    color: #999999;
  }

  &__body {
    padding: 20px;
    min-height: 80px;
    font-size: 16px;
    color: #666666;
    line-height: 1.6;
  }

  &__footer {
    display: flex;
    border-top: 1px solid #E5E5E5;
  }

  &__btn {
    flex: 1;
    height: 50px;
    border: none;
    background: none;
    font-size: 16px;
    cursor: pointer;

    &:active {
      background-color: #F5F5F5;
    }

    &--cancel {
      color: #666666;
      border-right: 1px solid #E5E5E5;
    }

    &--confirm {
      color: #3792ED;
      font-weight: 500;
    }
  }
}
</style>
