<template>
  <div 
    class="yl-sos-button"
    :class="{ 'yl-sos-button--pulsing': pulsing }"
    @click="handleClick"
    @longpress="handleLongPress"
  >
    <span class="yl-sos-button__text">SOS</span>
    <span v-if="showCountdown" class="yl-sos-button__countdown">{{ countdown }}</span>
  </div>
</template>

<script>
export default {
  name: 'yl-sos-button',
  props: {
    pulsing: {
      type: Boolean,
      default: false
    },
    emergencyPhone: {
      type: String,
      default: '120'
    }
  },
  data() {
    return {
      showCountdown: false,
      countdown: 3,
      timer: null
    }
  },
  methods: {
    handleClick() {
      if (this.showCountdown) {
        this.cancelCountdown()
        return
      }
      
      this.triggerSOS()
    },
    handleLongPress() {
      this.triggerSOS()
    },
    triggerSOS() {
      this.vibrate()
      
      this.showCountdown = true
      this.countdown = 3
      
      this.timer = setInterval(() => {
        this.countdown--
        
        if (this.countdown <= 0) {
          this.cancelCountdown()
          this.sendSOS()
        }
      }, 1000)
    },
    cancelCountdown() {
      this.showCountdown = false
      this.countdown = 3
      if (this.timer) {
        clearInterval(this.timer)
        this.timer = null
      }
    },
    vibrate() {
      if (navigator.vibrate) {
        navigator.vibrate(200)
      }
    },
    sendSOS() {
      const confirmed = confirm('确定要拨打紧急求助电话吗？\n\n将拨打: ' + this.emergencyPhone)
      
      if (confirmed) {
        this.performSOS()
      }
    },
    performSOS() {
      window.location.href = `tel:${this.emergencyPhone}`
      
      this.$emit('sos')
      
      setTimeout(() => {
        alert('已触发紧急求助')
        this.$emit('sos-sent')
      }, 500)
    }
  },
  beforeDestroy() {
    if (this.timer) {
      clearInterval(this.timer)
    }
  }
}
</script>

<style lang="scss" scoped>
.yl-sos-button {
  position: relative;
  width: 80px;
  height: 80px;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  background-color: #E74C3C;
  border-radius: 50%;
  box-shadow: 0 4px 16px rgba(231, 76, 60, 0.4);
  cursor: pointer;
  
  &--pulsing {
    animation: pulse 1.5s ease-in-out infinite;
  }
  
  &__text {
    font-size: 20px;
    font-weight: bold;
    color: #FFFFFF;
  }
  
  &__countdown {
    position: absolute;
    top: -5px;
    right: -5px;
    width: 24px;
    height: 24px;
    display: flex;
    justify-content: center;
    align-items: center;
    background-color: #FFFFFF;
    color: #E74C3C;
    font-size: 12px;
    font-weight: bold;
    border-radius: 50%;
  }
}

@keyframes pulse {
  0%, 100% {
    transform: scale(1);
    box-shadow: 0 4px 16px rgba(231, 76, 60, 0.4);
  }
  50% {
    transform: scale(1.05);
    box-shadow: 0 6px 24px rgba(231, 76, 60, 0.6);
  }
}
</style>
