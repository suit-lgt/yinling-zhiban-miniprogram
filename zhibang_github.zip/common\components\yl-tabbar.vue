<template>
  <div class="tabbar">
    <div 
      v-for="(tab, index) in tabs" 
      :key="index"
      class="tabbar-item"
      :class="{ 'tabbar-item--active': currentIndex === index }"
      @click="switchTab(index)"
    >
      <div class="tabbar-item__icon">{{ tab.icon }}</div>
      <div class="tabbar-item__text">{{ tab.name }}</div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'yl-tabbar',
  data() {
    return {
      currentIndex: 0,
      tabs: [
        { path: '/', icon: '🏠', name: '首页' },
        { path: '/health', icon: '❤️', name: '健康' },
        { path: '/qa', icon: '🤖', name: '问答' },
        { path: '/tools', icon: '📝', name: '备忘录' },
        { path: '/mine', icon: '👤', name: '我的' }
      ]
    }
  },
  mounted() {
    this.updateCurrentIndex()
  },
  watch: {
    '$route.path': 'updateCurrentIndex'
  },
  methods: {
    updateCurrentIndex() {
      const path = this.$route.path
      const index = this.tabs.findIndex(tab => tab.path === path)
      this.currentIndex = index >= 0 ? index : 0
    },
    switchTab(index) {
      if (index === this.currentIndex) return
      
      this.playFeedback()
      this.currentIndex = index
      this.$router.push(this.tabs[index].path)
    },
    playFeedback() {
      const vibrate = localStorage.getItem('tabVibrate')
      const sound = localStorage.getItem('tabSound')
      
      if (vibrate === 'true') {
        if (navigator.vibrate) {
          navigator.vibrate(50)
        }
      }
      
      if (sound === 'true') {
        try {
          const audio = new Audio('/static/click.mp3')
          audio.volume = 0.3
          audio.play().catch(() => {})
        } catch (e) {
          console.log('播放音效失败', e)
        }
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.tabbar {
  position: fixed;
  bottom: 0;
  left: 0;
  right: 0;
  display: flex;
  height: 80px;
  padding-bottom: env(safe-area-inset-bottom);
  background-color: #FFFFFF;
  border-top: 1px solid #E5E5E5;
  z-index: 1000;
  box-shadow: 0 -2px 10px rgba(0, 0, 0, 0.05);
}

.tabbar-item {
  flex: 1;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  cursor: pointer;
  transition: all 0.2s ease;
  
  &__icon {
    font-size: 32px;
    line-height: 1;
    margin-bottom: 4px;
  }
  
  &__text {
    font-size: 12px;
    color: #999999;
    transition: font-size 0.2s ease;
  }
  
  &--active {
    .tabbar-item__text {
      font-size: 14px;
      font-weight: 600;
      color: #3792ED;
    }
  }
  
  &:active {
    opacity: 0.7;
    transform: scale(0.95);
  }
}
</style>
