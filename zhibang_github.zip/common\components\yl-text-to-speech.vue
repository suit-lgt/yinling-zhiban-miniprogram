<template>
  <view class="yl-text-to-speech" v-if="enabled">
    <view 
      class="yl-text-to-speech__toggle"
      @click="toggleSpeak"
    >
      <text>{{ isSpeaking ? '🔊' : '🔈' }}</text>
    </view>
    <view v-if="isSpeaking" class="yl-text-to-speech__wave">
      <view 
        v-for="i in 3" 
        :key="i" 
        class="yl-text-to-speech__wave-item"
        :style="{ animationDelay: (i * 0.15) + 's' }"
      ></view>
    </view>
  </view>
</template>

<script>
export default {
  name: 'yl-text-to-speech',
  props: {
    text: {
      type: String,
      default: ''
    },
    enabled: {
      type: Boolean,
      default: true
    }
  },
  data() {
    return {
      isSpeaking: false,
      innerAudioContext: null
    }
  },
  watch: {
    text: {
      immediate: true,
      handler(newVal) {
        if (newVal && this.autoSpeak) {
          this.speak(newVal)
        }
      }
    }
  },
  methods: {
    toggleSpeak() {
      if (this.isSpeaking) {
        this.stop()
      } else {
        this.speak(this.text)
      }
    },
    speak(text) {
      if (!text) return
      
      this.isSpeaking = true
      
      const talk = uni.requireNativePlugin('dingtalk-talk')
      
      if (talk) {
        talk.speak({
          text: text,
          speed: 50,
          voice: 'xiaoyan'
        }, (res) => {
          this.isSpeaking = false
        })
      } else {
        this.speakWithWebAPI(text)
      }
    },
    speakWithWebAPI(text) {
      if (!('speechSynthesis' in window)) {
        uni.showToast({
          title: '您的浏览器不支持语音播报',
          icon: 'none'
        })
        this.isSpeaking = false
        return
      }
      
      const utterance = new SpeechSynthesisUtterance(text)
      utterance.rate = 0.8
      utterance.pitch = 1
      
      utterance.onend = () => {
        this.isSpeaking = false
      }
      
      utterance.onerror = () => {
        this.isSpeaking = false
      }
      
      speechSynthesis.speak(utterance)
    },
    stop() {
      this.isSpeaking = false
      
      if (typeof uni !== 'undefined') {
        const talk = uni.requireNativePlugin('dingtalk-talk')
        if (talk) {
          talk.stop()
        }
      }
      
      if ('speechSynthesis' in window) {
        speechSynthesis.cancel()
      }
    }
  },
  beforeDestroy() {
    this.stop()
  }
}
</script>

<style lang="scss" scoped>
.yl-text-to-speech {
  display: inline-flex;
  align-items: center;
  
  &__toggle {
    width: 40px;
    height: 40px;
    display: flex;
    justify-content: center;
    align-items: center;
    font-size: 20px;
  }
  
  &__wave {
    display: flex;
    align-items: flex-end;
    height: 20px;
    margin-left: 4px;
  }
  
  &__wave-item {
    width: 3px;
    height: 10px;
    background-color: #3792ED;
    margin: 0 2px;
    border-radius: 2px;
    animation: wave 0.5s ease-in-out infinite;
  }
}

@keyframes wave {
  0%, 100% {
    height: 5px;
  }
  50% {
    height: 15px;
  }
}
</style>
