<template>
  <div class="voice-input">
    <div 
      class="voice-btn"
      :class="{ 
        'voice-btn--listening': isListening,
        'voice-btn--thinking': isThinking,
        'voice-btn--large': large
      }"
      @click="handleClick"
    >
      <span class="voice-btn__icon">{{ btnIcon }}</span>
      <span class="voice-btn__text">{{ buttonText }}</span>
    </div>
    
    <div class="voice-wave" v-if="isListening">
      <span class="wave-bar" v-for="i in 5" :key="i"></span>
    </div>
    
    <div class="transcript" v-if="transcript">
      <span class="transcript__label">您说：</span>
      <span class="transcript__text">{{ transcript }}</span>
    </div>
    
    <div class="status-hint" v-if="statusHint">
      <span class="status-hint__text">{{ statusHint }}</span>
    </div>
  </div>
</template>

<script>
import { voiceManager } from '@/common/utils/voice'

export default {
  name: 'yl-voice-input',
  props: {
    large: {
      type: Boolean,
      default: false
    },
    autoSubmit: {
      type: Boolean,
      default: true
    },
    continuous: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      isListening: false,
      isThinking: false,
      transcript: '',
      continuousMode: false
    }
  },
  computed: {
    buttonText() {
      if (this.isThinking) return 'AI思考中...'
      if (this.isListening) return '松开发送'
      if (this.continuousMode) return '继续说话'
      return this.large ? '按住说话' : '点击说话'
    },
    btnIcon() {
      if (this.isThinking) return '🤔'
      if (this.isListening) return '🔊'
      if (this.continuousMode) return '🎤'
      return '🎤'
    },
    statusHint() {
      if (this.isListening) return '请说话，松开后自动发送'
      if (this.isThinking) return 'AI正在思考，请稍候...'
      return ''
    }
  },
  mounted() {
    this.initVoiceManager()
  },
  beforeDestroy() {
    voiceManager.stopRecognition()
    voiceManager.stopSpeaking()
  },
  methods: {
    initVoiceManager() {
      voiceManager.onStart = () => {
        this.isListening = true
      }
      
      voiceManager.onResult = (result) => {
        this.transcript = result.transcript
        this.$emit('input', result.transcript)
        
        if (result.isFinal && result.transcript.trim()) {
          this.$emit('result', result.transcript)
          this.isListening = false
          
          if (this.continuousMode) {
            setTimeout(() => this.startListening(), 500)
          }
        }
      }
      
      voiceManager.onEnd = () => {
        this.isListening = false
      }
      
      voiceManager.onError = (error) => {
        this.isListening = false
        console.error('语音识别错误:', error)
        
        if (error === 'no-speech') {
          this.$emit('hint', '没有检测到声音，请重试')
        } else if (error === 'not-allowed') {
          this.$emit('hint', '请允许麦克风权限')
        } else {
          this.$emit('hint', '语音识别失败，请重试')
        }
      }
    },
    handleClick() {
      if (this.isThinking) return
      
      if (this.isListening) {
        voiceManager.stopRecognition()
      } else {
        this.startListening()
      }
    },
    startListening() {
      if (!voiceManager.isRecognitionSupported()) {
        alert('您的浏览器不支持语音识别功能')
        return
      }
      
      this.transcript = ''
      const started = voiceManager.startRecognition()
      if (!started) {
        alert('语音识别启动失败，请检查麦克风权限')
      }
    },
    setThinking(thinking) {
      this.isThinking = thinking
    },
    setContinuousMode(enabled) {
      this.continuousMode = enabled
    },
    reset() {
      this.transcript = ''
      this.isListening = false
      this.isThinking = false
    }
  }
}
</script>

<style lang="scss" scoped>
.voice-input {
  display: flex;
  flex-direction: column;
  align-items: center;
}

.voice-btn {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  width: 120px;
  height: 120px;
  background: linear-gradient(135deg, #3792ED, #15559E);
  border-radius: 50%;
  cursor: pointer;
  transition: all 0.3s ease;
  box-shadow: 0 8px 24px rgba(55, 146, 237, 0.4);
  
  &--large {
    width: 180px;
    height: 180px;
  }
  
  &:active {
    transform: scale(0.95);
  }
  
  &--listening {
    background: linear-gradient(135deg, #E74C3C, #C0392B);
    animation: pulse 1s infinite;
  }
  
  &--thinking {
    background: linear-gradient(135deg, #F39C12, #D68910);
  }
  
  &__icon {
    font-size: 48px;
    margin-bottom: 8px;
    
    .voice-btn--large & {
      font-size: 72px;
    }
  }
  
  &__text {
    font-size: 16px;
    color: #FFFFFF;
    font-weight: 600;
    
    .voice-btn--large & {
      font-size: 22px;
    }
  }
}

.voice-wave {
  display: flex;
  align-items: center;
  justify-content: center;
  margin-top: 16px;
  height: 40px;
}

.wave-bar {
  width: 8px;
  height: 20px;
  background-color: #E74C3C;
  margin: 0 4px;
  border-radius: 4px;
  animation: wave 0.8s ease-in-out infinite;
  
  &:nth-child(1) { animation-delay: 0s; }
  &:nth-child(2) { animation-delay: 0.1s; }
  &:nth-child(3) { animation-delay: 0.2s; }
  &:nth-child(4) { animation-delay: 0.3s; }
  &:nth-child(5) { animation-delay: 0.4s; }
}

.transcript {
  margin-top: 16px;
  padding: 12px 20px;
  background-color: rgba(255, 255, 255, 0.9);
  border-radius: 24px;
  max-width: 80%;
  
  &__label {
    font-size: 14px;
    color: #3792ED;
    margin-right: 8px;
  }
  
  &__text {
    font-size: 18px;
    color: #333333;
  }
}

.status-hint {
  margin-top: 12px;
  
  &__text {
    font-size: 14px;
    color: rgba(255, 255, 255, 0.8);
  }
}

@keyframes pulse {
  0%, 100% {
    box-shadow: 0 0 0 0 rgba(231, 76, 60, 0.7);
  }
  50% {
    box-shadow: 0 0 0 20px rgba(231, 76, 60, 0);
  }
}

@keyframes wave {
  0%, 100% {
    height: 20px;
  }
  50% {
    height: 40px;
  }
}
</style>
