/**
 * 适老化设计规则
 * 确保应用符合老年用户的使用需求
 */

/**
 * 字体规范
 */
export const FONT_RULES = {
  // 字号定义
  sizes: {
    xs: '14px',
    sm: '16px',
    md: '18px',    // 输入框正文最低要求
    lg: '20px',
    xl: '22px',
    xxl: '24px',
    title: '26px',
    titleLarge: '28px'
  },

  // 档位配置
  presets: {
    standard: {
      body: '18px',
      title: '24px',
      button: '18px',
      small: '14px'
    },
    large: {
      body: '22px',
      title: '28px',
      button: '20px',
      small: '16px'
    },
    extraLarge: {
      body: '26px',
      title: '32px',
      button: '22px',
      small: '18px'
    }
  },

  // 行高
  lineHeight: {
    tight: 1.2,
    normal: 1.5,
    relaxed: 1.8
  },

  // 字体权重
  weight: {
    regular: 400,
    medium: 500,
    semibold: 600,
    bold: 700
  }
};

/**
 * 颜色规范
 */
export const COLOR_RULES = {
  // 主色调
  primary: {
    main: '#3792ED',
    dark: '#15559E',
    light: '#5BA3F5'
  },

  // 背景色
  background: {
    light: '#FFFFFF',
    gray: '#F5F5F5',
    dark: '#1A1A1A',
    darkGray: '#2A2A2A'
  },

  // 文字颜色
  text: {
    primary: '#333333',    // 对比度 12.63:1
    secondary: '#555555',  // 对比度 7.93:1
    tertiary: '#888888',   // 对比度 3.24:1 ⚠️
    placeholder: '#999999' // 对比度 2.85:1 ❌
  },

  // 分类颜色
  category: {
    health: '#E74C3C',    // 健康医疗
    service: '#3498DB',  // 生活服务
    social: '#9B59B6',    // 社交活动
    daily: '#F39C12'     // 日常事务
  },

  // 状态颜色
  status: {
    success: '#27AE60',
    warning: '#F39C12',
    error: '#E74C3C',
    info: '#3792ED'
  },

  // 对比度要求（WCAG 2.1）
  contrast: {
    normalText: 4.5,  // 正常文本 >= 4.5:1
    largeText: 3,     // 大文本 >= 3:1
    uiComponents: 3    // UI组件 >= 3:1
  }
};

/**
 * 触摸规范
 */
export const TOUCH_RULES = {
  // 最小触摸区域
  minSize: {
    width: 48,
    height: 48,
    unit: 'px'
  },

  // 推荐触摸区域
  recommendedSize: {
    width: 56,
    height: 56,
    unit: 'px'
  },

  // 图标最小尺寸
  iconMinSize: 24,

  // 间距要求
  spacing: {
    between: 8,    // 元素间最小间距
    padding: 16    // 内边距
  },

  // 点击反馈
  feedback: {
    duration: 100,      // 动画时长(ms)
    scale: 0.95,        // 缩放比例
    opacity: 0.8        // 透明度
  }
};

/**
 * 按钮规范
 */
export const BUTTON_RULES = {
  // 尺寸定义
  sizes: {
    small: {
      minWidth: 44,
      minHeight: 44,
      padding: '8px 16px',
      fontSize: '16px'
    },
    medium: {
      minWidth: 48,
      minHeight: 48,
      padding: '12px 24px',
      fontSize: '18px'
    },
    large: {
      minWidth: 56,
      minHeight: 56,
      padding: '16px 32px',
      fontSize: '20px'
    }
  },

  // 圆角
  borderRadius: {
    small: 4,
    medium: 8,
    large: 12
  },

  // 状态样式
  states: {
    default: {
      opacity: 1
    },
    hover: {
      opacity: 0.9
    },
    active: {
      opacity: 0.8,
      transform: 'scale(0.98)'
    },
    disabled: {
      opacity: 0.5,
      cursor: 'not-allowed'
    }
  }
};

/**
 * 布局规范
 */
export const LAYOUT_RULES = {
  // 间距系统
  spacing: {
    xs: 4,
    sm: 8,
    md: 16,
    lg: 24,
    xl: 32,
    xxl: 48
  },

  // 导航栏
  navbar: {
    height: 50,
    background: '#3792ED',
    textColor: '#FFFFFF'
  },

  // TabBar
  tabbar: {
    height: 60,
    iconSize: 24,
    textSize: 12
  },

  // 卡片
  card: {
    borderRadius: 12,
    padding: 16,
    shadow: '0 2px 8px rgba(0,0,0,0.1)'
  },

  // 列表项
  listItem: {
    minHeight: 60,
    padding: '12px 16px'
  }
};

/**
 * 交互规范
 */
export const INTERACTION_RULES = {
  // 支持的交互方式
  supported: [
    'click',      // 点击
    'input'       // 输入
  ],

  // 禁止的交互方式
  forbidden: [
    'swipe',      // 滑动
    'longpress',  // 长按
    'pinch',      // 捏合
    'rotate'      // 旋转
  ],

  // 操作步骤限制
  steps: {
    memo: 3,    // 备忘录操作最多3步
    core: 1     // 核心功能一步直达
  },

  // 反馈机制
  feedback: {
    success: {
      type: 'toast',
      icon: 'success',
      duration: 2000
    },
    error: {
      type: 'toast',
      icon: 'error',
      duration: 3000
    },
    loading: {
      type: 'loading',
      title: '加载中...'
    }
  }
};

/**
 * 无障碍规范
 */
export const ACCESSIBILITY_RULES = {
  // 焦点管理
  focus: {
    outlineWidth: 2,
    outlineColor: '#3792ED',
    outlineOffset: 2
  },

  // 屏幕阅读器
  aria: {
    required: true,
    labels: [
      'aria-label',
      'aria-describedby',
      'aria-invalid',
      'aria-disabled'
    ]
  },

  // 语音支持
  voice: {
    input: true,     // 语音输入
    output: false,   // 语音播报（可选）
    confirm: true   // 重要操作语音确认
  }
};

/**
 * 验证工具函数
 */
export function validateAccessibility(element) {
  const results = {
    passed: true,
    issues: []
  };

  // 检查字体大小
  if (element.fontSize < 16) {
    results.issues.push(`字体太小: ${element.fontSize}px，应 >= 16px`);
    results.passed = false;
  }

  // 检查触摸区域
  if (element.width < 48 || element.height < 48) {
    results.issues.push(`触摸区域太小: ${element.width}x${element.height}px，应 >= 48x48px`);
    results.passed = false;
  }

  // 检查对比度
  if (element.contrast < 4.5) {
    results.issues.push(`对比度不足: ${element.contrast}:1，应 >= 4.5:1`);
    results.passed = false;
  }

  return results;
}

export default {
  FONT_RULES,
  COLOR_RULES,
  TOUCH_RULES,
  BUTTON_RULES,
  LAYOUT_RULES,
  INTERACTION_RULES,
  ACCESSIBILITY_RULES,
  validateAccessibility
};
