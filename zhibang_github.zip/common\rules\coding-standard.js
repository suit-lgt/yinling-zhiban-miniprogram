/**
 * 代码编写标准
 * 统一代码风格，提高代码可维护性
 */

/**
 * Vue 组件标准
 */
export const VUE_STANDARD = {
  // script 标签顺序
  scriptOrder: [
    'name',
    'components',
    'props',
    'emits',
    'mixins',
    'data',
    'computed',
    'watch',
    'onLoad',
    'onShow',
    'onReady',
    'onHide',
    'onUnload',
    'methods'
  ],

  // props 定义规范
  propsStandard: {
    type: true,          // 必须定义类型
    default: true,       // 必须有默认值
    required: false,     // 可选
    validator: false    // 验证器可选
  },

  // data 返回规范
  dataStandard: {
    mustReturn: true,
    privatePrefix: '_',  // 私有变量以下划线开头
    constant: 'const'
  }
};

/**
 * 样式编写标准
 */
export const CSS_STANDARD = {
  // 属性顺序
  propertyOrder: [
    'display',
    'position',
    'top', 'right', 'bottom', 'left',
    'width', 'height',
    'margin', 'padding',
    'border', 'border-radius',
    'background',
    'color',
    'font',
    'line-height',
    'text-align',
    'flex',
    'z-index',
    'transition',
    'animation'
  ],

  // 单位使用规范
  units: {
    font: 'px',
    layout: 'rpx',
    border: 'px',
    spacing: 'rpx'
  },

  // 响应式断点
  breakpoints: {
    small: '320px',
    medium: '375px',
    large: '414px',
    tablet: '768px'
  }
};

/**
 * API 编写标准
 */
export const API_STANDARD = {
  // 请求方法规范
  methods: {
    GET: '获取数据',
    POST: '创建数据',
    PUT: '更新数据',
    DELETE: '删除数据'
  },

  // 错误码规范
  errorCodes: {
    400: '请求参数错误',
    401: '未授权',
    403: '禁止访问',
    404: '资源不存在',
    500: '服务器错误',
    502: '网关错误',
    503: '服务不可用',
    504: '网关超时'
  },

  // 请求封装要求
  requestRequirements: [
    '统一的请求拦截器',
    '统一的响应拦截器',
    '统一的错误处理',
    '请求超时处理',
    '请求取消功能'
  ]
};

/**
 * 注释规范
 */
export const COMMENT_STANDARD = {
  // 必须添加注释的情况
  mustComment: [
    '复杂的业务逻辑',
    '重要的算法实现',
    '特殊处理逻辑',
    '外部接口调用',
    '非常规解决方案'
  ],

  // 注释风格
  styles: {
    file: '文件头部说明',
    function: '函数功能说明',
    section: '代码区块说明',
    todo: '待完成事项'
  }
};

/**
 * 函数编写规范
 */
export const FUNCTION_STANDARD = {
  // 函数长度限制
  maxLength: 50,

  // 参数限制
  maxParams: 5,

  // 函数设计原则
  principles: [
    '单一职责 - 一个函数只做一件事',
    '命名清晰 - 函数名表达其功能',
    '参数精简 - 尽量减少参数数量',
    '返回明确 - 明确返回值的含义',
    '错误处理 - 包含完善的错误处理'
  ],

  // 推荐写法
  recommended: {
    // 使用 async/await
    async: true,
    
    // 错误捕获
    tryCatch: true,
    
    // 参数校验
    validate: true
  }
};

/**
 * Git 提交规范
 */
export const GIT_STANDARD = {
  // 提交类型
  types: {
    feat: '新功能',
    fix: 'bug修复',
    docs: '文档更新',
    style: '代码格式调整',
    refactor: '代码重构',
    perf: '性能优化',
    test: '测试相关',
    chore: '构建/工具相关'
  },

  // 提交信息格式
  format: '<type>(<scope>): <subject>',
  
  // 示例
  examples: [
    'feat(health): 添加血压记录功能',
    'fix(memo): 修复备忘录删除问题',
    'docs: 更新开发规范文档',
    'style: 统一按钮样式'
  ]
};

export default {
  VUE_STANDARD,
  CSS_STANDARD,
  API_STANDARD,
  COMMENT_STANDARD,
  FUNCTION_STANDARD,
  GIT_STANDARD
};
