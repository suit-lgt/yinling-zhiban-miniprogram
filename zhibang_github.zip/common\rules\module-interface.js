/**
 * 模块接口规范
 * 定义模块间通信的统一接口，防止功能耦合
 * 这是防止"修复一部分功能导致其他功能也被修改"的核心机制
 */

/**
 * 模块注册表
 * 所有功能模块必须在此注册，获取唯一的模块ID
 */
export const MODULE_REGISTRY = {
  // 模块ID定义
  MODULES: {
    INDEX: 'index',
    HEALTH: 'health',
    QA: 'qa',
    TOOLS: 'tools',
    MINE: 'mine',
    LOGIN: 'login',
    GUIDE: 'guide'
  },

  // 模块版本
  VERSIONS: {
    index: '1.0.0',
    health: '1.0.0',
    qa: '1.0.0',
    tools: '1.0.0',
    mine: '1.0.0',
    login: '1.0.0',
    guide: '1.0.0'
  }
};

/**
 * 事件总线 - 模块间通信的唯一方式
 * 所有跨模块通信必须通过此事件总线
 */
class EventBus {
  constructor() {
    this.events = {};
  }

  /**
   * 订阅事件
   * @param {string} event - 事件名称
   * @param {Function} callback - 回调函数
   * @param {Object} context - 上下文
   */
  on(event, callback, context) {
    if (!this.events[event]) {
      this.events[event] = [];
    }
    this.events[event].push({ callback, context });
  }

  /**
   * 取消订阅
   * @param {string} event - 事件名称
   * @param {Function} callback - 回调函数
   */
  off(event, callback) {
    if (!this.events[event]) return;
    
    if (!callback) {
      delete this.events[event];
    } else {
      this.events[event] = this.events[event].filter(
        item => item.callback !== callback
      );
    }
  }

  /**
   * 发布事件
   * @param {string} event - 事件名称
   * @param {*} data - 传递的数据
   */
  emit(event, data) {
    if (!this.events[event]) return;
    
    this.events[event].forEach(item => {
      item.callback.call(item.context, data);
    });
  }

  /**
   * 一次性订阅
   * @param {string} event - 事件名称
   * @param {Function} callback - 回调函数
   */
  once(event, callback) {
    const wrapper = (data) => {
      callback(data);
      this.off(event, wrapper);
    };
    this.on(event, wrapper);
  }
}

export const eventBus = new EventBus();

/**
 * 预定义事件列表
 * 所有模块间通信必须使用以下事件
 */
export const EVENTS = {
  // 用户相关
  USER_LOGIN: 'user:login',
  USER_LOGOUT: 'user:logout',
  USER_UPDATE: 'user:update',

  // 主题相关
  THEME_CHANGE: 'theme:change',
  FONT_SIZE_CHANGE: 'font:size:change',

  // 备忘录相关
  MEMO_ADD: 'memo:add',
  MEMO_UPDATE: 'memo:update',
  MEMO_DELETE: 'memo:delete',

  // 健康相关
  HEALTH_DATA_UPDATE: 'health:data:update',
  MEDICINE_REMIND: 'health:medicine:remind',

  // 导航相关
  TAB_CHANGE: 'tab:change',
  PAGE_JUMP: 'page:jump'
};

/**
 * 模块接口定义
 * 每个模块必须实现的接口方法
 */
export const MODULE_INTERFACE = {
  // 必需的生命周期方法
  lifecycle: {
    onInit: 'module:init',      // 模块初始化
    onShow: 'module:show',      // 模块显示
    onHide: 'module:hide',     // 模块隐藏
    onDestroy: 'module:destroy' // 模块销毁
  },

  // 模块必须暴露的接口
  required: [
    'getModuleId',     // 获取模块ID
    'getModuleName',  // 获取模块名称
    'handleEvent'     // 处理事件
  ],

  // 推荐的事件处理方式
  recommended: {
    // 订阅其他模块的事件
    subscribe: (event, callback) => eventBus.on(event, callback),
    // 发布事件给其他模块
    publish: (event, data) => eventBus.emit(event, data),
    // 取消订阅
    unsubscribe: (event, callback) => eventBus.off(event, callback)
  }
};

/**
 * 创建模块的标准结构
 * @param {string} moduleId - 模块ID
 * @param {string} moduleName - 模块名称
 * @returns {Object} 模块结构
 */
export function createModuleStructure(moduleId, moduleName) {
  return {
    id: moduleId,
    name: moduleName,
    version: MODULE_REGISTRY.VERSIONS[moduleId] || '1.0.0',
    
    // 生命周期方法
    onInit() {
      console.log(`[${moduleName}] 模块初始化`);
    },
    onShow() {
      console.log(`[${moduleName}] 模块显示`);
    },
    onHide() {
      console.log(`[${moduleName}] 模块隐藏`);
    },
    onDestroy() {
      console.log(`[${moduleName}] 模块销毁`);
      // 清理所有订阅的事件
      eventBus.off(null, null);
    },
    
    // 事件处理入口
    handleEvent(event, data) {
      console.log(`[${moduleName}] 收到事件: ${event}`, data);
    },
    
    // 获取模块信息
    getModuleId() {
      return this.id;
    },
    getModuleName() {
      return this.name;
    }
  };
}

/**
 * 解耦检查清单
 * 开发时对照检查，确保模块解耦
 */
export const DECOUPLING_CHECKLIST = {
  // 模块内部
  internal: [
    '✓ 模块内部组件是否只在本模块使用？',
    '✓ 是否避免了跨目录引用？',
    '✓ 样式是否使用了 scoped？'
  ],
  
  // 模块间通信
  communication: [
    '✓ 跨模块调用是否通过事件总线？',
    '✓ 是否避免直接 import 其他模块？',
    '✓ 传递的数据是否使用标准格式？'
  ],
  
  // 公共资源
  common: [
    '✓ 公共组件是否放在 common/components？',
    '✓ 工具函数是否放在 common/utils？',
    '✓ 规则定义是否放在 common/rules？'
  ]
};

export default {
  MODULE_REGISTRY,
  EVENTS,
  MODULE_INTERFACE,
  createModuleStructure,
  DECOUPLING_CHECKLIST,
  eventBus
};
