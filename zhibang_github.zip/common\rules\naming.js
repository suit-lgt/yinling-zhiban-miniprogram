/**
 * 命名规范
 * 统一项目中的命名规则，防止命名混乱导致的问题
 */

export const NAMING_RULES = {
  // 文件命名
  files: {
    vue: 'kebab-case',        // yl-button.vue
    js: 'kebab-case',         // theme-utils.js
    json: 'kebab-case',       // app-config.json
    image: 'kebab-case'       // icon-home.png
  },

  // 组件命名
  components: {
    prefix: 'yl',             // 公共组件前缀
    pattern: 'kebab-case',    // yl-button, yl-card
    private: {
      prefix: '',             // 页面私有组件无前缀
      pattern: 'PascalCase'   // HomeHeader, HealthCard
    }
  },

  // 变量命名
  variables: {
    const: 'UPPER_SNAKE_CASE',  // MAX_COUNT, API_BASE_URL
    let: 'camelCase',            // userName, isLoading
    function: 'camelCase',      // getUserInfo, handleClick
    class: 'PascalCase'         // UserInfo, HealthRecord
  },

  // CSS类命名
  css: {
    pattern: 'kebab-case',     // .btn-primary, .card-header
    block: 'BEM',              // .card__header, .card__body--active
    prefix: {
      layout: 'ly-',           // ly-flex, ly-grid
      component: 'yl-',        // yl-button, yl-card
      state: 'is-',             // is-active, is-disabled
      theme: 'theme-'           // theme-dark, theme-light
    }
  },

  // 页面/路由命名
  pages: {
    directory: 'kebab-case',   // pages/health/medicine/
    route: 'kebab-case'       // /pages/health/health
  },

  // API命名
  api: {
    file: 'kebab-case',        // user-api.js
    function: 'camelCase',    // getUserInfo, login
    prefix: 'api'              // userAPI, weatherAPI
  }
};

/**
 * 禁止使用的命名
 */
export const FORBIDDEN_NAMES = {
  variables: ['temp', 'tmp', 'data', 'obj', 'item', 'info'],
  components: ['Test', 'Demo', 'Temp', 'Example'],
  files: ['index', 'main', 'base', 'common']
};

/**
 * 验证命名是否符合规范
 * @param {string} name - 待验证的名称
 * @param {string} type - 类型 (variable|component|file|css)
 * @returns {boolean}
 */
export function validateName(name, type) {
  const rules = NAMING_RULES[type];
  if (!rules) return true;

  switch (type) {
    case 'variable':
      return /^[a-z][a-zA-Z0-9]*$/.test(name) || /^[A-Z][A-Z0-9_]*$/.test(name);
    case 'component':
      return /^[a-z][a-z0-9-]*$/.test(name) || /^[A-Z][a-zA-Z0-9]*$/.test(name);
    case 'file':
      return /^[a-z0-9-.]+$/.test(name);
    case 'css':
      return /^[a-z][a-z0-9-]*$/.test(name);
    default:
      return true;
  }
}

export default NAMING_RULES;
