/**
 * 状态管理规范
 * 统一状态管理方式，防止状态混乱
 */

/**
 * 存储键名定义
 */
export const STORAGE_KEYS = {
  // 用户相关
  USER: 'user',
  USER_TOKEN: 'user_token',

  // 应用设置
  THEME: 'app_theme',           // 主题 light/dark
  FONT_SIZE: 'app_font_size',  // 字体大小 standard/large/extraLarge
  IS_DARK: 'isDarkMode',       // 深色模式
  TAB_INDEX: 'selectedIndex',  // TabBar索引

  // 业务数据
  MEMO_LIST: 'memoList',
  HEALTH_DATA: 'healthData',
  MEDICINE_LIST: 'medicineList',
  EMERGENCY_CONTACTS: 'emergencyContacts',

  // 缓存
  WEATHER_CACHE: 'weather_cache',
  ARTICLE_CACHE: 'article_cache',
  CACHE_EXPIRE: 5 * 60 * 1000  // 缓存5分钟
};

/**
 * 本地存储工具类
 */
export class StorageManager {
  constructor() {
    this.keys = STORAGE_KEYS;
  }

  /**
   * 设置存储
   * @param {string} key - 键名
   * @param {*} value - 值
   */
  set(key, value) {
    try {
      const data = JSON.stringify(value);
      localStorage.setItem(key, data);
    } catch (e) {
      console.error('存储失败:', e);
    }
  }

  /**
   * 获取存储
   * @param {string} key - 键名
   * @param {*} defaultValue - 默认值
   * @returns {*}
   */
  get(key, defaultValue = null) {
    try {
      const data = localStorage.getItem(key);
      return data ? JSON.parse(data) : defaultValue;
    } catch (e) {
      console.error('读取存储失败:', e);
      return defaultValue;
    }
  }

  /**
   * 移除存储
   * @param {string} key - 键名
   */
  remove(key) {
    try {
      localStorage.removeItem(key);
    } catch (e) {
      console.error('移除存储失败:', e);
    }
  }

  /**
   * 清空所有存储
   */
  clear() {
    try {
      localStorage.clear();
    } catch (e) {
      console.error('清空存储失败:', e);
    }
  }

  /**
   * 检查存储是否存在
   * @param {string} key - 键名
   * @returns {boolean}
   */
  has(key) {
    return localStorage.getItem(key) !== null;
  }
}

export const storage = new StorageManager();

/**
 * 状态管理器
 * 用于页面间共享状态
 */
export class StateManager {
  constructor() {
    this.state = {};
    this.listeners = {};
  }

  /**
   * 设置状态
   * @param {string} key - 状态键名
   * @param {*} value - 状态值
   */
  setState(key, value) {
    const oldValue = this.state[key];
    this.state[key] = value;
    
    // 触发监听器
    if (this.listeners[key]) {
      this.listeners[key].forEach(listener => {
        listener(value, oldValue);
      });
    }
  }

  /**
   * 获取状态
   * @param {string} key - 状态键名
   * @returns {*}
   */
  getState(key) {
    return this.state[key];
  }

  /**
   * 订阅状态变化
   * @param {string} key - 状态键名
   * @param {Function} listener - 监听函数
   */
  subscribe(key, listener) {
    if (!this.listeners[key]) {
      this.listeners[key] = [];
    }
    this.listeners[key].push(listener);

    // 返回取消订阅函数
    return () => {
      this.listeners[key] = this.listeners[key].filter(l => l !== listener);
    };
  }

  /**
   * 批量设置状态
   * @param {Object} state - 状态对象
   */
  setMultipleState(state) {
    Object.keys(state).forEach(key => {
      this.setState(key, state[key]);
    });
  }
}

export const stateManager = new StateManager();

/**
 * 事件总线
 * 用于跨页面通信
 */
export const EventBus = {
  events: {},

  /**
   * 订阅事件
   * @param {string} event - 事件名
   * @param {Function} callback - 回调函数
   */
  on(event, callback) {
    if (!this.events[event]) {
      this.events[event] = [];
    }
    this.events[event].push(callback);
  },

  /**
   * 取消订阅
   * @param {string} event - 事件名
   * @param {Function} callback - 回调函数
   */
  off(event, callback) {
    if (!this.events[event]) return;
    if (callback) {
      this.events[event] = this.events[event].filter(cb => cb !== callback);
    } else {
      delete this.events[event];
    }
  },

  /**
   * 发布事件
   * @param {string} event - 事件名
   * @param {*} data - 数据
   */
  emit(event, data) {
    if (!this.events[event]) return;
    this.events[event].forEach(callback => {
      callback(data);
    });
  },

  /**
   * 一次性订阅
   * @param {string} event - 事件名
   * @param {Function} callback - 回调函数
   */
  once(event, callback) {
    const wrapper = (data) => {
      callback(data);
      this.off(event, wrapper);
    };
    this.on(event, wrapper);
  }
};

/**
 * 页面状态生命周期管理
 */
export const pageStateLifecycle = {
  /**
   * 页面加载时获取状态
   * @param {Object} options - 选项
   */
  onLoad(options) {
    const page = this;
    page._stateSubscriptions = [];
    
    // 从存储加载持久化状态
    const theme = storage.get(STORAGE_KEYS.THEME, 'light');
    const fontSize = storage.get(STORAGE_KEYS.FONT_SIZE, 'standard');
    const isDark = storage.get(STORAGE_KEYS.IS_DARK, false);
    
    // 设置应用状态
    stateManager.setMultipleState({
      theme,
      fontSize,
      isDark
    });
  },

  /**
   * 页面显示时同步状态
   */
  onShow() {
    // 页面显示时重新获取最新状态
  },

  /**
   * 页面隐藏时清理
   */
  onUnload() {
    // 清理所有状态订阅
    if (this._stateSubscriptions) {
      this._stateSubscriptions.forEach(unsubscribe => {
        unsubscribe();
      });
      this._stateSubscriptions = [];
    }
  },

  /**
   * 订阅状态变化
   * @param {string} key - 状态键名
   * @param {Function} callback - 回调函数
   */
  subscribeState(key, callback) {
    const unsubscribe = stateManager.subscribe(key, callback);
    this._stateSubscriptions.push(unsubscribe);
  }
};

/**
 * 状态管理最佳实践
 */
export const BEST_PRACTICES = {
  // 应该
  do: [
    '使用 storage 封装处理持久化数据',
    '使用 stateManager 处理页面级状态',
    '使用 EventBus 处理跨页面通信',
    '在 onUnload 中清理订阅'
  ],

  // 不应该
  dont: [
    '不要直接修改全局变量',
    '不要在 data 中存储大量数据',
    '不要在页面间传递大量数据（使用存储或事件）',
    '不要忘记在页面销毁时清理事件监听'
  ]
};

/**
 * 预定义业务状态
 */
export const BUSINESS_STATES = {
  // 用户状态
  user: {
    loggedIn: false,
    info: null,
    loginDays: 0
  },

  // 主题状态
  theme: {
    mode: 'light',     // light/dark
    fontSize: 'standard', // standard/large/extraLarge
    primaryColor: '#3792ED'
  },

  // 备忘录状态
  memo: {
    list: [],
    categories: [],
    currentCategory: 'all'
  },

  // 健康状态
  health: {
    bloodPressure: [],
    bloodSugar: [],
    heartRate: [],
    lastRecord: null
  }
};

export default {
  STORAGE_KEYS,
  storage,
  stateManager,
  EventBus,
  pageStateLifecycle,
  BEST_PRACTICES,
  BUSINESS_STATES
};
