/**
 * HTTP 请求封装
 * 统一的请求拦截器和错误处理
 */

import { storage, STORAGE_KEYS } from '../rules/state-management'

const BASE_URL = 'https://api.example.com'

const request = (options) => {
  return new Promise((resolve, reject) => {
    const token = storage.get(STORAGE_KEYS.USER_TOKEN, '')
    
    uni.request({
      url: BASE_URL + options.url,
      method: options.method || 'GET',
      data: options.data || {},
      header: {
        'Content-Type': 'application/json',
        'Authorization': token ? `Bearer ${token}` : '',
        ...options.header
      },
      timeout: options.timeout || 30000,
      success: (res) => {
        if (res.statusCode >= 200 && res.statusCode < 300) {
          resolve(res.data)
        } else if (res.statusCode === 401) {
          handleUnauthorized()
          reject({ code: 401, message: '未授权，请重新登录' })
        } else if (res.statusCode === 403) {
          reject({ code: 403, message: '禁止访问' })
        } else if (res.statusCode === 404) {
          reject({ code: 404, message: '请求的资源不存在' })
        } else if (res.statusCode >= 500) {
          reject({ code: res.statusCode, message: '服务器错误，请稍后重试' })
        } else {
          reject({ code: res.statusCode, message: res.data?.message || '请求失败' })
        }
      },
      fail: (err) => {
        const errorMsg = getErrorMessage(err)
        reject({ code: -1, message: errorMsg })
      }
    })
  })
}

function getErrorMessage(err) {
  if (err.errMsg) {
    if (err.errMsg.includes('request:fail')) {
      return '网络连接失败，请检查网络设置'
    }
    if (err.errMsg.includes('timeout')) {
      return '请求超时，请稍后重试'
    }
  }
  return '网络异常，请稍后重试'
}

function handleUnauthorized() {
  storage.remove(STORAGE_KEYS.USER_TOKEN)
  storage.remove(STORAGE_KEYS.USER)
  
  uni.showToast({
    title: '登录已过期，请重新登录',
    icon: 'none'
  })
  
  setTimeout(() => {
    uni.reLaunch({
      url: '/pagesA/login/login'
    })
  }, 1500)
}

export const http = {
  get(url, data, options = {}) {
    return request({ url, method: 'GET', data, ...options })
  },
  
  post(url, data, options = {}) {
    return request({ url, method: 'POST', data, ...options })
  },
  
  put(url, data, options = {}) {
    return request({ url, method: 'PUT', data, ...options })
  },
  
  delete(url, data, options = {}) {
    return request({ url, method: 'DELETE', data, ...options })
  }
}

export default http
