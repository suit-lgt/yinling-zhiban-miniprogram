export function formatFileSize(bytes) {
  if (bytes === 0) return '0 B'
  const k = 1024
  const sizes = ['B', 'KB', 'MB', 'GB']
  const i = Math.floor(Math.log(bytes) / Math.log(k))
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i]
}

export function getImageType(filePath) {
  if (!filePath) return 'unknown'
  const ext = filePath.split('.').pop().toLowerCase()
  const typeMap = {
    'jpg': 'image/jpeg',
    'jpeg': 'image/jpeg',
    'png': 'image/png',
    'gif': 'image/gif',
    'webp': 'image/webp',
    'bmp': 'image/bmp',
    'svg': 'image/svg+xml'
  }
  return typeMap[ext] || 'image/' + ext
}

export function isImageFile(filePath) {
  if (!filePath) return false
  const imageExtensions = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp', 'svg']
  const ext = filePath.split('.').pop().toLowerCase()
  return imageExtensions.includes(ext)
}

export function getImageDimensions(filePath) {
  return new Promise((resolve, reject) => {
    if (!filePath) {
      reject(new Error('图片路径不能为空'))
      return
    }

    const img = new Image()
    
    img.onload = function() {
      resolve({
        width: img.width,
        height: img.height,
        aspectRatio: img.width / img.height
      })
    }
    
    img.onerror = function() {
      reject(new Error('图片加载失败'))
    }
    
    img.src = filePath
  })
}

export function pickImages(options = {}) {
  return new Promise((resolve, reject) => {
    const input = document.createElement('input')
    input.type = 'file'
    input.accept = 'image/*'
    input.multiple = options.count > 1
    
    input.onchange = function(e) {
      const files = Array.from(e.target.files)
      const count = Math.min(options.count || files.length, files.length)
      const selectedFiles = files.slice(0, count)
      
      const results = []
      let completed = 0
      
      if (selectedFiles.length === 0) {
        resolve([])
        return
      }
      
      selectedFiles.forEach((file, index) => {
        const reader = new FileReader()
        
        reader.onload = function(event) {
          const dataUrl = event.target.result
          const img = new Image()
          
          img.onload = function() {
            results.push({
              name: file.name,
              size: file.size,
              sizeStr: formatFileSize(file.size),
              type: file.type,
              path: URL.createObjectURL(file),
              dataUrl: dataUrl,
              width: img.width,
              height: img.height,
              lastModified: file.lastModified,
              lastModifiedDate: new Date(file.lastModified)
            })
            
            completed++
            if (completed === selectedFiles.length) {
              resolve(results)
            }
          }
          
          img.onerror = function() {
            results.push({
              name: file.name,
              size: file.size,
              sizeStr: formatFileSize(file.size),
              type: file.type,
              path: URL.createObjectURL(file),
              dataUrl: dataUrl,
              lastModified: file.lastModified,
              lastModifiedDate: new Date(file.lastModified)
            })
            
            completed++
            if (completed === selectedFiles.length) {
              resolve(results)
            }
          }
          
          img.src = dataUrl
        }
        
        reader.onerror = function() {
          completed++
          if (completed === selectedFiles.length) {
            resolve(results)
          }
        }
        
        reader.readAsDataURL(file)
      })
    }
    
    input.onerror = function() {
      reject(new Error('文件选择失败'))
    }
    
    input.click()
  })
}

export function compressImage(filePath, options = {}) {
  return new Promise((resolve, reject) => {
    const quality = options.quality || 0.8
    const maxWidth = options.maxWidth || 1920
    const maxHeight = options.maxHeight || 1920
    
    const img = new Image()
    
    img.onload = function() {
      let width = img.width
      let height = img.height
      
      if (width > maxWidth) {
        height = (maxWidth / width) * height
        width = maxWidth
      }
      if (height > maxHeight) {
        width = (maxHeight / height) * width
        height = maxHeight
      }
      
      const canvas = document.createElement('canvas')
      canvas.width = width
      canvas.height = height
      
      const ctx = canvas.getContext('2d')
      ctx.drawImage(img, 0, 0, width, height)
      
      canvas.toBlob(
        function(blob) {
          if (!blob) {
            reject(new Error('图片压缩失败'))
            return
          }
          
          resolve({
            blob: blob,
            path: URL.createObjectURL(blob),
            size: blob.size,
            sizeStr: formatFileSize(blob.size),
            width: width,
            height: height
          })
        },
        'image/jpeg',
        quality
      )
    }
    
    img.onerror = function() {
      reject(new Error('图片加载失败'))
    }
    
    img.src = filePath
  })
}

export function downloadImage(filePath, filename = 'image') {
  const link = document.createElement('a')
  link.href = filePath
  link.download = filename + '_' + Date.now() + '.jpg'
  link.target = '_blank'
  document.body.appendChild(link)
  link.click()
  document.body.removeChild(link)
}

export default {
  formatFileSize,
  getImageType,
  isImageFile,
  getImageDimensions,
  pickImages,
  compressImage,
  downloadImage
}