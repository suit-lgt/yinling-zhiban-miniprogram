/**
 * 通用工具函数
 * 提供日期格式化、数据验证、本地存储等常用工具
 */

import { storage, STORAGE_KEYS } from '../rules/state-management'
import imageUtils from './image'

export { imageUtils }

/**
 * 日期格式化
 */
export const dateUtils = {
  /**
   * 格式化日期
   * @param {string|Date|number} date - 日期
   * @param {string} format - 格式 YYYY-MM-DD HH:mm:ss
   * @returns {string}
   */
  format(date, format = 'YYYY-MM-DD HH:mm:ss') {
    if (!date) return ''
    
    const d = new Date(date)
    if (isNaN(d.getTime())) return ''
    
    const year = d.getFullYear()
    const month = String(d.getMonth() + 1).padStart(2, '0')
    const day = String(d.getDate()).padStart(2, '0')
    const hour = String(d.getHours()).padStart(2, '0')
    const minute = String(d.getMinutes()).padStart(2, '0')
    const second = String(d.getSeconds()).padStart(2, '0')
    
    return format
      .replace('YYYY', year)
      .replace('MM', month)
      .replace('DD', day)
      .replace('HH', hour)
      .replace('mm', minute)
      .replace('ss', second)
  },
  
  /**
   * 获取日期字符串 YYYY-MM-DD
   */
  getDateString(date = new Date()) {
    return this.format(date, 'YYYY-MM-DD')
  },
  
  /**
   * 获取时间字符串 HH:mm
   */
  getTimeString(date = new Date()) {
    return this.format(date, 'HH:mm')
  },
  
  /**
   * 获取完整时间字符串
   */
  getFullTimeString(date = new Date()) {
    return this.format(date, 'YYYY-MM-DD HH:mm')
  },
  
  /**
   * 获取相对时间
   */
  getRelativeTime(timestamp) {
    const now = Date.now()
    const diff = now - timestamp
    
    const minute = 60 * 1000
    const hour = 60 * minute
    const day = 24 * hour
    
    if (diff < minute) {
      return '刚刚'
    } else if (diff < hour) {
      return Math.floor(diff / minute) + '分钟前'
    } else if (diff < day) {
      return Math.floor(diff / hour) + '小时前'
    } else if (diff < 7 * day) {
      return Math.floor(diff / day) + '天前'
    } else {
      return this.getDateString(new Date(timestamp))
    }
  },
  
  /**
   * 判断是否为今天
   */
  isToday(date) {
    const today = this.getDateString()
    return this.getDateString(new Date(date)) === today
  },
  
  /**
   * 获取星期几
   */
  getWeekDay(date = new Date()) {
    const weekDays = ['星期日', '星期一', '星期二', '星期三', '星期四', '星期五', '星期六']
    return weekDays[new Date(date).getDay()]
  }
}

/**
 * 数据验证工具
 */
export const validateUtils = {
  /**
   * 验证手机号
   */
  isPhone(phone) {
    return /^1[3-9]\d{9}$/.test(phone)
  },
  
  /**
   * 验证邮箱
   */
  isEmail(email) {
    return /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/.test(email)
  },
  
  /**
   * 验证身份证号
   */
  isIdCard(idCard) {
    return /(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/.test(idCard)
  },
  
  /**
   * 验证密码强度（至少6位）
   */
  isValidPassword(password) {
    return password && password.length >= 6
  },
  
  /**
   * 验证姓名（2-10位中文或英文）
   */
  isValidName(name) {
    return /^[\u4e00-\u9fa5a-zA-Z]{2,10}$/.test(name)
  },
  
  /**
   * 验证金额
   */
  isMoney(amount) {
    return /^\d+(\.\d{1,2})?$/.test(amount)
  }
}

/**
 * 字符串工具
 */
export const stringUtils = {
  /**
   * 脱敏手机号
   */
  maskPhone(phone) {
    if (!phone) return ''
    return phone.replace(/(\d{3})\d{4}(\d{4})/, '$1****$2')
  },
  
  /**
   * 脱敏身份证号
   */
  maskIdCard(idCard) {
    if (!idCard) return ''
    return idCard.replace(/(\d{4})\d{10}(\d{4})/, '$1**********$2')
  },
  
  /**
   * 截断字符串
   */
  truncate(str, length = 50) {
    if (!str) return ''
    if (str.length <= length) return str
    return str.substring(0, length) + '...'
  },
  
  /**
   * 生成随机ID
   */
  generateId() {
    return 'id_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9)
  }
}

/**
 * 数据处理工具
 */
export const dataUtils = {
  /**
   * 深拷贝
   */
  deepClone(obj) {
    if (obj === null || typeof obj !== 'object') return obj
    if (obj instanceof Date) return new Date(obj.getTime())
    if (obj instanceof Array) return obj.map(item => this.deepClone(item))
    if (obj instanceof Object) {
      const clonedObj = {}
      for (const key in obj) {
        if (obj.hasOwnProperty(key)) {
          clonedObj[key] = this.deepClone(obj[key])
        }
      }
      return clonedObj
    }
  },
  
  /**
   * 防抖
   */
  debounce(fn, delay = 300) {
    let timer = null
    return function(...args) {
      if (timer) clearTimeout(timer)
      timer = setTimeout(() => {
        fn.apply(this, args)
      }, delay)
    }
  },
  
  /**
   * 节流
   */
  throttle(fn, delay = 300) {
    let lastTime = 0
    return function(...args) {
      const now = Date.now()
      if (now - lastTime >= delay) {
        lastTime = now
        fn.apply(this, args)
      }
    }
  },
  
  /**
   * 数字格式化（千分位）
   */
  formatNumber(num) {
    if (!num) return '0'
    return String(num).replace(/\B(?=(\d{3})+(?!\d))/g, ',')
  }
}

/**
 * 存储工具封装
 */
export const storageUtils = {
  /**
   * 获取用户信息
   */
  getUser() {
    return storage.get(STORAGE_KEYS.USER, null)
  },
  
  /**
   * 保存用户信息
   */
  setUser(user) {
    storage.set(STORAGE_KEYS.USER, user)
  },
  
  /**
   * 获取备忘录列表
   */
  getMemoList() {
    return storage.get(STORAGE_KEYS.MEMO_LIST, [])
  },
  
  /**
   * 保存备忘录列表
   */
  setMemoList(list) {
    storage.set(STORAGE_KEYS.MEMO_LIST, list)
  },
  
  /**
   * 获取健康数据
   */
  getHealthData() {
    return storage.get(STORAGE_KEYS.HEALTH_DATA, {})
  },
  
  /**
   * 保存健康数据
   */
  setHealthData(data) {
    storage.set(STORAGE_KEYS.HEALTH_DATA, data)
  },
  
  /**
   * 获取主题设置
   */
  getTheme() {
    return {
      theme: storage.get(STORAGE_KEYS.THEME, 'light'),
      fontSize: storage.get(STORAGE_KEYS.FONT_SIZE, 'standard'),
      isDark: storage.get(STORAGE_KEYS.IS_DARK, false)
    }
  },
  
  /**
   * 保存主题设置
   */
  setTheme(settings) {
    if (settings.theme) storage.set(STORAGE_KEYS.THEME, settings.theme)
    if (settings.fontSize) storage.set(STORAGE_KEYS.FONT_SIZE, settings.fontSize)
    if (typeof settings.isDark === 'boolean') storage.set(STORAGE_KEYS.IS_DARK, settings.isDark)
  }
}

/**
 * 设备工具
 */
export const deviceUtils = {
  /**
   * 获取设备信息
   */
  getSystemInfo() {
    return new Promise((resolve) => {
      uni.getSystemInfo({
        success(res) {
          resolve(res)
        },
        fail() {
          resolve({})
        }
      })
    })
  },
  
  /**
   * 获取网络状态
   */
  getNetworkType() {
    return new Promise((resolve) => {
      uni.getNetworkType({
        success(res) {
          resolve(res.networkType)
        },
        fail() {
          resolve('unknown')
        }
      })
    })
  },
  
  /**
   * 拨打电话
   */
  makeCall(phoneNumber) {
    return new Promise((resolve, reject) => {
      uni.makePhoneCall({
        phoneNumber,
        success: () => resolve(true),
        fail: (err) => reject(err)
      })
    })
  },
  
  /**
   * 振动提醒
   */
  vibrate() {
    uni.vibrateShort({
      fail: () => {}
    })
  },
  
  /**
   * 震动反馈（长振动）
   */
  vibrateLong() {
    uni.vibrateLong({
      fail: () => {}
    })
  }
}

/**
 * 提示工具
 */
export const toastUtils = {
  /**
   * 显示成功提示
   */
  success(title = '操作成功', duration = 1500) {
    uni.showToast({
      title,
      icon: 'success',
      duration
    })
  },
  
  /**
   * 显示失败提示
   */
  error(title = '操作失败', duration = 1500) {
    uni.showToast({
      title,
      icon: 'none',
      duration
    })
  },
  
  /**
   * 显示警告提示
   */
  warning(title, duration = 1500) {
    uni.showToast({
      title,
      icon: 'none',
      duration
    })
  },
  
  /**
   * 显示加载中
   */
  loading(title = '加载中...') {
    uni.showLoading({
      title,
      mask: true
    })
  },
  
  /**
   * 隐藏加载中
   */
  hideLoading() {
    uni.hideLoading()
  },
  
  /**
   * 显示确认对话框
   */
  confirm(title, content) {
    return new Promise((resolve) => {
      uni.showModal({
        title,
        content,
        success: (res) => {
          resolve(res.confirm)
        }
      })
    })
  }
}

export {
  dateUtils,
  validateUtils,
  stringUtils,
  dataUtils,
  storageUtils,
  deviceUtils,
  toastUtils,
  imageUtils
}

export default {
  dateUtils,
  validateUtils,
  stringUtils,
  dataUtils,
  storageUtils,
  deviceUtils,
  toastUtils,
  imageUtils
}
