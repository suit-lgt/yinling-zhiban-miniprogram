/**
 * 主题管理工具
 * 处理应用主题切换和字体大小设置
 */

import { storage, STORAGE_KEYS } from '../rules/state-management'

const THEME_CONFIG = {
  light: {
    name: '浅色',
    colors: {
      primary: '#3792ED',
      background: '#FFFFFF',
      card: '#FFFFFF',
      text: '#333333',
      textSecondary: '#666666',
      border: '#E5E5E5'
    }
  },
  dark: {
    name: '深色',
    colors: {
      primary: '#5BA3F5',
      background: '#1A1A1A',
      card: '#2A2A2A',
      text: '#FFFFFF',
      textSecondary: '#AAAAAA',
      border: '#3A3A3A'
    }
  }
}

const FONT_SIZE_CONFIG = {
  standard: {
    name: '标准',
    scale: 1,
    body: '18px',
    title: '24px',
    button: '18px'
  },
  large: {
    name: '大',
    scale: 1.2,
    body: '20px',
    title: '26px',
    button: '20px'
  },
  extraLarge: {
    name: '特大',
    scale: 1.4,
    body: '22px',
    title: '28px',
    button: '22px'
  }
}

class ThemeManager {
  constructor() {
    this.currentTheme = 'light'
    this.currentFontSize = 'standard'
    this.listeners = []
    this.init()
  }

  init() {
    this.currentTheme = storage.get(STORAGE_KEYS.THEME, 'light')
    this.currentFontSize = storage.get(STORAGE_KEYS.FONT_SIZE, 'standard')
    this.applyTheme()
    this.applyFontSize()
  }

  getTheme() {
    return this.currentTheme
  }

  getThemeConfig() {
    return THEME_CONFIG[this.currentTheme]
  }

  getFontSize() {
    return this.currentFontSize
  }

  getFontSizeConfig() {
    return FONT_SIZE_CONFIG[this.currentFontSize]
  }

  setTheme(theme) {
    if (!THEME_CONFIG[theme]) {
      console.error('不支持的主题:', theme)
      return
    }

    this.currentTheme = theme
    storage.set(STORAGE_KEYS.THEME, theme)
    storage.set(STORAGE_KEYS.IS_DARK, theme === 'dark')
    this.applyTheme()
    this.notifyListeners()
  }

  setFontSize(size) {
    if (!FONT_SIZE_CONFIG[size]) {
      console.error('不支持的字体大小:', size)
      return
    }

    this.currentFontSize = size
    storage.set(STORAGE_KEYS.FONT_SIZE, size)
    storage.set('globalFontScale', FONT_SIZE_CONFIG[size].scale)
    this.applyFontSize()
    this.notifyListeners()
  }

  applyTheme() {
    const config = THEME_CONFIG[this.currentTheme]
    
    // 浏览器环境不支持 setBackgroundColor，仅更新 CSS 变量
    // uni.setBackgroundColor({
    //   backgroundColor: config.colors.background
    // })

    this.updateCssVariables(config.colors)
  }

  applyFontSize() {
    const config = FONT_SIZE_CONFIG[this.currentFontSize]
    localStorage.setItem('globalFontScale', config.scale)
  }

  updateCssVariables(colors) {
    Object.keys(colors).forEach(key => {
      localStorage.setItem('theme_' + key, colors[key])
    })
  }

  toggle() {
    this.setTheme(this.currentTheme === 'light' ? 'dark' : 'light')
  }

  increaseFontSize() {
    const sizes = ['standard', 'large', 'extraLarge']
    const currentIndex = sizes.indexOf(this.currentFontSize)
    if (currentIndex < sizes.length - 1) {
      this.setFontSize(sizes[currentIndex + 1])
    }
  }

  decreaseFontSize() {
    const sizes = ['standard', 'large', 'extraLarge']
    const currentIndex = sizes.indexOf(this.currentFontSize)
    if (currentIndex > 0) {
      this.setFontSize(sizes[currentIndex - 1])
    }
  }

  subscribe(callback) {
    this.listeners.push(callback)
    return () => {
      this.listeners = this.listeners.filter(l => l !== callback)
    }
  }

  notifyListeners() {
    this.listeners.forEach(callback => {
      callback({
        theme: this.currentTheme,
        fontSize: this.currentFontSize,
        themeConfig: this.getThemeConfig(),
        fontSizeConfig: this.getFontSizeConfig()
      })
    })
  }
}

export const themeManager = new ThemeManager()

export default themeManager
