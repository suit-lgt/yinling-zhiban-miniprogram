/**
 * uni-app API 兼容层
 * 在浏览器环境中模拟 uni-app API
 */

const uni = {}

// 存储相关
uni.getStorageSync = function(key) {
  const data = localStorage.getItem(key)
  return data ? JSON.parse(data) : null
}

uni.setStorageSync = function(key, value) {
  localStorage.setItem(key, JSON.stringify(value))
}

uni.removeStorageSync = function(key) {
  localStorage.removeItem(key)
}

uni.clearStorageSync = function() {
  localStorage.clear()
}

uni.getStorageInfoSync = function() {
  return {
    keys: Object.keys(localStorage),
    currentSize: localStorage.length,
    keys: Array.from({ length: localStorage.length }, (_, i) => localStorage.key(i))
  }
}

// 路由相关
uni.navigateTo = function(options) {
  if (options.url) {
    const path = options.url.replace('/pages', '').replace('/pagesB', '').replace('/pagesA', '')
    if (router && router.push) {
      router.push(path)
    } else {
      window.location.hash = path
    }
  }
  options.success && options.success()
}

uni.navigateBack = function(options) {
  if (router && router.back) {
    router.back()
  } else {
    window.history.back()
  }
  options && options.success && options.success()
}

uni.switchTab = function(options) {
  if (options.url) {
    const path = options.url.replace('/pages', '').replace('/pagesB', '').replace('/pagesA', '')
    if (router && router.push) {
      router.push(path)
    } else {
      window.location.hash = path
    }
  }
  options.success && options.success()
}

uni.reLaunch = function(options) {
  if (options.url) {
    const path = options.url.replace('/pages', '').replace('/pagesB', '').replace('/pagesA', '')
    if (router && router.push) {
      router.push(path)
    } else {
      window.location.hash = path
    }
  }
  options.success && options.success()
}

uni.redirectTo = function(options) {
  uni.navigateTo(options)
}

uni.preloadPage = function() {}

// 界面相关
uni.showToast = function(options) {
  const message = options.title || ''
  const icon = options.icon || 'none'
  
  if (icon === 'success') {
    alert('✓ ' + message)
  } else {
    alert(message)
  }
  
  if (options.duration && options.duration > 0) {
    setTimeout(() => {
      options.complete && options.complete()
    }, options.duration)
  }
}

uni.hideToast = function() {}

uni.showLoading = function(options) {
  const title = options.title || '加载中...'
  const loadingEl = document.getElementById('global-loading')
  if (loadingEl) {
    loadingEl.textContent = title
    loadingEl.style.display = 'flex'
  } else {
    const el = document.createElement('div')
    el.id = 'global-loading'
    el.style.cssText = 'position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,0.5);display:flex;justify-content:center;align-items:center;z-index:9999;'
    el.innerHTML = '<div style="background:#fff;padding:20px 40px;border-radius:8px;">' + title + '</div>'
    document.body.appendChild(el)
  }
  options.success && options.success()
}

uni.hideLoading = function() {
  const loadingEl = document.getElementById('global-loading')
  if (loadingEl) {
    loadingEl.style.display = 'none'
  }
}

uni.showModal = function(options) {
  const confirmed = confirm(options.content || '')
  if (confirmed) {
    options.success && options.success({ confirm: true })
  } else {
    options.success && options.success({ confirm: false })
  }
  options.complete && options.complete()
}

uni.showActionSheet = function(options) {
  alert('功能开发中')
}

uni.setNavigationBarTitle = function(options) {
  if (options.title) {
    document.title = options.title
  }
}

uni.setNavigationBarColor = function() {}

uni.showTabBar = function() {}

uni.hideTabBar = function() {}

uni.setTabBarItem = function() {}

uni.setTabBarStyle = function() {}

// 设备相关
uni.getSystemInfo = function(options) {
  const info = {
    platform: 'browser',
    brand: 'Chrome',
    model: 'Desktop',
    system: 'Windows',
    language: 'zh-CN',
    pixelRatio: window.devicePixelRatio || 1,
    screenWidth: window.screen.width,
    screenHeight: window.screen.height,
    windowWidth: window.innerWidth,
    windowHeight: window.innerHeight,
    statusBarHeight: 0,
    navigationBarHeight: 44
  }
  options.success && options.success(info)
}

uni.getSystemInfoSync = function() {
  return {
    platform: 'browser',
    brand: 'Chrome',
    model: 'Desktop',
    system: 'Windows',
    language: 'zh-CN',
    pixelRatio: window.devicePixelRatio || 1,
    screenWidth: window.screen.width,
    screenHeight: window.screen.height,
    windowWidth: window.innerWidth,
    windowHeight: window.innerHeight,
    statusBarHeight: 0,
    navigationBarHeight: 44
  }
}

uni.getNetworkType = function(options) {
  options.success && options.success({ networkType: 'wifi' })
}

uni.getNetworkTypeSync = function() {
  return 'wifi'
}

uni.getLocation = function(options) {
  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(
      (position) => {
        options.success && options.success({
          latitude: position.coords.latitude,
          longitude: position.coords.longitude
        })
      },
      () => {
        options.fail && options.fail({ errMsg: '获取位置失败' })
      }
    )
  } else {
    options.fail && options.fail({ errMsg: '不支持定位' })
  }
}

uni.makePhoneCall = function(options) {
  if (options.phoneNumber) {
    window.location.href = 'tel:' + options.phoneNumber
  }
}

uni.vibrateShort = function(options) {
  if (navigator.vibrate) {
    navigator.vibrate(10)
  }
}

uni.vibrateLong = function(options) {
  if (navigator.vibrate) {
    navigator.vibrate(400)
  }
}

uni.addPhoneContact = function() {}

uni.scanCode = function(options) {
  alert('扫码功能需要相机权限')
  options.fail && options.fail({ errMsg: 'not supported' })
}

uni.chooseImage = function(options) {
  const input = document.createElement('input')
  input.type = 'file'
  input.accept = 'image/*'
  input.multiple = options && options.count > 1
  input.onchange = (e) => {
    const files = Array.from(e.target.files)
    const count = options && options.count ? Math.min(options.count, files.length) : files.length
    const selectedFiles = files.slice(0, count)
    
    const tempFilePaths = []
    const tempFiles = []
    
    let completed = 0
    
    selectedFiles.forEach((file, index) => {
      const blobUrl = URL.createObjectURL(file)
      tempFilePaths.push(blobUrl)
      
      const img = new Image()
      img.onload = function() {
        tempFiles.push({
          path: blobUrl,
          name: file.name,
          size: file.size,
          width: img.width,
          height: img.height,
          type: file.type,
          lastModified: file.lastModified,
          lastModifiedDate: new Date(file.lastModified)
        })
        
        completed++
        if (completed === selectedFiles.length) {
          options.success && options.success({
            tempFilePaths: tempFilePaths,
            tempFiles: tempFiles
          })
        }
      }
      img.onerror = function() {
        tempFiles.push({
          path: blobUrl,
          name: file.name,
          size: file.size,
          type: file.type,
          lastModified: file.lastModified,
          lastModifiedDate: new Date(file.lastModified)
        })
        
        completed++
        if (completed === selectedFiles.length) {
          options.success && options.success({
            tempFilePaths: tempFilePaths,
            tempFiles: tempFiles
          })
        }
      }
      img.src = blobUrl
    })
    
    if (selectedFiles.length === 0) {
      options.success && options.success({
        tempFilePaths: [],
        tempFiles: []
      })
    }
  }
  input.click()
}

uni.chooseVideo = function(options) {
  alert('视频选择功能开发中')
}

uni.getImageInfo = function(options) {
  const src = options && options.src
  if (!src) {
    options.fail && options.fail({ errMsg: '图片路径不能为空' })
    return
  }
  
  const img = new Image()
  img.crossOrigin = 'anonymous'
  
  img.onload = function() {
    const info = {
      width: img.width,
      height: img.height,
      path: src,
      type: src.split('.').pop().toLowerCase(),
      orientation: 0,
      errMsg: 'getImageInfo:ok'
    }
    
    if (img.width === 0 || img.height === 0) {
      options.fail && options.fail({ errMsg: '获取图片信息失败' })
      return
    }
    
    options.success && options.success(info)
  }
  
  img.onerror = function() {
    options.fail && options.fail({ errMsg: '图片加载失败，请检查路径是否正确' })
  }
  
  if (src.startsWith('blob:') || src.startsWith('data:') || src.startsWith('http')) {
    img.src = src
  } else {
    img.src = src
  }
}

uni.compressImage = function(options) {
  const src = options && options.src
  const quality = options && options.quality ? options.quality / 100 : 0.8
  
  if (!src) {
    options.fail && options.fail({ errMsg: '图片路径不能为空' })
    return
  }
  
  const img = new Image()
  img.onload = function() {
    const canvas = document.createElement('canvas')
    const ctx = canvas.getContext('2d')
    
    let width = img.width
    let height = img.height
    
    if (options && options.width) {
      width = options.width
      height = (img.height / img.width) * width
    }
    if (options && options.height && (!options || !options.width)) {
      height = options.height
      width = (img.width / img.height) * height
    }
    
    canvas.width = width
    canvas.height = height
    ctx.drawImage(img, 0, 0, width, height)
    
    canvas.toBlob(function(blob) {
      const compressedSrc = URL.createObjectURL(blob)
      options.success && options.success({
        tempFilePath: compressedSrc,
        size: blob.size
      })
    }, 'image/jpeg', quality)
  }
  
  img.onerror = function() {
    options.fail && options.fail({ errMsg: '图片压缩失败' })
  }
  
  img.src = src
}

uni.saveImageToPhotosAlbum = function(options) {
  const filePath = options && options.filePath
  if (!filePath) {
    options.fail && options.fail({ errMsg: '图片路径不能为空' })
    return
  }
  
  const link = document.createElement('a')
  link.href = filePath
  link.download = 'image_' + Date.now() + '.jpg'
  link.target = '_blank'
  
  document.body.appendChild(link)
  link.click()
  document.body.removeChild(link)
  
  options.success && options.success({ errMsg: 'saveImageToPhotosAlbum:ok' })
}

uni.getBackgroundAudioManager = function() {
  return {}
}

uni.getRecorderManager = function() {
  return {
    start: function() {},
    stop: function() {},
    pause: function() {},
    resume: function() {}
  }
}

// 网络相关
uni.request = function(options) {
  const xhr = new XMLHttpRequest()
  xhr.open(options.method || 'GET', options.url)
  xhr.onload = () => {
    if (xhr.status >= 200 && xhr.status < 300) {
      options.success && options.success({
        data: JSON.parse(xhr.responseText),
        statusCode: xhr.status,
        header: {}
      })
    } else {
      options.fail && options.fail({ errMsg: '请求失败' })
    }
  }
  xhr.onerror = () => {
    options.fail && options.fail({ errMsg: '网络错误' })
  }
  if (options.header) {
    Object.keys(options.header).forEach(key => {
      xhr.setRequestHeader(key, options.header[key])
    })
  }
  xhr.send(options.data)
}

uni.uploadFile = function(options) {
  const input = document.createElement('input')
  input.type = 'file'
  input.onchange = (e) => {
    const file = e.target.files[0]
    const formData = new FormData()
    formData.append('file', file)
    
    const xhr = new XMLHttpRequest()
    xhr.open('POST', options.url)
    xhr.onload = () => {
      options.success && options.success({
        data: xhr.responseText,
        statusCode: xhr.status
      })
    }
    xhr.send(formData)
  }
  input.click()
}

uni.downloadFile = function(options) {
  alert('下载功能需要后端支持')
  options.fail && options.fail({ errMsg: 'not supported' })
}

// 运行环境
uni.getEnv = function() {
  return { plus: false, __uniConfig: {} }
}

uni.canIUse = function() {
  return false
}

uni.env = {
  VERSION: '1.0.0',
  APPID: 'browser',
  CLIENT: 'browser',
  PLATFORM: 'browser'
}

// 事件相关
uni.$on = function(event, callback) {
  window.addEventListener(event, callback)
}

uni.$off = function(event, callback) {
  window.removeEventListener(event, callback)
}

uni.$emit = function(event, data) {
  window.dispatchEvent(new CustomEvent(event, { detail: data }))
}

uni.$once = function(event, callback) {
  const wrapper = (e) => {
    callback(e.detail)
    window.removeEventListener(event, wrapper)
  }
  window.addEventListener(event, wrapper)
}

// 原生插件
uni.requireNativePlugin = function(name) {
  console.warn('原生插件 ' + name + ' 在浏览器中不可用')
  return null
}

// 设置
uni.setStorage = function(key, value) {
  localStorage.setItem(key, JSON.stringify(value))
}

uni.getStorage = function(key) {
  return localStorage.getItem(key)
}

uni.removeStorage = function(key) {
  localStorage.removeItem(key)
}

// 性能
uni.createSelectorQuery = function() {
  return {
    select: function() { return this },
    selectAll: function() { return this },
    boundingClientRect: function() { return this },
    scrollOffset: function() { return this },
    exec: function() { return [] }
  }
}

uni.createIntersectionObserver = function() {
  return {
    observe: function() {},
    disconnect: function() {}
  }
}

// 页面间通信
uni.eventChannel = {
  on: function() {},
  emit: function() {},
  off: function() {}
}

uni.getOpenerEventChannel = function() {
  return uni.eventChannel
}

// 导出
export default uni
export { uni }
