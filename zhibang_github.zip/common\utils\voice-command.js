/**
 * 语音命令处理器
 * 统一处理所有语音命令
 */

import { memoAPI, healthAPI } from '@/api'
import { voiceManager } from './voice'

class VoiceCommandHandler {
  constructor() {
    this.commands = this.initCommands()
  }

  initCommands() {
    return {
      // 页面导航
      navigate: {
        keywords: ['去', '打开', '进入', '跳转', '到', '首页', '健康', '问答', '备忘录', '我的'],
        handler: (text, context) => this.handleNavigate(text, context)
      },
      
      // 天气查询
      weather: {
        keywords: ['天气', '气温', '温度', '天气怎么样'],
        handler: (text, context) => this.handleWeather(text, context)
      },
      
      // 健康数据查询
      health: {
        keywords: ['血压', '血糖', '心率', '健康', '身体'],
        handler: (text, context) => this.handleHealth(text, context)
      },
      
      // 提醒/备忘录
      reminder: {
        keywords: ['提醒', '备忘录', '记事', '记录', '添加'],
        handler: (text, context) => this.handleReminder(text, context)
      },
      
      // 打电话
      call: {
        keywords: ['打电话', '拨打', '呼叫', '打电话给', '联系'],
        handler: (text, context) => this.handleCall(text, context)
      },
      
      // SOS紧急求助
      sos: {
        keywords: ['sos', '紧急', '救命', '求助', '帮助'],
        handler: (text, context) => this.handleSos(text, context)
      },
      
      // 打车
      taxi: {
        keywords: ['打车', '叫车', '租车', '乘车'],
        handler: (text, context) => this.handleTaxi(text, context)
      },
      
      // 挂号
      hospital: {
        keywords: ['挂号', '医院', '看病', '门诊'],
        handler: (text, context) => this.handleHospital(text, context)
      },
      
      // 用药提醒
      medicine: {
        keywords: ['吃药', '用药', '服药', '药'],
        handler: (text, context) => this.handleMedicine(text, context)
      },
      
      // 反诈
      fraud: {
        keywords: ['反诈', '防骗', '诈骗', '骗子'],
        handler: (text, context) => this.handleFraud(text, context)
      },
      
      // 朗读
      read: {
        keywords: ['朗读', '读出来', '读一下', '播放'],
        handler: (text, context) => this.handleRead(text, context)
      },
      
      // 关闭/返回
      close: {
        keywords: ['关闭', '返回', '退出', '回去'],
        handler: (text, context) => this.handleClose(text, context)
      },
      
      // 帮助
      help: {
        keywords: ['帮助', '帮助我', '有什么用', '能做什么', '命令'],
        handler: (text, context) => this.handleHelp(text, context)
      },
      
      // 日期时间
      datetime: {
        keywords: ['几点', '什么时候', '日期', '今天几号', '现在几点'],
        handler: (text, context) => this.handleDatetime(text, context)
      },
      
      // 设置
      settings: {
        keywords: ['设置', '调整', '配置', '声音', '音量'],
        handler: (text, context) => this.handleSettings(text, context)
      }
    }
  }

  async process(text, context = {}) {
    const lowerText = text.toLowerCase().replace(/[？?。，,！!]/g, '')
    
    // 遍历所有命令类型
    for (const [cmdType, cmd] of Object.entries(this.commands)) {
      for (const keyword of cmd.keywords) {
        if (lowerText.includes(keyword)) {
          const result = await cmd.handler(text, context)
          return result
        }
      }
    }
    
    // 默认回答
    return {
      response: `您说"${text}"，我理解了。你可以尝试说：\n- "打开健康页面"查看健康数据\n- "今天天气怎么样"\n- "帮我设置提醒"\n- "拨打紧急电话"\n- "帮助"查看更多命令`,
      action: null
    }
  }

  handleNavigate(text, context) {
    const lowerText = text.toLowerCase()
    let path = '/'
    let pageName = '首页'
    
    if (lowerText.includes('健康')) {
      path = '/health'
      pageName = '健康'
    } else if (lowerText.includes('问答')) {
      path = '/qa'
      pageName = '问答'
    } else if (lowerText.includes('备忘录') || lowerText.includes('工具')) {
      path = '/tools'
      pageName = '备忘录'
    } else if (lowerText.includes('我的') || lowerText.includes('个人')) {
      path = '/profile'
      pageName = '我的'
    } else if (lowerText.includes('首页')) {
      path = '/'
      pageName = '首页'
    }
    
    return {
      response: `好的，正在为您打开${pageName}页面。`,
      action: { type: 'goTo', path, pageName }
    }
  }

  async handleWeather(text, context) {
    try {
      const weather = await context.weatherAPI?.() || context.weather || { temp: '--', text: '未知' }
      const response = `今天天气${weather.text || '未知'}，气温${weather.temp || '--'}度。`
      return {
        response,
        action: null
      }
    } catch (e) {
      return {
        response: '抱歉，暂时无法获取天气信息。',
        action: null
      }
    }
  }

  async handleHealth(text, context) {
    try {
      const stats = healthAPI.getHealthStats()
      let response = '您的健康数据如下：'
      
      if (stats.bloodPressure.latest) {
        response += `血压${stats.bloodPressure.latest.value}；`
      } else {
        response += '血压未记录；'
      }
      
      if (stats.bloodSugar.latest) {
        response += `血糖${stats.bloodSugar.latest.value}；`
      } else {
        response += '血糖未记录；'
      }
      
      if (stats.heartRate.latest) {
        response += `心率${stats.heartRate.latest.value}。`
      } else {
        response += '心率未记录。'
      }
      
      return {
        response,
        action: { type: 'goTo', path: '/health/record', pageName: '健康记录' }
      }
    } catch (e) {
      return {
        response: '抱歉，无法获取您的健康数据。',
        action: null
      }
    }
  }

  handleReminder(text, context) {
    const title = this.extractTitle(text)
    return {
      response: `好的，我帮您创建提醒："${title}"。请在备忘录页面确认或修改具体时间。`,
      action: { type: 'addMemo', params: { title } }
    }
  }

  handleCall(text, context) {
    return {
      response: '好的，正在为您拨打紧急联系人电话。',
      action: { type: 'callPhone' }
    }
  }

  handleSos(text, context) {
    return {
      response: '紧急求助模式已启动，请确认是否立即拨打急救电话？',
      action: { type: 'sosConfirm' }
    }
  }

  handleTaxi(text, context) {
    return {
      response: '好的，正在为您打开打车功能。',
      action: { type: 'goTo', path: '/health/taxi', pageName: '打车' }
    }
  }

  handleHospital(text, context) {
    return {
      response: '好的，正在为您打开医院挂号功能。',
      action: { type: 'goTo', path: '/health/hospital', pageName: '挂号' }
    }
  }

  handleMedicine(text, context) {
    return {
      response: '好的，正在为您打开用药提醒设置。',
      action: { type: 'goTo', path: '/health/medicine', pageName: '用药提醒' }
    }
  }

  handleFraud(text, context) {
    return {
      response: '好的，正在为您打开反诈宣传页面。',
      action: { type: 'goTo', path: '/health/fraud', pageName: '反诈宣传' }
    }
  }

  handleRead(text, context) {
    return {
      response: context.lastResponse || '没有可朗读的内容。',
      action: { type: 'speak' }
    }
  }

  handleClose(text, context) {
    return {
      response: '好的，正在返回上一页。',
      action: { type: 'goBack' }
    }
  }

  handleHelp(text, context) {
    return {
      response: `我可以帮您完成以下操作：
1. 导航：说"打开健康页面"可跳转
2. 天气：说"今天天气怎么样"查询天气
3. 健康：说"查看血压/血糖/心率"
4. 提醒：说"帮我设置提醒"创建备忘录
5. 打电话：说"拨打紧急电话"
6. SOS：说"紧急求助"进入紧急模式
7. 打车：说"帮我打车"
8. 挂号：说"我要挂号"
9. 用药：说"提醒我吃药"
10. 反诈：说"打开反诈宣传"

您可以直接说出您想要的帮助。`,
      action: null
    }
  }

  handleDatetime(text, context) {
    const now = new Date()
    const hours = now.getHours()
    const minutes = now.getMinutes().toString().padStart(2, '0')
    const month = now.getMonth() + 1
    const date = now.getDate()
    const weekDays = ['星期日', '星期一', '星期二', '星期三', '星期四', '星期五', '星期六']
    const weekDay = weekDays[now.getDay()]
    
    return {
      response: `现在时间是${hours}点${minutes}分，今天是${month}月${date}日，${weekDay}。`,
      action: null
    }
  }

  handleSettings(text, context) {
    const lowerText = text.toLowerCase()
    
    if (lowerText.includes('声音') || lowerText.includes('音量')) {
      return {
        response: '好的，正在打开声音设置。您可以在"我的"页面中调整语音播报音量。',
        action: { type: 'goTo', path: '/profile/settings', pageName: '设置' }
      }
    }
    
    return {
      response: '好的，正在打开设置页面。',
      action: { type: 'goTo', path: '/profile/settings', pageName: '设置' }
    }
  }

  extractTitle(text) {
    const patterns = [
      /(?:提醒|记录|添加)(.*?)(?:的|到|吧|$)/,
      /(?:帮|帮我)(.*?)(?:提醒|记录)/,
      /(.*?)(?:提醒|记事)/
    ]
    
    for (const pattern of patterns) {
      const match = text.match(pattern)
      if (match && match[1]) {
        return match[1].trim()
      }
    }
    
    return '新提醒'
  }
}

export const voiceCommandHandler = new VoiceCommandHandler()

export default voiceCommandHandler
