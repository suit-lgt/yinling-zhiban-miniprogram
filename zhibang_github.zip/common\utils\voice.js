/**
 * 语音工具类
 * 支持语音识别和语音合成
 * 使用 Web Speech API
 */

class VoiceManager {
  constructor() {
    this.recognition = null
    this.synthesis = window.speechSynthesis || null
    this.isListening = false
    this.isSpeaking = false
    this.onResult = null
    this.onError = null
    this.onEnd = null
    this.onStart = null
    
    this.initRecognition()
  }

  initRecognition() {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition
    
    if (!SpeechRecognition) {
      console.warn('浏览器不支持语音识别')
      return
    }
    
    this.recognition = new SpeechRecognition()
    this.recognition.continuous = false
    this.recognition.interimResults = true
    this.recognition.lang = 'zh-CN'
    this.recognition.maxAlternatives = 1
    
    this.recognition.onstart = () => {
      this.isListening = true
      this.onStart && this.onStart()
    }
    
    this.recognition.onresult = (event) => {
      const results = event.results
      const lastResult = results[results.length - 1]
      const transcript = lastResult[0].transcript
      
      this.onResult && this.onResult({
        transcript,
        isFinal: lastResult.isFinal
      })
    }
    
    this.recognition.onerror = (event) => {
      console.error('语音识别错误:', event.error)
      this.isListening = false
      this.onError && this.onError(event.error)
    }
    
    this.recognition.onend = () => {
      this.isListening = false
      this.onEnd && this.onEnd()
    }
  }

  startRecognition() {
    if (!this.recognition) {
      this.onError && this.onError('语音识别不可用')
      return false
    }
    
    try {
      this.recognition.start()
      return true
    } catch (e) {
      console.error('启动语音识别失败:', e)
      return false
    }
  }

  stopRecognition() {
    if (this.recognition && this.isListening) {
      this.recognition.stop()
    }
  }

  speak(text, lang = 'zh-CN') {
    if (!this.synthesis) {
      console.warn('浏览器不支持语音合成')
      return false
    }
    
    this.stopSpeaking()
    
    const utterance = new SpeechSynthesisUtterance(text)
    utterance.lang = lang
    utterance.rate = 0.9
    utterance.pitch = 1
    utterance.volume = 1
    
    utterance.onstart = () => {
      this.isSpeaking = true
    }
    
    utterance.onend = () => {
      this.isSpeaking = false
    }
    
    utterance.onerror = () => {
      this.isSpeaking = false
    }
    
    this.synthesis.speak(utterance)
    return true
  }

  stopSpeaking() {
    if (this.synthesis) {
      this.synthesis.cancel()
      this.isSpeaking = false
    }
  }

  isSupported() {
    return !!(window.SpeechRecognition || window.webkitSpeechRecognition) || !!window.speechSynthesis
  }

  isRecognitionSupported() {
    return !!(window.SpeechRecognition || window.webkitSpeechRecognition)
  }

  isSynthesisSupported() {
    return !!window.speechSynthesis
  }
}

export const voiceManager = new VoiceManager()

export default voiceManager
