Component({
  properties: {
    type: { type: String, value: '' },
    colorStart: { type: String, value: '#FF6B6B' },
    colorEnd: { type: String, value: '#EE5A24' },
    size: { type: Number, value: 112 }
  }
})
