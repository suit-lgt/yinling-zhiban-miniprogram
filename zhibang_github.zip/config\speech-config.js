/**
 * 科大讯飞语音服务配置
 * 
 * 使用说明：
 * 1. 访问 https://www.xfyun.cn/ 注册账号
 * 2. 创建应用并开通"语音听写"和"在线语音合成"服务
 * 3. 获取 AppID、APIKey、APISecret
 * 4. 将以下占位符替换为你自己的真实密钥
 * 
 * ⚠️ 安全提示：请勿将真实密钥提交到 GitHub！
 */

module.exports = {
  // 科大讯飞开放平台配置
  xfyun: {
    // 星火认知大模型（AI问答）
    spark: {
      appId: 'YOUR_XFYUN_APP_ID',         // 替换为你的 AppID
      apiKey: 'YOUR_XFYUN_API_KEY',       // 替换为你的 APIKey
      apiSecret: 'YOUR_XFYUN_API_SECRET', // 替换为你的 APISecret
      // 服务地址
      host: 'spark-api.xf-yun.com',
      uri: '/v1.1/chat',
      // 模型版本
      model: 'lite',  // lite/general/pro/max
      // 模型域名映射
      modelDomain: {
        'lite': 'lite',
        'general': 'generalv3',
        'pro': 'generalv3.5',
        'max': 'generalv3.5'
      }
    },
    
    // 语音听写（语音识别）- 已开通
    iat: {
      appId: 'YOUR_XFYUN_APP_ID',         // 替换为你的 AppID
      apiKey: 'YOUR_XFYUN_API_KEY',       // 替换为你的 APIKey
      apiSecret: 'YOUR_XFYUN_API_SECRET', // 替换为你的 APISecret
      host: 'iat-api.xfyun.cn',
      uri: '/v2/iat',
      language: 'zh_cn',
      domain: 'iat',
      accent: 'mandarin',
      dwa: 'wpgs',
    },
    
    // 在线语音合成 - 待开通
    tts: {
      appId: '',      // 待开通后填写
      apiKey: '',     // 待开通后填写
      apiSecret: '',  // 待开通后填写
      host: 'tts-api.xfyun.cn',
      uri: '/v2/tts',
      voice: 'xiaoyan',
    }
  },
  
  // 录音配置
  recorder: {
    duration: 60000,       // 最长录音时长（毫秒）
    sampleRate: 16000,     // 采样率
    numberOfChannels: 1,   // 录音通道数
    encodeBitRate: 96000,  // 编码码率
    format: 'pcm',         // 音频格式
  },
  
  // 调试模式（未配置密钥时使用模拟数据）
  debug: true
}
