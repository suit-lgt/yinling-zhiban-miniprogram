<template>
  <view class="page">
    <view class="content">
      <text class="title">用户服务协议</text>
      
      <view class="section">
        <text class="section__title">一、服务条款的确认和接纳</text>
        <text class="section__text">
          银龄智伴（以下简称"本应用"）是由开发者提供的面向老年用户的智能助手应用。
          用户在使用本应用时，应遵守以下服务条款。本应用有权根据实际情况修改本协议，
          修改后的协议将在应用内公示，修改后的协议自公示之日起生效。
        </text>
      </view>

      <view class="section">
        <text class="section__title">二、用户信息保护</text>
        <text class="section__text">
          1. 本应用非常重视用户个人信息的保护。
          2. 在用户使用本应用时，本应用可能会收集用户的个人信息，
             包括但不限于手机号、设备信息、位置信息等。
          3. 本应用不会将用户个人信息提供给第三方，除非获得用户明确同意
             或法律法规另有规定。
        </text>
      </view>

      <view class="section">
        <text class="section__title">三、服务的变更、中断和终止</text>
        <text class="section__text">
          1. 本应用有权随时修改、中断或终止服务，且不需对用户或第三方负责。
          2. 如因系统维护或升级的需要，本应用可能需要暂停服务，
             本应用会尽可能提前通知用户。
        </text>
      </view>

      <view class="section">
        <text class="section__title">四、免责声明</text>
        <text class="section__text">
          1. 用户理解并同意，本应用服务按"现状"提供，不提供任何明示或暗示的担保。
          2. 本应用不保证服务一定会满足用户的需求，不保证服务不会中断，
             不保证服务的及时性、安全性和准确性。
        </text>
      </view>

      <view class="section">
        <text class="section__title">五、知识产权</text>
        <text class="section__text">
          本应用的所有内容，包括但不限于文字、图片、图标、音频、视频等，
          其知识产权归本应用所有。未经本应用书面授权，任何人不得以任何方式使用。
        </text>
      </view>

      <view class="section">
        <text class="section__title">六、联系我们</text>
        <text class="section__text">
          如有任何问题或建议，请通过应用内的"意见反馈"功能联系我们。
        </text>
      </view>

      <text class="update-time">最后更新：2024年1月</text>
    </view>
  </view>
</template>

<script>
export default {
  data() {
    return {}
  }
}
</script>

<style lang="scss" scoped>
.page {
  min-height: 100vh;
  background-color: #FFFFFF;
  padding: 16px;
}

.content {
  padding-bottom: 40px;
}

.title {
  display: block;
  font-size: 24px;
  font-weight: bold;
  color: #333333;
  text-align: center;
  margin-bottom: 24px;
}

.section {
  margin-bottom: 20px;
  
  &__title {
    display: block;
    font-size: 16px;
    font-weight: 600;
    color: #333333;
    margin-bottom: 8px;
  }
  
  &__text {
    display: block;
    font-size: 14px;
    color: #666666;
    line-height: 1.8;
    text-align: justify;
  }
}

.update-time {
  display: block;
  font-size: 12px;
  color: #999999;
  text-align: center;
  margin-top: 24px;
}
</style>
