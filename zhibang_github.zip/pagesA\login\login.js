Page({
  data: {
    form: {
      phone: '',
      password: ''
    }
  },
  onPhoneInput(e) {
    this.setData({ 'form.phone': e.detail.value })
  },
  onPasswordInput(e) {
    this.setData({ 'form.password': e.detail.value })
  },
  handleLogin() {
    const { phone, password } = this.data.form
    
    if (!phone) {
      wx.showToast({ title: '请输入手机号', icon: 'none' })
      return
    }
    if (!/^1[3-9]\d{9}$/.test(phone)) {
      wx.showToast({ title: '手机号格式错误', icon: 'none' })
      return
    }
    if (!password) {
      wx.showToast({ title: '请输入密码', icon: 'none' })
      return
    }
    if (password.length < 6) {
      wx.showToast({ title: '密码至少6位', icon: 'none' })
      return
    }
    
    wx.showLoading({ title: '登录中...' })
    
    setTimeout(() => {
      wx.hideLoading()
      
      const user = {
        phone: phone,
        name: '用户' + phone.slice(-4),
        avatar: ''
      }
      
      wx.setStorageSync('userInfo', user)
      wx.setStorageSync('loginDays', 1)
      
      wx.showToast({ title: '登录成功', icon: 'success' })
      
      setTimeout(() => {
        wx.switchTab({ url: '/pages/index/index' })
      }, 1500)
    }, 1000)
  },
  goToRegister() {
    wx.navigateTo({ url: '/pagesA/login/register' })
  },
  goToAgreement() {
    wx.navigateTo({ url: '/pagesA/login/agreement' })
  },
  wechatLogin() {
    wx.showToast({ title: '微信登录开发中', icon: 'none' })
  }
})
