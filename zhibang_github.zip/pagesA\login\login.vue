<template>
  <view class="page">
    <view class="logo">
      <text class="logo__text">银龄智伴</text>
      <text class="logo__sub">让科技温暖每一位老人</text>
    </view>

    <view class="form">
      <yl-input
        v-model="form.phone"
        type="number"
        placeholder="请输入手机号"
        :error="errors.phone"
        clearable
      />
      
      <yl-input
        v-model="form.password"
        type="password"
        placeholder="请输入密码"
        :error="errors.password"
        clearable
      />
      
      <view class="form__options">
        <text class="form__link" @click="goToRegister">立即注册</text>
        <text class="form__link" @click="goToAgreement">用户协议</text>
      </view>
      
      <yl-button type="primary" size="large" block @click="handleLogin">
        登录
      </yl-button>
    </view>

    <view class="other-login">
      <text class="other-login__text">其他登录方式</text>
      <view class="other-login__icons">
        <view class="other-login__icon" @click="wechatLogin">
          <text>微信</text>
        </view>
      </view>
    </view>
  </view>
</template>

<script>
import ylInput from '@/common/components/yl-input.vue'
import ylButton from '@/common/components/yl-button.vue'

export default {
  components: {
    ylInput,
    ylButton
  },
  data() {
    return {
      form: {
        phone: '',
        password: ''
      },
      errors: {
        phone: '',
        password: ''
      }
    }
  },
  methods: {
    validate() {
      let valid = true
      this.errors = { phone: '', password: '' }
      
      if (!this.form.phone) {
        this.errors.phone = '请输入手机号'
        valid = false
      } else if (!/^1[3-9]\d{9}$/.test(this.form.phone)) {
        this.errors.phone = '请输入正确的手机号'
        valid = false
      }
      
      if (!this.form.password) {
        this.errors.password = '请输入密码'
        valid = false
      } else if (this.form.password.length < 6) {
        this.errors.password = '密码长度不能少于6位'
        valid = false
      }
      
      return valid
    },
    handleLogin() {
      if (!this.validate()) return
      
      uni.showLoading({ title: '登录中...' })
      
      setTimeout(() => {
        uni.hideLoading()
        
        const user = {
          phone: this.form.phone,
          name: '用户' + this.form.phone.slice(-4),
          avatar: ''
        }
        
        this.$storage.set(this.$storageKeys.USER, user)
        this.$storage.set('loginDays', 1)
        
        uni.showToast({
          title: '登录成功',
          icon: 'success'
        })
        
        setTimeout(() => {
          uni.switchTab({ url: '/pages/index/index' })
        }, 1500)
      }, 1000)
    },
    goToRegister() {
      uni.navigateTo({ url: '/pagesA/login/register' })
    },
    goToAgreement() {
      uni.navigateTo({ url: '/pagesA/login/agreement' })
    },
    wechatLogin() {
      uni.showToast({
        title: '微信登录开发中',
        icon: 'none'
      })
    }
  }
}
</script>

<style lang="scss" scoped>
.page {
  min-height: 100vh;
  background-color: #FFFFFF;
  padding: 60px 24px;
}

.logo {
  text-align: center;
  margin-bottom: 48px;
  
  &__text {
    display: block;
    font-size: 32px;
    font-weight: bold;
    color: #3792ED;
  }
  
  &__sub {
    display: block;
    font-size: 14px;
    color: #999999;
    margin-top: 8px;
  }
}

.form {
  &__options {
    display: flex;
    justify-content: space-between;
    margin-bottom: 24px;
  }
  
  &__link {
    font-size: 14px;
    color: #3792ED;
  }
}

.other-login {
  margin-top: 48px;
  text-align: center;
  
  &__text {
    font-size: 14px;
    color: #999999;
    display: block;
    margin-bottom: 16px;
  }
  
  &__icons {
    display: flex;
    justify-content: center;
  }
  
  &__icon {
    width: 56px;
    height: 56px;
    display: flex;
    justify-content: center;
    align-items: center;
    background-color: #07C160;
    border-radius: 50%;
    
    text {
      font-size: 14px;
      color: #FFFFFF;
    }
  }
}
</style>
