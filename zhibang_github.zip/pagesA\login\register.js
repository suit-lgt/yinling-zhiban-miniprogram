Page({
  data: {
    form: {
      phone: '',
      code: '',
      password: '',
      confirmPassword: ''
    },
    agreed: false,
    codeText: '发送验证码',
    countdown: 0
  },
  onPhoneInput(e) {
    this.setData({ 'form.phone': e.detail.value })
  },
  onCodeInput(e) {
    this.setData({ 'form.code': e.detail.value })
  },
  onPasswordInput(e) {
    this.setData({ 'form.password': e.detail.value })
  },
  onConfirmPasswordInput(e) {
    this.setData({ 'form.confirmPassword': e.detail.value })
  },
  sendCode() {
    if (this.data.countdown > 0) return
    
    const phone = this.data.form.phone
    if (!phone) {
      wx.showToast({ title: '请输入手机号', icon: 'none' })
      return
    }
    if (!/^1[3-9]\d{9}$/.test(phone)) {
      wx.showToast({ title: '手机号格式错误', icon: 'none' })
      return
    }
    
    this.setData({ countdown: 60, codeText: '60秒后重发' })
    
    const timer = setInterval(() => {
      const countdown = this.data.countdown - 1
      if (countdown <= 0) {
        clearInterval(timer)
        this.setData({ countdown: 0, codeText: '发送验证码' })
      } else {
        this.setData({ countdown, codeText: `${countdown}秒后重发` })
      }
    }, 1000)
    
    wx.showToast({ title: '验证码已发送', icon: 'success' })
  },
  handleAgreementChange(e) {
    this.setData({ agreed: e.detail.value.includes('agree') })
  },
  handleRegister() {
    const { phone, code, password, confirmPassword } = this.data.form
    
    if (!phone) {
      wx.showToast({ title: '请输入手机号', icon: 'none' })
      return
    }
    if (!/^1[3-9]\d{9}$/.test(phone)) {
      wx.showToast({ title: '手机号格式错误', icon: 'none' })
      return
    }
    if (!code) {
      wx.showToast({ title: '请输入验证码', icon: 'none' })
      return
    }
    if (!password) {
      wx.showToast({ title: '请设置密码', icon: 'none' })
      return
    }
    if (password.length < 6) {
      wx.showToast({ title: '密码至少6位', icon: 'none' })
      return
    }
    if (password !== confirmPassword) {
      wx.showToast({ title: '两次密码不一致', icon: 'none' })
      return
    }
    if (!this.data.agreed) {
      wx.showToast({ title: '请同意用户协议', icon: 'none' })
      return
    }
    
    wx.showLoading({ title: '注册中...' })
    
    setTimeout(() => {
      wx.hideLoading()
      
      const user = {
        phone: phone,
        name: '用户' + phone.slice(-4),
        avatar: ''
      }
      
      wx.setStorageSync('userInfo', user)
      
      wx.showToast({ title: '注册成功', icon: 'success' })
      
      setTimeout(() => {
        wx.navigateBack()
      }, 1500)
    }, 1000)
  },
  goToAgreement() {
    wx.navigateTo({ url: '/pagesA/login/agreement' })
  },
  goToLogin() {
    wx.navigateBack()
  }
})
