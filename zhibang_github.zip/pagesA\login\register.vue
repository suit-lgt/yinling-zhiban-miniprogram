<template>
  <view class="page">
    <view class="form">
      <yl-input
        v-model="form.phone"
        type="number"
        placeholder="请输入手机号"
        :error="errors.phone"
        clearable
      />
      
      <view class="code-input">
        <yl-input
          v-model="form.code"
          type="number"
          placeholder="请输入验证码"
          :error="errors.code"
        />
        <view class="code-btn" @click="sendCode">
          <text>{{ codeText }}</text>
        </view>
      </view>
      
      <yl-input
        v-model="form.password"
        type="password"
        placeholder="请设置密码（至少6位）"
        :error="errors.password"
        clearable
      />
      
      <yl-input
        v-model="form.confirmPassword"
        type="password"
        placeholder="请确认密码"
        :error="errors.confirmPassword"
        clearable
      />
      
      <view class="agreement">
        <checkbox-group @change="handleAgreementChange">
          <label>
            <checkbox value="agree" :checked="agreed" />
            <text class="agreement__text">我已阅读并同意</text>
          </label>
        </checkbox-group>
        <text class="agreement__link" @click="goToAgreement">《用户协议》</text>
      </view>
      
      <yl-button type="primary" size="large" block @click="handleRegister">
        注册
      </yl-button>
    </view>

    <view class="login-link">
      <text>已有账号？</text>
      <text class="login-link__btn" @click="goToLogin">立即登录</text>
    </view>
  </view>
</template>

<script>
import ylInput from '@/common/components/yl-input.vue'
import ylButton from '@/common/components/yl-button.vue'

export default {
  components: {
    ylInput,
    ylButton
  },
  data() {
    return {
      form: {
        phone: '',
        code: '',
        password: '',
        confirmPassword: ''
      },
      errors: {
        phone: '',
        code: '',
        password: '',
        confirmPassword: ''
      },
      agreed: false,
      codeText: '发送验证码',
      countdown: 0
    }
  },
  methods: {
    sendCode() {
      if (this.countdown > 0) return
      
      if (!this.form.phone) {
        uni.showToast({ title: '请输入手机号', icon: 'none' })
        return
      }
      
      if (!/^1[3-9]\d{9}$/.test(this.form.phone)) {
        uni.showToast({ title: '手机号格式错误', icon: 'none' })
        return
      }
      
      this.countdown = 60
      this.codeText = `${this.countdown}秒后重发`
      
      const timer = setInterval(() => {
        this.countdown--
        if (this.countdown <= 0) {
          clearInterval(timer)
          this.codeText = '发送验证码'
        } else {
          this.codeText = `${this.countdown}秒后重发`
        }
      }, 1000)
      
      uni.showToast({ title: '验证码已发送', icon: 'success' })
    },
    handleAgreementChange(e) {
      this.agreed = e.detail.value.includes('agree')
    },
    validate() {
      let valid = true
      this.errors = { phone: '', code: '', password: '', confirmPassword: '' }
      
      if (!this.form.phone) {
        this.errors.phone = '请输入手机号'
        valid = false
      } else if (!/^1[3-9]\d{9}$/.test(this.form.phone)) {
        this.errors.phone = '手机号格式错误'
        valid = false
      }
      
      if (!this.form.code) {
        this.errors.code = '请输入验证码'
        valid = false
      }
      
      if (!this.form.password) {
        this.errors.password = '请设置密码'
        valid = false
      } else if (this.form.password.length < 6) {
        this.errors.password = '密码至少6位'
        valid = false
      }
      
      if (this.form.password !== this.form.confirmPassword) {
        this.errors.confirmPassword = '两次密码不一致'
        valid = false
      }
      
      if (!this.agreed) {
        uni.showToast({ title: '请同意用户协议', icon: 'none' })
        valid = false
      }
      
      return valid
    },
    handleRegister() {
      if (!this.validate()) return
      
      uni.showLoading({ title: '注册中...' })
      
      setTimeout(() => {
        uni.hideLoading()
        
        const user = {
          phone: this.form.phone,
          name: '用户' + this.form.phone.slice(-4),
          avatar: ''
        }
        
        this.$storage.set(this.$storageKeys.USER, user)
        
        uni.showToast({
          title: '注册成功',
          icon: 'success'
        })
        
        setTimeout(() => {
          uni.navigateBack()
        }, 1500)
      }, 1000)
    },
    goToAgreement() {
      uni.navigateTo({ url: '/pagesA/login/agreement' })
    },
    goToLogin() {
      uni.navigateBack()
    }
  }
}
</script>

<style lang="scss" scoped>
.page {
  min-height: 100vh;
  background-color: #FFFFFF;
  padding: 40px 24px;
}

.code-input {
  display: flex;
  align-items: center;
  margin-bottom: 16px;
  
  .yl-input {
    flex: 1;
    margin-bottom: 0;
  }
}

.code-btn {
  width: 100px;
  height: 48px;
  display: flex;
  justify-content: center;
  align-items: center;
  background-color: #3792ED;
  border-radius: 8px;
  margin-left: 12px;
  
  text {
    font-size: 14px;
    color: #FFFFFF;
  }
}

.agreement {
  display: flex;
  align-items: center;
  margin-bottom: 24px;
  font-size: 14px;
  
  &__text {
    color: #666666;
    margin-left: 8px;
  }
  
  &__link {
    color: #3792ED;
  }
}

.login-link {
  text-align: center;
  margin-top: 24px;
  font-size: 14px;
  color: #666666;
  
  &__btn {
    color: #3792ED;
    margin-left: 8px;
  }
}
</style>
