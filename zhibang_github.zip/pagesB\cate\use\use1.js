Page({
  data: {},
  startUse() {
    wx.switchTab({ url: '/pages/index/index' })
  }
})
