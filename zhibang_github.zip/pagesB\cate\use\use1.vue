<template>
  <view class="page">
    <view class="guide-section">
      <text class="guide-number">01</text>
      <text class="guide-title">首页功能</text>
      <view class="guide-content">
        <text class="guide-text">首页为您展示天气信息、AI智能助手入口、今日提醒和常用应用快捷入口。您可以快速访问健康模块、备忘录等功能。</text>
      </view>
    </view>
    
    <view class="guide-section">
      <text class="guide-number">02</text>
      <text class="guide-title">健康模块</text>
      <view class="guide-content">
        <text class="guide-text">健康模块提供血压、血糖、心率等健康数据记录，用药提醒设置，以及一键打车、医院挂号、生活缴费等生活服务功能。</text>
      </view>
    </view>
    
    <view class="guide-section">
      <text class="guide-number">03</text>
      <text class="guide-title">智能问答</text>
      <view class="guide-content">
        <text class="guide-text">AI智能助手可以回答您关于健康、生活、防骗等各方面的问题。您可以通过语音或文字输入问题。</text>
      </view>
    </view>
    
    <view class="guide-section">
      <text class="guide-number">04</text>
      <text class="guide-title">备忘录</text>
      <view class="guide-content">
        <text class="guide-text">您可以创建健康医疗、生活服务、社交活动、日常事务等分类的备忘录，并设置提醒时间。</text>
      </view>
    </view>
    
    <view class="guide-section">
      <text class="guide-number">05</text>
      <text class="guide-title">我的设置</text>
      <view class="guide-content">
        <text class="guide-text">在"我的"页面，您可以编辑个人资料、管理紧急联系人、设置深色模式和字体大小、查看意见反馈等。</text>
      </view>
    </view>
    
    <view class="start-btn" @click="startUse">
      <text>开始使用</text>
    </view>
  </view>
</template>

<script>
export default {
  methods: {
    startUse() {
      uni.switchTab({ url: '/pages/index/index' })
    }
  }
}
</script>

<style lang="scss" scoped>
.page {
  min-height: 100vh;
  background-color: #F5F5F5;
  padding: 16px;
  padding-bottom: 80px;
}

.guide-section {
  background-color: #FFFFFF;
  border-radius: 12px;
  padding: 20px;
  margin-bottom: 16px;
}

.guide-number {
  display: block;
  font-size: 24px;
  font-weight: bold;
  color: #3792ED;
  margin-bottom: 8px;
}

.guide-title {
  display: block;
  font-size: 18px;
  font-weight: 600;
  color: #333333;
  margin-bottom: 12px;
}

.guide-content {
  padding-left: 16px;
}

.guide-text {
  font-size: 14px;
  color: #666666;
  line-height: 1.8;
}

.start-btn {
  position: fixed;
  bottom: 80px;
  left: 16px;
  right: 16px;
  height: 56px;
  display: flex;
  justify-content: center;
  align-items: center;
  background-color: #3792ED;
  border-radius: 28px;
  
  text {
    font-size: 18px;
    font-weight: bold;
    color: #FFFFFF;
  }
}
</style>
