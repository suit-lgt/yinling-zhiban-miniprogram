Page({
  data: {
    faqList: [
      {
        question: '如何设置用药提醒？',
        answer: '点击"健康"页面，点击"用药提醒"，添加药品信息后设置提醒时间即可。系统会在设定时间提醒您服药。',
        expanded: false
      },
      {
        question: '如何使用一键打车？',
        answer: '在"健康"页面点击"一键打车"，确认当前位置和目的地后，系统会自动为您呼叫出租车。',
        expanded: false
      },
      {
        question: '如何添加紧急联系人？',
        answer: '进入"我的"页面，点击"紧急联系人"，按照提示添加家人或朋友的联系方式。在紧急情况下可以快速呼叫。',
        expanded: false
      },
      {
        question: '如何修改字体大小？',
        answer: '进入"我的"页面，找到"字体大小"设置，可以选择标准、大、特大三种字体大小。',
        expanded: false
      },
      {
        question: '忘记密码怎么办？',
        answer: '在登录页面点击"忘记密码"，通过手机验证码的方式重置密码。',
        expanded: false
      }
    ]
  },
  toggleFaq(e) {
    const index = e.currentTarget.dataset.index
    const faqList = this.data.faqList.map((item, i) => {
      if (i === index) {
        return { ...item, expanded: !item.expanded }
      }
      return item
    })
    this.setData({ faqList })
  },
  startUse() {
    wx.switchTab({ url: '/pages/index/index' })
  }
})
