<template>
  <view class="page">
    <view class="header">
      <text class="header__title">常见问题解答</text>
    </view>
    
    <view class="faq-list">
      <view
        v-for="(faq, index) in faqList"
        :key="index"
        class="faq-item"
        @click="toggleFaq(index)"
      >
        <view class="faq-item__question">
          <text>{{ faq.question }}</text>
          <text class="faq-item__arrow">{{ faq.expanded ? '∧' : '∨' }}</text>
        </view>
        <view class="faq-item__answer" v-if="faq.expanded">
          <text>{{ faq.answer }}</text>
        </view>
      </view>
    </view>
    
    <view class="tips-card">
      <text class="tips-card__title">需要更多帮助？</text>
      <text class="tips-card__text">您可以通过以下方式获取帮助：</text>
      <text class="tips-card__text">1. 进入"问答"页面咨询AI助手</text>
      <text class="tips-card__text">2. 进入"我的"页面提交意见反馈</text>
      <text class="tips-card__text">3. 拨打客服热线：400-123-4567</text>
    </view>
    
    <view class="start-btn" @click="startUse">
      <text>我知道了</text>
    </view>
  </view>
</template>

<script>
export default {
  data() {
    return {
      faqList: [
        {
          question: '如何设置用药提醒？',
          answer: '点击"健康"页面，点击"用药提醒"，添加药品信息后设置提醒时间即可。系统会在设定时间提醒您服药。',
          expanded: false
        },
        {
          question: '如何使用一键打车？',
          answer: '在"健康"页面点击"一键打车"，确认当前位置和目的地后，系统会自动为您呼叫出租车。',
          expanded: false
        },
        {
          question: '如何添加紧急联系人？',
          answer: '进入"我的"页面，点击"紧急联系人"，按照提示添加家人或朋友的联系方式。在紧急情况下可以快速呼叫。',
          expanded: false
        },
        {
          question: '如何修改字体大小？',
          answer: '进入"我的"页面，找到"字体大小"设置，可以选择标准、大、特大三种字体大小。',
          expanded: false
        },
        {
          question: '忘记密码怎么办？',
          answer: '在登录页面点击"忘记密码"，通过手机验证码的方式重置密码。',
          expanded: false
        }
      ]
    }
  },
  methods: {
    toggleFaq(index) {
      this.faqList[index].expanded = !this.faqList[index].expanded
    },
    startUse() {
      uni.switchTab({ url: '/pages/index/index' })
    }
  }
}
</script>

<style lang="scss" scoped>
.page {
  min-height: 100vh;
  background-color: #F5F5F5;
  padding: 16px;
  padding-bottom: 80px;
}

.header {
  margin-bottom: 24px;
  
  &__title {
    font-size: 24px;
    font-weight: bold;
    color: #333333;
  }
}

.faq-list {
  margin-bottom: 24px;
}

.faq-item {
  background-color: #FFFFFF;
  border-radius: 12px;
  margin-bottom: 8px;
  overflow: hidden;
  
  &__question {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 16px;
    font-size: 16px;
    color: #333333;
  }
  
  &__arrow {
    font-size: 14px;
    color: #999999;
  }
  
  &__answer {
    padding: 0 16px 16px;
    font-size: 14px;
    color: #666666;
    line-height: 1.8;
  }
}

.tips-card {
  padding: 16px;
  background-color: rgba(55, 146, 237, 0.1);
  border-radius: 12px;
  margin-bottom: 24px;
  
  &__title {
    display: block;
    font-size: 16px;
    font-weight: 600;
    color: #3792ED;
    margin-bottom: 12px;
  }
  
  &__text {
    display: block;
    font-size: 14px;
    color: #333333;
    line-height: 1.8;
  }
}

.start-btn {
  position: fixed;
  bottom: 80px;
  left: 16px;
  right: 16px;
  height: 56px;
  display: flex;
  justify-content: center;
  align-items: center;
  background-color: #3792ED;
  border-radius: 28px;
  
  text {
    font-size: 18px;
    font-weight: bold;
    color: #FFFFFF;
  }
}
</style>
