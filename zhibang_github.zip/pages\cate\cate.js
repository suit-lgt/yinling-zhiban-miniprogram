Page({
  data: {
    categories: [
      { id: 1, name: '健康养生', icon: '❤️', color: '#E74C3C' },
      { id: 2, name: '防骗科普', icon: '🛡️', color: '#9B59B6' },
      { id: 3, name: '生活服务', icon: '💡', color: '#3498DB' },
      { id: 4, name: '社交娱乐', icon: '🎮', color: '#F39C12' }
    ],
    apps: [
      { id: 1, name: '用药提醒', icon: '💊', color: '#E74C3C', desc: '设置服药时间，准时提醒', path: '/pages/health/medicine/medicine' },
      { id: 2, name: '健康记录', icon: '❤️', color: '#E74C3C', desc: '记录血压血糖心率', path: '/pages/health/record/record' },
      { id: 3, name: '一键打车', icon: '🚗', color: '#3498DB', desc: '快速叫车出行', path: '/pages/health/taxi/taxi' },
      { id: 4, name: '医院挂号', icon: '🏥', color: '#3498DB', desc: '在线预约挂号', path: '/pages/health/hospital/hospital' },
      { id: 5, name: '生活缴费', icon: '💡', color: '#3498DB', desc: '水电网费缴纳', path: '/pages/health/payment/payment' },
      { id: 6, name: '反诈宣传', icon: '🛡️', color: '#9B59B6', desc: '防骗知识普及', path: '/pages/health/fraud/fraud' }
    ]
  },
  selectCategory(e) {
    const id = e.currentTarget.dataset.id
    const category = this.data.categories.find(c => c.id === id)
    wx.showToast({
      title: category.name,
      icon: 'none'
    })
  },
  openApp(e) {
    const path = e.currentTarget.dataset.path
    wx.navigateTo({ url: path })
  }
})
