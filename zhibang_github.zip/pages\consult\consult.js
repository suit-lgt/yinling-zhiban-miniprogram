// 线上咨询页面
const QUESTIONS_DB = {
  id_card: [
    {
      id: 'id_01',
      question: '身份证过期如何补办？需要哪些材料？',
      preview: '可携带户口簿到户籍地派出所办理...',
      answer: '身份证过期后可前往户籍地或居住地公安机关户籍窗口办理换领。手续简便，一般5-15个工作日可取。',
      materials: ['本人到场（无法到场需出具委托书）', '户口簿原件', '旧身份证（如有）', '近期白底彩色证件照（有相机可现场拍摄）'],
      tip: '建议提前1-3个月办理，过期身份证在宾馆住宿、乘坐飞机等场景会受限。',
      categoryIcon: '🪪', categoryName: '身份证', colorStart: '#fd79a8', colorEnd: '#e84393'
    },
    {
      id: 'id_02',
      question: '身份证丢失如何补办？异地能办吗？',
      preview: '异地也可办理，但需要提供居住证...',
      answer: '身份证丢失后需先到派出所报失，再申请补办。现支持全国范围内异地受理，但需额外提供居住证或暂住证。建议同时报警备案，防止被冒用。',
      materials: ['户口簿原件', '居住证或暂住证（异地办理时需要）', '派出所丢失报告单'],
      tip: '补办身份证期间可申请临时身份证，有效期3个月，可临时使用。',
      categoryIcon: '🪪', categoryName: '身份证', colorStart: '#fd79a8', colorEnd: '#e84393'
    },
    {
      id: 'id_03',
      question: '老年人身份证上的地址如何变更？',
      preview: '需要先办理户口迁移，再换领身份证...',
      answer: '身份证上的地址与户籍地址一致，如需变更需先到派出所办理户口迁移手续，完成后再申请换领新身份证。户口迁移需同时满足迁入地接收条件。',
      materials: ['户口簿', '迁入地接收证明（若跨区户迁）', '房产证或购房合同（落户新地址需要）'],
      tip: '随迁子女老人可申请投靠落户，手续相对简便，可咨询当地派出所。',
      categoryIcon: '🪪', categoryName: '身份证', colorStart: '#fd79a8', colorEnd: '#e84393'
    },
    {
      id: 'id_04',
      question: '第二代身份证何时需要强制换领？',
      preview: '16-25周岁有效期10年，26周岁至....',
      answer: '第二代居民身份证按年龄段分为三档有效期：16-25周岁有效期10年，26-45周岁有效期20年，46周岁以上为长期有效。长期有效的证件无需换领，只有证件损坏、信息变更等情况才需换领。',
      materials: [],
      tip: '可通过"互联网+公安"政务平台查询本人身份证有效期及状态。',
      categoryIcon: '🪪', categoryName: '身份证', colorStart: '#fd79a8', colorEnd: '#e84393'
    }
  ],
  social: [
    {
      id: 'soc_01',
      question: '社保卡丢失如何挂失和补办？',
      preview: '需先挂失再补办，挂失后医保暂停...',
      answer: '社保卡丢失后应立即挂失（防止他人冒用），挂失后医疗保险暂停使用。可通过拨打12333电话、银行网点、社保局窗口或网上服务平台办理挂失，再携带材料前往社保局补办。',
      materials: ['本人身份证原件', '近期1寸免冠彩照2张', '挂失凭证（如有）'],
      tip: '部分城市支持网上申请补办，等待期间可申请临时就医凭证到医院就诊。',
      categoryIcon: '🏥', categoryName: '社保', colorStart: '#45B7D1', colorEnd: '#2980B9'
    },
    {
      id: 'soc_02',
      question: '退休后如何激活社保卡的金融账户？',
      preview: '前往社保卡发行银行柜台办理...',
      answer: '退休后领到社保卡需前往发行银行（卡背面有银行标志）的任意网点办理金融账户激活，激活后退休金将按月存入。首次激活需本人携带身份证到场，不可委托他人。',
      materials: ['本人身份证原件', '社保卡原件', '预留手机号码（用于绑定短信通知）'],
      tip: '激活后建议同时开通手机银行，方便随时查询到账情况。',
      categoryIcon: '🏥', categoryName: '社保', colorStart: '#45B7D1', colorEnd: '#2980B9'
    },
    {
      id: 'soc_03',
      question: '养老金何时到账？如何查询余额？',
      preview: '养老金一般每月1-5日到账...',
      answer: '养老金一般在每月1日至5日之间划拨到社保卡金融账户，具体日期因地区和银行不同。查询方式：①社保卡绑定的银行App；②拨打12333查询；③前往银行柜台或ATM；④当地社保局官网或小程序。',
      materials: [],
      tip: '每年需进行养老金领取资格认证（"生存认证"），可通过国家社会保险公共服务平台App完成，无需到场。',
      categoryIcon: '🏥', categoryName: '社保', colorStart: '#45B7D1', colorEnd: '#2980B9'
    }
  ],
  medical: [
    {
      id: 'med_01',
      question: '老年证（敬老卡）如何办理？有什么优惠？',
      preview: '年满60周岁可申请，享受公交免费等...',
      answer: '年满60周岁的老年人可申请老年优待证（部分城市叫"敬老卡"），享受公共交通免费或优惠、景区减免等福利。可前往户籍所在地街道（乡镇）民政部门或老龄委申请。部分城市可线上办理。',
      materials: ['户口簿或身份证', '本人1寸照片2张', '申请表（窗口领取）'],
      tip: '异地居住的老人可凭居住证在居住地申请临时优待证，享受当地优惠。',
      categoryIcon: '👴', categoryName: '老年证', colorStart: '#26de81', colorEnd: '#20bf6b'
    },
    {
      id: 'med_02',
      question: '慢性病如何申请医保门诊特病？',
      preview: '高血压、糖尿病等慢性病可申请...',
      answer: '高血压、糖尿病、冠心病等常见慢性病患者可向医保部门申请"门诊特殊疾病"认定，认定后门诊买药按住院标准报销，大幅降低医药费。需前往定点医院开具诊断证明后，到医保局申请认定。',
      materials: ['医保卡（社保卡）', '定点医院开具的疾病诊断证明', '近期检查报告单（血压、血糖等）', '身份证'],
      tip: '每个城市纳入特病的病种数量不同，一般20-50种，具体可咨询当地医保局。',
      categoryIcon: '💊', categoryName: '医保', colorStart: '#FF6B6B', colorEnd: '#EE5A24'
    },
    {
      id: 'med_03',
      question: '出院后如何进行医保报销？流程是什么？',
      preview: '出院时医院直接结算，异地需手工报销...',
      answer: '在参保地定点医院住院时，出院时直接刷社保卡结算，自动完成报销，无需另行操作。若在异地就医，需提前办理"异地就医备案"，才能享受直接结算；未备案的异地住院需保留所有票据，回参保地手工报销。',
      materials: ['住院发票（原件）', '出院小结', '检查化验报告单', '社保卡', '身份证'],
      tip: '异地就医备案可通过"国家医保服务平台"App提前办理，非常方便。',
      categoryIcon: '💊', categoryName: '医保', colorStart: '#FF6B6B', colorEnd: '#EE5A24'
    }
  ],
  housing: [
    {
      id: 'hou_01',
      question: '房产证上需要加上子女名字怎么办理？',
      preview: '需到不动产登记中心办理共有权人登记...',
      answer: '在房产证上加名，需前往当地不动产登记中心办理"共有权人登记"。若是父母将房产赠与子女，还需签署赠与协议并缴纳相关税费；若是婚后共同购房的子女加名，手续相对简便。',
      materials: ['不动产权证书原件', '全体产权人身份证', '户口簿', '共有协议书（可在窗口领取样本）', '婚姻状况证明（如需）'],
      tip: '加名涉及契税等税费，建议提前咨询当地不动产登记中心了解费用明细。',
      categoryIcon: '🏠', categoryName: '房产', colorStart: '#f7971e', colorEnd: '#E67E22'
    },
    {
      id: 'hou_02',
      question: '不动产权证（房产证）丢失如何补办？',
      preview: '携带材料到不动产登记中心申请补办...',
      answer: '房产证（不动产权证书）丢失后，需向当地不动产登记中心申请补办。先在报纸上刊登遗失声明，再持材料前往登记中心申请。办理时间约15-30个工作日，补办后原证作废。',
      materials: ['本人身份证', '遗失声明报纸（部分城市可网上公告代替）', '购房合同（如有）', '填写遗失补办申请表'],
      tip: '部分城市已实现网上预约，可减少排队等待时间，建议提前在政务服务平台预约。',
      categoryIcon: '🏠', categoryName: '房产', colorStart: '#f7971e', colorEnd: '#E67E22'
    }
  ],
  travel: [
    {
      id: 'tra_01',
      question: '老年人港澳通行证如何申请？多久有效？',
      preview: '可在户籍地或居住地公安局出入境管理处申请...',
      answer: '港澳通行证（俗称"回乡证"）可在户籍所在地或实际居住地公安局出入境管理处申请，也可通过"粤港澳大湾区"政务平台线上预约。有效期一般为5年或10年，签注有效期另行计算。',
      materials: ['居民身份证', '户口簿', '近期白底彩照', '填写申请表'],
      tip: '进入香港、澳门需另外办理签注（配额制），旺季建议提前2-3个月申请。',
      categoryIcon: '✈️', categoryName: '出行证件', colorStart: '#a18cd1', colorEnd: '#7D3C98'
    },
    {
      id: 'tra_02',
      question: '护照到期如何续签？国内还是国外续签？',
      preview: '在国内可到公安局出入境窗口办理...',
      answer: '护照到期后需换领新护照（护照不可延期，只能换领）。在国内可前往户籍地或居住地公安局出入境管理处办理，约10-15个工作日。在境外可前往中国驻当地使领馆办理，时间较长，建议提前3个月。',
      materials: ['居民身份证', '户口簿', '旧护照（交回销毁）', '近期白底彩照', '填写申请表'],
      tip: '护照还有6个月以上有效期即可换领新护照，无需等到完全过期，可提前办理避免急用。',
      categoryIcon: '✈️', categoryName: '出行证件', colorStart: '#a18cd1', colorEnd: '#7D3C98'
    }
  ],
  pension: [
    {
      id: 'pen_01',
      question: '如何办理退休手续？什么时候可以退休？',
      preview: '女职工55岁（管理岗60岁），男职工60岁...',
      answer: '法定退休年龄：男职工60周岁，女工人50周岁，女干部55周岁。退休手续由所在单位人事部门或社保局办理，个人只需提供相关材料配合审核。灵活就业人员需本人携带材料到社保局办理。',
      materials: ['身份证', '社保卡', '档案材料（单位提供）', '照片2张', '银行账户信息'],
      tip: '2025年起我国开始渐进式延迟退休，具体延迟幅度与出生年月有关，可咨询当地社保局。',
      categoryIcon: '🏦', categoryName: '退休养老', colorStart: '#6C5CE7', colorEnd: '#4834D4'
    },
    {
      id: 'pen_02',
      question: '每年的养老金认证（生存认证）怎么做？',
      preview: '可通过App人脸识别，无需到场...',
      answer: '养老金领取资格认证（生存认证）每年需认证一次。现已支持多种便民方式：①"国家社会保险公共服务平台"App人脸识别；②微信/支付宝小程序认证；③银行App刷脸认证；④也可到社保局或银行网点现场认证。',
      materials: ['手机（需安装相关App）', '社保卡', '身份证（到场认证时需要）'],
      tip: '认证时间窗口一般为每年1月1日至12月31日，建议年初完成认证，避免因未认证导致养老金暂停发放。',
      categoryIcon: '🏦', categoryName: '退休养老', colorStart: '#6C5CE7', colorEnd: '#4834D4'
    }
  ]
}

Page({
  data: {
    activeCategory: 'id_card',
    currentCategoryName: '身份证',
    showAnswer: false,
    selectedItem: {},
    categories: [
      { id: 'id_card',  icon: '🪪', name: '身份证',   colorStart: '#fd79a8', colorEnd: '#e84393' },
      { id: 'social',   icon: '🏥', name: '社保',     colorStart: '#45B7D1', colorEnd: '#2980B9' },
      { id: 'medical',  icon: '👴', name: '老年证/医保', colorStart: '#26de81', colorEnd: '#20bf6b' },
      { id: 'housing',  icon: '🏠', name: '房产',     colorStart: '#f7971e', colorEnd: '#E67E22' },
      { id: 'travel',   icon: '✈️', name: '出行证件', colorStart: '#a18cd1', colorEnd: '#7D3C98' },
      { id: 'pension',  icon: '🏦', name: '退休养老', colorStart: '#6C5CE7', colorEnd: '#4834D4' }
    ],
    currentQuestions: []
  },

  onLoad() {
    this.loadCategory('id_card')
  },

  switchCategory(e) {
    const id = e.currentTarget.dataset.id
    this.loadCategory(id)
  },

  loadCategory(id) {
    const cat = this.data.categories.find(c => c.id === id)
    const questions = QUESTIONS_DB[id] || []
    this.setData({
      activeCategory: id,
      currentCategoryName: cat ? cat.name : '',
      currentQuestions: questions
    })
  },

  openAnswer(e) {
    const item = e.currentTarget.dataset.item
    this.setData({ showAnswer: true, selectedItem: item })
  },

  closeAnswer() {
    this.setData({ showAnswer: false })
  },

  openFreeChat() {
    this.setData({ showAnswer: false })
    wx.navigateTo({ url: '/pages/qa/qa-chat' })
  },

  noop() {}
})
