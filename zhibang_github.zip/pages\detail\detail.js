Page({
  data: {
    articleId: null,
    article: null
  },
  onLoad(options) {
    if (options.id) {
      this.setData({ articleId: options.id })
      this.loadArticle()
    }
  },
  loadArticle() {
    const articles = [
      {
        id: 1,
        title: '如何防范电信诈骗',
        date: '2024-01-15',
        content: '电信诈骗是指犯罪分子通过电话、网络和短信方式，编造虚假信息，设置骗局，对受害人实施远程、非接触式诈骗，诱使受害人给犯罪分子打款或转账的犯罪行为。\n\n防范措施：\n1. 不轻信陌生来电和短信\n2. 不向陌生人透露个人信息\n3. 不向陌生人转账汇款\n4. 遇到可疑情况及时报警\n5. 安装国家反诈中心APP'
      },
      {
        id: 2,
        title: '老年人数字生活指南',
        date: '2024-01-10',
        content: '随着科技的发展，智能手机已经成为我们生活中不可或缺的一部分。作为老年人，我们也可以享受数字化带来的便利。\n\n基本操作：\n1. 学会使用微信进行视频通话\n2. 使用健康码出行\n3. 网上预约挂号\n4. 使用导航出行\n5. 享受线上购物便利\n\n注意事项：\n1. 注意保护个人信息\n2. 不随意点击陌生链接\n3. 谨慎网络交友'
      }
    ]
    
    const article = articles.find(a => a.id === parseInt(this.data.articleId))
    this.setData({ article })
  }
})
