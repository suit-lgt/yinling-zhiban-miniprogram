Page({
  data: {
    currentIndex: 0,
    guideList: [
      {
        icon: '🏠',
        title: '欢迎使用银龄智伴',
        desc: '一款专为老年人设计的智能助手，让科技温暖您的生活'
      },
      {
        icon: '❤️',
        title: '健康守护',
        desc: '记录健康数据，设置用药提醒，守护您的身体健康'
      },
      {
        icon: '💡',
        title: '生活便利',
        desc: '一键打车、医院挂号、生活缴费，让生活更便捷'
      },
      {
        icon: '🤖',
        title: '智能问答',
        desc: '有任何问题都可以问AI助手，随时为您解答'
      }
    ]
  },
  goToSlide(e) {
    const index = e.currentTarget.dataset.index
    this.setData({ currentIndex: index })
  },
  startUse() {
    wx.setStorageSync('hasShownGuide', true)
    wx.switchTab({ url: '/pages/index/index' })
  },
  skipGuide() {
    this.startUse()
  }
})
