const dataTypeMap = ['bloodPressure', 'bloodSugar', 'heartRate']

Page({
  data: {
    dataTypeIndex: 0,
    dataTypes: [
      { value: 0, name: '血压', icon: '❤️' },
      { value: 1, name: '血糖', icon: '💉' },
      { value: 2, name: '心率', icon: '💗' }
    ],
    form: {
      systolic: '',
      diastolic: '',
      bloodSugar: '',
      heartRate: '',
      date: '',
      time: '',
      remark: ''
    },
    // 趋势图数据
    trendData: [],
    trendLabels: [],
    maxValue: 0,
    minValue: 0,
    avgValue: 0
  },
  onLoad() {
    const now = new Date()
    const dateStr = now.toISOString().split('T')[0]
    const timeStr = now.toTimeString().slice(0, 5)
    this.setData({
      'form.date': dateStr,
      'form.time': timeStr
    })
    this.loadTrendData()
  },
  onShow() {
    this.loadTrendData()
  },
  selectType(e) {
    const index = e.currentTarget.dataset.index
    this.setData({ dataTypeIndex: index })
    this.loadTrendData()
  },
  // 加载趋势数据
  loadTrendData() {
    const dataType = dataTypeMap[this.data.dataTypeIndex]
    const storageKey = `healthRecords_${dataType}`
    let records = wx.getStorageSync(storageKey) || []
    
    // 如果没有数据，使用演示数据
    if (records.length === 0) {
      records = this.getDemoData(dataType)
    }
    
    // 获取最近7条数据
    const recentRecords = records.slice(0, 7).reverse()
    
    // 生成趋势数据
    const trendData = recentRecords.map(r => {
      if (dataType === 'bloodPressure') {
        // 血压取收缩压
        return parseInt(r.value.split('/')[0]) || 0
      }
      return parseFloat(r.value) || 0
    })
    
    // 生成日期标签
    const trendLabels = recentRecords.map(r => {
      const date = new Date(r.createTime)
      const today = new Date()
      const diffDays = Math.floor((today - date) / (1000 * 60 * 60 * 24))
      
      if (diffDays === 0) return '今天'
      if (diffDays === 1) return '昨天'
      return `${diffDays}天前`
    })
    
    // 计算统计值
    const maxValue = trendData.length > 0 ? Math.max(...trendData) : 0
    const minValue = trendData.length > 0 ? Math.min(...trendData) : 0
    const avgValue = trendData.length > 0 
      ? (trendData.reduce((a, b) => a + b, 0) / trendData.length).toFixed(1)
      : 0
    
    this.setData({
      trendData,
      trendLabels,
      maxValue,
      minValue,
      avgValue
    }, () => {
      // 数据更新后绘制折线图
      this.drawTrendLine()
    })
  },

  // 绘制趋势线
  drawTrendLine() {
    const { trendData, maxValue } = this.data
    if (trendData.length === 0) return

    const ctx = wx.createCanvasContext('trendLineCanvas')
    const query = wx.createSelectorQuery()
    query.select('.line-canvas').boundingClientRect()
    query.exec((res) => {
      if (!res[0]) return
      
      const canvasWidth = res[0].width
      const canvasHeight = res[0].height
      const padding = 20
      const chartHeight = canvasHeight - padding * 2
      const chartWidth = canvasWidth - padding * 2
      const barWidth = chartWidth / trendData.length
      const centerOffset = barWidth / 2

      // 清空画布
      ctx.clearRect(0, 0, canvasWidth, canvasHeight)

      // 计算点的位置
      const points = trendData.map((value, index) => {
        const x = padding + index * barWidth + centerOffset
        const y = canvasHeight - padding - (value / maxValue * chartHeight * 0.85)
        return { x, y, value }
      })

      // 绘制渐变区域
      ctx.beginPath()
      ctx.moveTo(points[0].x, canvasHeight - padding)
      points.forEach((point, index) => {
        if (index === 0) {
          ctx.lineTo(point.x, point.y)
        } else {
          // 使用贝塞尔曲线使线条更平滑
          const prevPoint = points[index - 1]
          const cpX = (prevPoint.x + point.x) / 2
          ctx.quadraticCurveTo(prevPoint.x, prevPoint.y, cpX, (prevPoint.y + point.y) / 2)
          ctx.quadraticCurveTo(cpX, (prevPoint.y + point.y) / 2, point.x, point.y)
        }
      })
      ctx.lineTo(points[points.length - 1].x, canvasHeight - padding)
      ctx.closePath()
      
      // 渐变填充
      const gradient = ctx.createLinearGradient(0, padding, 0, canvasHeight - padding)
      gradient.addColorStop(0, 'rgba(250, 140, 22, 0.3)')
      gradient.addColorStop(1, 'rgba(250, 140, 22, 0.05)')
      ctx.fillStyle = gradient
      ctx.fill()

      // 绘制折线
      ctx.beginPath()
      ctx.strokeStyle = '#FA8C16'
      ctx.lineWidth = 4
      ctx.lineCap = 'round'
      ctx.lineJoin = 'round'
      
      points.forEach((point, index) => {
        if (index === 0) {
          ctx.moveTo(point.x, point.y)
        } else {
          const prevPoint = points[index - 1]
          const cpX = (prevPoint.x + point.x) / 2
          ctx.quadraticCurveTo(prevPoint.x, prevPoint.y, cpX, (prevPoint.y + point.y) / 2)
          ctx.quadraticCurveTo(cpX, (prevPoint.y + point.y) / 2, point.x, point.y)
        }
      })
      ctx.stroke()

      // 绘制数据点
      points.forEach((point, index) => {
        // 外圈
        ctx.beginPath()
        ctx.arc(point.x, point.y, 8, 0, Math.PI * 2)
        ctx.fillStyle = '#FFFFFF'
        ctx.fill()
        ctx.strokeStyle = '#FA8C16'
        ctx.lineWidth = 3
        ctx.stroke()

        // 内圈
        ctx.beginPath()
        ctx.arc(point.x, point.y, 4, 0, Math.PI * 2)
        ctx.fillStyle = '#FA8C16'
        ctx.fill()
      })

      ctx.draw()
    })
  },
  // 获取演示数据
  getDemoData(type) {
    const now = Date.now()
    const oneDay = 24 * 60 * 60 * 1000
    
    if (type === 'bloodPressure') {
      return [
        { id: 1, value: '128/82', createTime: now - oneDay * 0.5 },
        { id: 2, value: '132/85', createTime: now - oneDay * 1 },
        { id: 3, value: '125/78', createTime: now - oneDay * 2 },
        { id: 4, value: '135/88', createTime: now - oneDay * 3 },
        { id: 5, value: '130/80', createTime: now - oneDay * 4 },
        { id: 6, value: '118/75', createTime: now - oneDay * 5 },
        { id: 7, value: '122/76', createTime: now - oneDay * 6 }
      ]
    }
    
    if (type === 'bloodSugar') {
      return [
        { id: 1, value: '5.8', createTime: now - oneDay * 0.5 },
        { id: 2, value: '6.2', createTime: now - oneDay * 1 },
        { id: 3, value: '5.6', createTime: now - oneDay * 2 },
        { id: 4, value: '6.5', createTime: now - oneDay * 3 },
        { id: 5, value: '5.9', createTime: now - oneDay * 4 },
        { id: 6, value: '5.4', createTime: now - oneDay * 5 },
        { id: 7, value: '5.7', createTime: now - oneDay * 6 }
      ]
    }
    
    if (type === 'heartRate') {
      return [
        { id: 1, value: '72', createTime: now - oneDay * 0.5 },
        { id: 2, value: '75', createTime: now - oneDay * 1 },
        { id: 3, value: '68', createTime: now - oneDay * 2 },
        { id: 4, value: '78', createTime: now - oneDay * 3 },
        { id: 5, value: '71', createTime: now - oneDay * 4 },
        { id: 6, value: '65', createTime: now - oneDay * 5 },
        { id: 7, value: '70', createTime: now - oneDay * 6 }
      ]
    }
    
    return []
  },
  onSystolicInput(e) {
    this.setData({ 'form.systolic': e.detail.value })
  },
  onDiastolicInput(e) {
    this.setData({ 'form.diastolic': e.detail.value })
  },
  onBloodSugarInput(e) {
    this.setData({ 'form.bloodSugar': e.detail.value })
  },
  onHeartRateInput(e) {
    this.setData({ 'form.heartRate': e.detail.value })
  },
  onRemarkInput(e) {
    this.setData({ 'form.remark': e.detail.value })
  },
  changeDate(e) {
    this.setData({ 'form.date': e.detail.value })
  },
  changeTime(e) {
    this.setData({ 'form.time': e.detail.value })
  },
  saveData() {
    const form = this.data.form
    
    if (!form.date || !form.time) {
      wx.showToast({ title: '请选择测量时间', icon: 'none' })
      return
    }
    
    let value = ''
    const dataType = dataTypeMap[this.data.dataTypeIndex]
    
    if (dataType === 'bloodPressure') {
      if (!form.systolic || !form.diastolic) {
        wx.showToast({ title: '请填写血压值', icon: 'none' })
        return
      }
      value = `${form.systolic}/${form.diastolic}`
    } else if (dataType === 'bloodSugar') {
      if (!form.bloodSugar) {
        wx.showToast({ title: '请填写血糖值', icon: 'none' })
        return
      }
      value = form.bloodSugar
    } else {
      if (!form.heartRate) {
        wx.showToast({ title: '请填写心率值', icon: 'none' })
        return
      }
      value = form.heartRate
    }
    
    wx.showLoading({ title: '保存中...' })
    
    const storageKey = `healthRecords_${dataType}`
    let records = wx.getStorageSync(storageKey) || []
    
    const newRecord = {
      id: Date.now(),
      type: dataType,
      value,
      date: form.date,
      time: form.time,
      remark: form.remark,
      createTime: Date.now()
    }
    
    records.unshift(newRecord)
    wx.setStorageSync(storageKey, records)
    
    wx.hideLoading()
    wx.showToast({ title: '保存成功', icon: 'success' })
    
    setTimeout(() => {
      wx.navigateBack()
    }, 1500)
  }
})
