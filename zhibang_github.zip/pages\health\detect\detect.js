// 智能检测页面
Page({
  data: {
    fallDetection: {
      enabled: false,
      detecting: false,
      alert: false,
      countdown: 30,
      sensitivity: 'normal',
      triggerCount: 0,
      lastTrigger: ''
    },
    sensorData: {
      x: '-0.09',
      y: '-0.63',
      z: '-0.94',
      total: '1.13'
    }
  },

  onLoad() {
    this.loadSettings()
  },

  onUnload() {
    this.stopSensorSimulation()
    if (this.countdownInterval) {
      clearInterval(this.countdownInterval)
    }
  },

  onShow() {
    this.loadSettings()
  },

  // 加载设置
  loadSettings() {
    const settings = wx.getStorageSync('fallDetectionSettings')
    if (settings) {
      this.setData({
        fallDetection: { ...this.data.fallDetection, ...settings }
      })
      if (settings.enabled) {
        this.startSensorSimulation()
      }
    }
  },

  // 保存设置
  saveSettings() {
    wx.setStorageSync('fallDetectionSettings', this.data.fallDetection)
  },

  // 切换跌倒检测开关
  toggleFallDetection(e) {
    const enabled = e.detail.value
    const fallDetection = { ...this.data.fallDetection, enabled, detecting: enabled }
    this.setData({ fallDetection })
    this.saveSettings()

    if (enabled) {
      wx.showToast({ title: '跌倒检测已开启', icon: 'success' })
      this.startSensorSimulation()
    } else {
      wx.showToast({ title: '跌倒检测已关闭', icon: 'none' })
      this.stopSensorSimulation()
    }
  },

  // 设置灵敏度
  setSensitivity(e) {
    const level = e.currentTarget.dataset.level
    const fallDetection = { ...this.data.fallDetection, sensitivity: level }
    this.setData({ fallDetection })
    this.saveSettings()
    wx.showToast({ title: '灵敏度已设置', icon: 'none' })
  },

  // 开始传感器数据模拟
  startSensorSimulation() {
    if (this.sensorInterval) return
    this.sensorInterval = setInterval(() => {
      const x = (Math.random() * 0.2 - 0.1).toFixed(2)
      const y = (Math.random() * 0.2 - 0.7).toFixed(2)
      const z = (Math.random() * 0.2 - 0.9).toFixed(2)
      const total = Math.sqrt(x*x + y*y + z*z).toFixed(2)
      this.setData({
        sensorData: { x, y, z, total }
      })
    }, 500)
  },

  // 停止传感器模拟
  stopSensorSimulation() {
    if (this.sensorInterval) {
      clearInterval(this.sensorInterval)
      this.sensorInterval = null
    }
  },

  // 模拟跌倒检测触发
  triggerFallAlert() {
    const fallDetection = { ...this.data.fallDetection, alert: true, countdown: 30 }
    this.setData({ fallDetection })

    this.countdownInterval = setInterval(() => {
      const countdown = this.data.fallDetection.countdown - 1
      if (countdown <= 0) {
        clearInterval(this.countdownInterval)
        this.autoSOS()
      } else {
        this.setData({
          fallDetection: { ...this.data.fallDetection, countdown }
        })
      }
    }, 1000)
  },

  // 取消警报
  cancelAlert() {
    clearInterval(this.countdownInterval)
    const fallDetection = { ...this.data.fallDetection, alert: false }
    this.setData({ fallDetection })
    wx.showToast({ title: '警报已取消', icon: 'success' })
  },

  // 确认求助
  confirmAlert() {
    clearInterval(this.countdownInterval)
    const fallDetection = { ...this.data.fallDetection, alert: false }
    this.setData({ fallDetection })
    this.handleSOS()
  },

  // 自动SOS
  autoSOS() {
    const fallDetection = {
      ...this.data.fallDetection,
      alert: false,
      triggerCount: this.data.fallDetection.triggerCount + 1,
      lastTrigger: new Date().toLocaleString('zh-CN', { hour: '2-digit', minute: '2-digit', second: '2-digit' })
    }
    this.setData({ fallDetection })
    this.saveSettings()
    this.handleSOS()
  },

  // 手动SOS
  manualSOS() {
    this.handleSOS()
  },

  // 处理SOS
  handleSOS() {
    wx.showModal({
      title: '🆘 紧急求助',
      content: '即将向所有家人发送求助信息',
      confirmText: '确认求助',
      confirmColor: '#F5222D',
      success: (res) => {
        if (res.confirm) {
          wx.showToast({ title: '已通知所有家人', icon: 'success' })
        }
      }
    })
  }
})
