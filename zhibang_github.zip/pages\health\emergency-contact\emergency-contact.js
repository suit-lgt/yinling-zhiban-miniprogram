Page({
  data: {
    contacts: [
      { name: '儿子', phone: '13800138000' },
      { name: '女儿', phone: '13900139000' }
    ]
  },
  onLoad() {
    this.loadContacts()
  },
  loadContacts() {
    const contacts = wx.getStorageSync('emergencyContacts')
    if (contacts && contacts.length > 0) {
      this.setData({ contacts })
    }
  },
  callContact(e) {
    const index = e.currentTarget.dataset.index
    const contact = this.data.contacts[index]
    wx.showModal({
      title: '确认呼叫',
      content: `确定要呼叫 ${contact.name} (${contact.phone}) 吗？`,
      success: (res) => {
        if (res.confirm) {
          wx.makePhoneCall({
            phoneNumber: contact.phone
          })
        }
      }
    })
  },
  callEmergency() {
    if (this.data.contacts.length > 0) {
      const firstContact = this.data.contacts[0]
      wx.showModal({
        title: '紧急呼叫',
        content: `确定要紧急呼叫 ${firstContact.name} (${firstContact.phone}) 吗？`,
        success: (res) => {
          if (res.confirm) {
            wx.makePhoneCall({
              phoneNumber: firstContact.phone
            })
          }
        }
      })
    } else {
      wx.showModal({
        title: '紧急呼叫',
        content: '确定要拨打急救电话 120 吗？',
        success: (res) => {
          if (res.confirm) {
            wx.makePhoneCall({
              phoneNumber: '120'
            })
          }
        }
      })
    }
  },
  addContact() {
    wx.navigateTo({
      url: '/pages/mine/profile/profile'
    })
  }
})
