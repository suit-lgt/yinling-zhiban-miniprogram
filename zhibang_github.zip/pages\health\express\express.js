Page({
  data: {
    trackingNumber: '',
    companyIndex: 0,
    companies: ['顺丰速运', '中通快递', '圆通速递', '韵达快递', '申通快递'],
    trackingInfo: null
  },
  onTrackingInput(e) {
    this.setData({ trackingNumber: e.detail.value })
  },
  changeCompany(e) {
    this.setData({ companyIndex: e.detail.value })
  },
  queryExpress() {
    if (!this.data.trackingNumber) {
      wx.showToast({ title: '请输入快递单号', icon: 'none' })
      return
    }
    
    wx.showLoading({ title: '查询中...' })
    
    setTimeout(() => {
      wx.hideLoading()
      this.setData({
        trackingInfo: {
          company: this.data.companies[this.data.companyIndex],
          number: this.data.trackingNumber,
          status: '运输中',
          tracks: [
            { desc: '已到达北京转运中心', time: '2024-01-15 14:30' },
            { desc: '已从广州发出', time: '2024-01-14 10:00' },
            { desc: '已收件', time: '2024-01-13 18:00' }
          ]
        }
      })
    }, 1000)
  }
})
