Page({
  data: {
    status: 'normal',
    statusIcon: '✓',
    statusText: '监测中...',
    sensitivity: 'medium',
    sensitivityLevels: [
      { value: 'low', label: '低' },
      { value: 'medium', label: '中' },
      { value: 'high', label: '高' }
    ],
    autoCall: true,
    sendLocation: true
  },
  onLoad() {
    // 加载设置
    const settings = wx.getStorageSync('fallDetectionSettings')
    if (settings) {
      this.setData({
        sensitivity: settings.sensitivity || 'medium',
        autoCall: settings.autoCall !== false,
        sendLocation: settings.sendLocation !== false
      })
    }
  },
  setSensitivity(e) {
    const value = e.currentTarget.dataset.value
    this.setData({ sensitivity: value })
    this.saveSettings()
    wx.showToast({ title: '灵敏度已设置', icon: 'success' })
  },
  toggleAutoCall(e) {
    this.setData({ autoCall: e.detail.value })
    this.saveSettings()
  },
  toggleSendLocation(e) {
    this.setData({ sendLocation: e.detail.value })
    this.saveSettings()
  },
  saveSettings() {
    const { sensitivity, autoCall, sendLocation } = this.data
    wx.setStorageSync('fallDetectionSettings', { sensitivity, autoCall, sendLocation })
  },
  testDetection() {
    wx.showLoading({ title: '测试中...' })
    setTimeout(() => {
      wx.hideLoading()
      wx.showToast({
        title: '检测功能正常',
        icon: 'success'
      })
    }, 2000)
  }
})
