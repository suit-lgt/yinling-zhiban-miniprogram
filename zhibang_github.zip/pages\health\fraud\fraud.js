Page({
  data: {
    activeType: 'all',
    fraudTypes: [
      { id: 'all', name: '全部' },
      { id: 'phone', name: '电话诈骗' },
      { id: 'online', name: '网络诈骗' },
      { id: 'fake', name: '冒充诈骗' }
    ],
    fraudList: [
      { id: 1, type: 'phone', title: '冒充公检法诈骗', desc: '骗子冒充公安机关、检察院、法院工作人员，以涉嫌犯罪为由要求转账。' },
      { id: 2, type: 'phone', title: '医保社保诈骗', desc: '骗子冒充医保局、社保局工作人员，以账户异常为由骗取个人信息。' },
      { id: 3, type: 'online', title: '杀猪盘诈骗', desc: '骗子通过婚恋网站、社交平台寻找受害者，建立感情后诱导投资。' },
      { id: 4, type: 'online', title: '刷单返利诈骗', desc: '骗子以高额返利为诱饵，诱导受害者垫付资金刷单。' },
      { id: 5, type: 'fake', title: '冒充熟人诈骗', desc: '骗子冒充朋友、家人，以急事为由借钱。' },
      { id: 6, type: 'fake', title: '冒充客服诈骗', desc: '骗子冒充电商客服、银行客服，以退款为由骗取验证码。' }
    ],
    filteredList: []
  },
  onLoad() {
    this.filterList()
  },
  filterList() {
    const { activeType, fraudList } = this.data
    let list = fraudList
    if (activeType !== 'all') {
      list = fraudList.filter(item => item.type === activeType)
    }
    this.setData({ filteredList: list })
  },
  switchType(e) {
    const id = e.currentTarget.dataset.id
    this.setData({ activeType: id }, () => {
      this.filterList()
    })
  },
  showDetail(e) {
    const id = e.currentTarget.dataset.id
    const item = this.data.fraudList.find(f => f.id === id)
    wx.showModal({
      title: item.title,
      content: item.desc + '\n\n如遇此情况，请立即拨打110报警！',
      showCancel: false
    })
  }
})
