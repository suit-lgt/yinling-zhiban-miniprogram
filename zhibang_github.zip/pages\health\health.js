// pages/health/health.js
Page({
  data: {
    locationEnabled: false,
    healthData: {
      bloodPressure: '128/82',
      bloodSugar: '5.8',
      heartRate: '72'
    },
    bloodPressureStatus: 'normal',
    bloodPressureText: '正常',
    bloodSugarStatus: 'normal',
    bloodSugarText: '正常',
    heartRateStatus: 'normal',
    heartRateText: '正常',
    medicineProgress: '今日已完成 2/3 次用药',
    quickFunctions: [
      { id: 1, name: '医院挂号', icon: '🏥', color: '#1890FF', path: '/pages/health/hospital/hospital' },
      { id: 2, name: '健康档案', icon: '📊', color: '#52C41A', path: '/pages/health/record/record' },
      { id: 3, name: '用药提醒', icon: '💊', color: '#FAAD14', path: '/pages/health/medicine/medicine' },
      { id: 4, name: '叫车服务', icon: '🚕', color: '#722ED1', path: '/pages/health/taxi/taxi' },
      { id: 5, name: '快递查询', icon: '📦', color: '#13C2C2', path: '/pages/health/express/express' },
      { id: 6, name: '生活缴费', icon: '💡', color: '#EB2F96', path: '/pages/health/payment/payment' },
      { id: 7, name: '反诈宣传', icon: '🛡️', color: '#F5222D', path: '/pages/health/fraud/fraud' },
      { id: 8, name: '跌倒检测', icon: '⚠️', color: '#FA8C16', path: '/pages/health/fall/fall' }
    ]
  },

  onLoad(options) {
    this.loadHealthData()
  },

  onShow() {
    this.loadHealthData()
  },

  // 加载健康数据
  loadHealthData() {
    // 从存储中获取最新数据
    const bpRecords = wx.getStorageSync('healthRecords_bloodPressure') || []
    const bsRecords = wx.getStorageSync('healthRecords_bloodSugar') || []
    const hrRecords = wx.getStorageSync('healthRecords_heartRate') || []

    const healthData = { ...this.data.healthData }

    if (bpRecords.length > 0) {
      healthData.bloodPressure = bpRecords[0].value
    }
    if (bsRecords.length > 0) {
      healthData.bloodSugar = bsRecords[0].value
    }
    if (hrRecords.length > 0) {
      healthData.heartRate = hrRecords[0].value
    }

    this.setData({
      healthData,
      ...this.getStatusInfo(healthData)
    })
  },

  // 获取状态信息
  getStatusInfo(healthData) {
    const result = {}

    // 血压状态
    if (healthData.bloodPressure) {
      const [systolic] = healthData.bloodPressure.split('/').map(Number)
      if (systolic < 120) {
        result.bloodPressureStatus = 'normal'
        result.bloodPressureText = '正常'
      } else if (systolic < 140) {
        result.bloodPressureStatus = 'warning'
        result.bloodPressureText = '偏高'
      } else {
        result.bloodPressureStatus = 'danger'
        result.bloodPressureText = '很高'
      }
    }

    // 血糖状态
    if (healthData.bloodSugar) {
      const val = Number(healthData.bloodSugar)
      if (val < 6.1) {
        result.bloodSugarStatus = 'normal'
        result.bloodSugarText = '正常'
      } else if (val < 7.0) {
        result.bloodSugarStatus = 'warning'
        result.bloodSugarText = '偏高'
      } else {
        result.bloodSugarStatus = 'danger'
        result.bloodSugarText = '很高'
      }
    }

    // 心率状态
    if (healthData.heartRate) {
      const val = Number(healthData.heartRate)
      if (val >= 60 && val <= 100) {
        result.heartRateStatus = 'normal'
        result.heartRateText = '正常'
      } else {
        result.heartRateStatus = 'warning'
        result.heartRateText = '异常'
      }
    }

    return result
  },

  // 跳转到健康记录页面
  goToRecord(e) {
    const type = e.currentTarget.dataset.type
    wx.navigateTo({
      url: `/pages/health/record/record?type=${type}`
    })
  },

  // 处理快捷功能点击
  handleQuickClick(e) {
    const item = e.currentTarget.dataset.item
    wx.navigateTo({
      url: item.path
    })
  },

  // 跳转到用药提醒
  goToMedicine() {
    wx.navigateTo({
      url: '/pages/health/medicine/medicine'
    })
  },

  // 跳转到紧急联系人
  goToEmergencyContact() {
    wx.navigateTo({
      url: '/pages/health/emergency-contact/emergency-contact'
    })
  },

  // 处理SOS
  handleSOS() {
    wx.showModal({
      title: '🆘 紧急求助',
      content: '即将拨打紧急联系人电话并发送位置信息',
      confirmText: '确认',
      confirmColor: '#F5222D',
      cancelText: '取消',
      success: (res) => {
        if (res.confirm) {
          wx.showToast({
            title: '已发送求助信息',
            icon: 'success'
          })
        }
      }
    })
  },

  // 切换位置共享
  toggleLocation() {
    const locationEnabled = !this.data.locationEnabled
    this.setData({ locationEnabled })
    wx.showToast({
      title: locationEnabled ? '位置共享已开启' : '位置共享已关闭',
      icon: 'none'
    })
  }
})