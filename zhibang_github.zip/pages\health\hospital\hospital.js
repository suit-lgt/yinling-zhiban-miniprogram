Page({
  data: {
    keyword: '',
    selectedHospital: null,
    selectedDepartment: null,
    showDoctors: false,
    showBooking: false,
    selectedDate: '',
    selectedTime: '',
    patientName: '',
    patientPhone: '',
    
    // 当前位置（演示数据）- 北京市朝阳区某小区
    currentLocation: {
      name: '北京市朝阳区阳光花园小区',
      latitude: 39.9234,
      longitude: 116.4556
    },
    
    // 是否显示地图
    showMap: false,
    
    // 地图标记点
    mapMarkers: [],
    
    // 医院列表（演示数据）- 基于真实北京医院位置
    hospitals: [
      { 
        id: 1, 
        name: '北京市第一医院', 
        address: '北京市东城区东单北大街1号',
        level: '三级甲等',
        distance: '2.5km',
        icon: '🏥',
        latitude: 39.9074,
        longitude: 116.4184,
        phone: '010-65231111',
        departments: [
          { id: 101, name: '内科', doctors: 15 },
          { id: 102, name: '外科', doctors: 12 },
          { id: 103, name: '妇产科', doctors: 8 },
          { id: 104, name: '儿科', doctors: 10 },
          { id: 105, name: '骨科', doctors: 6 },
          { id: 106, name: '心内科', doctors: 9 }
        ]
      },
      { 
        id: 2, 
        name: '朝阳区中心医院', 
        address: '北京市朝阳区工体南路8号',
        level: '三级乙等',
        distance: '1.8km',
        icon: '🏥',
        latitude: 39.9312,
        longitude: 116.4523,
        phone: '010-65851111',
        departments: [
          { id: 201, name: '内科', doctors: 10 },
          { id: 202, name: '外科', doctors: 8 },
          { id: 203, name: '中医科', doctors: 5 },
          { id: 204, name: '康复科', doctors: 4 }
        ]
      },
      { 
        id: 3, 
        name: '社区卫生服务中心', 
        address: '北京市朝阳区阳光花园小区南门',
        level: '社区医院',
        distance: '0.5km',
        icon: '🏨',
        latitude: 39.9234,
        longitude: 116.4556,
        phone: '010-65831111',
        departments: [
          { id: 301, name: '全科', doctors: 3 },
          { id: 302, name: '中医', doctors: 2 },
          { id: 303, name: '预防保健', doctors: 2 }
        ]
      },
      { 
        id: 4, 
        name: '北京协和医院', 
        address: '北京市东城区帅府园1号',
        level: '三级甲等',
        distance: '3.2km',
        icon: '🏥',
        latitude: 39.9108,
        longitude: 116.4109,
        phone: '010-69151111',
        departments: [
          { id: 401, name: '内科', doctors: 25 },
          { id: 402, name: '外科', doctors: 20 },
          { id: 403, name: '妇产科', doctors: 15 },
          { id: 404, name: '肿瘤科', doctors: 12 },
          { id: 405, name: '神经内科', doctors: 10 }
        ]
      },
      { 
        id: 5, 
        name: '中日友好医院', 
        address: '北京市朝阳区樱花园东街2号',
        level: '三级甲等',
        distance: '4.1km',
        icon: '🏥',
        latitude: 39.9502,
        longitude: 116.4234,
        phone: '010-84221111',
        departments: [
          { id: 501, name: '呼吸科', doctors: 18 },
          { id: 502, name: '骨科', doctors: 14 },
          { id: 503, name: '中医科', doctors: 10 },
          { id: 504, name: '康复科', doctors: 8 }
        ]
      },
      { 
        id: 6, 
        name: '朝阳医院', 
        address: '北京市朝阳区白家庄路8号',
        level: '三级甲等',
        distance: '2.8km',
        icon: '🏥',
        latitude: 39.9167,
        longitude: 116.4456,
        phone: '010-85231111',
        departments: [
          { id: 601, name: '呼吸科', doctors: 12 },
          { id: 602, name: '心内科', doctors: 10 },
          { id: 603, name: '消化科', doctors: 8 },
          { id: 604, name: '内分泌科', doctors: 6 }
        ]
      },
      { 
        id: 7, 
        name: '北京同仁医院', 
        address: '北京市东城区东交民巷1号',
        level: '三级甲等',
        distance: '3.5km',
        icon: '🏥',
        latitude: 39.9012,
        longitude: 116.4123,
        phone: '010-58261111',
        departments: [
          { id: 701, name: '眼科', doctors: 20 },
          { id: 702, name: '耳鼻喉科', doctors: 15 },
          { id: 703, name: '内科', doctors: 12 }
        ]
      },
      { 
        id: 8, 
        name: '北京医院', 
        address: '北京市东城区大佛寺东街6号',
        level: '三级甲等',
        distance: '3.8km',
        icon: '🏥',
        latitude: 39.9189,
        longitude: 116.4089,
        phone: '010-85131111',
        departments: [
          { id: 801, name: '老年医学科', doctors: 18 },
          { id: 802, name: '心内科', doctors: 14 },
          { id: 803, name: '内分泌科', doctors: 10 }
        ]
      }
    ],
    
    // 当前显示的医院列表
    filteredHospitals: [],
    
    // 医生列表（演示数据）
    doctors: [
      { id: 1001, name: '张医生', title: '主任医师', specialty: '高血压、冠心病', available: true, morning: 5, afternoon: 3 },
      { id: 1002, name: '李医生', title: '副主任医师', specialty: '糖尿病、甲状腺疾病', available: true, morning: 3, afternoon: 4 },
      { id: 1003, name: '王医生', title: '主治医师', specialty: '呼吸道感染、哮喘', available: false, morning: 0, afternoon: 0 },
      { id: 1004, name: '刘医生', title: '主任医师', specialty: '胃病、肝病', available: true, morning: 2, afternoon: 5 },
      { id: 1005, name: '陈医生', title: '副主任医师', specialty: '肾病、风湿病', available: true, morning: 4, afternoon: 2 }
    ],
    
    // 预约日期（未来7天）
    availableDates: [],
    
    // 预约时间段
    timeSlots: [
      { time: '08:00-08:30', available: true },
      { time: '08:30-09:00', available: true },
      { time: '09:00-09:30', available: false },
      { time: '09:30-10:00', available: true },
      { time: '10:00-10:30', available: true },
      { time: '10:30-11:00', available: false },
      { time: '14:00-14:30', available: true },
      { time: '14:30-15:00', available: true },
      { time: '15:00-15:30', available: true },
      { time: '15:30-16:00', available: false }
    ],
    
    // 我的预约记录
    myAppointments: [],
    
    // 是否显示预约成功详情
    showBookingSuccess: false,
    
    // 当前预约详情
    currentAppointment: null
  },

  onLoad() {
    this.setData({
      filteredHospitals: this.data.hospitals
    })
    this.generateDates()
    this.loadMyAppointments()
    this.initMapMarkers()
  },

  // 初始化地图标记点
  initMapMarkers() {
    const markers = this.data.hospitals.map((hospital, index) => ({
      id: hospital.id,
      latitude: hospital.latitude,
      longitude: hospital.longitude,
      iconPath: '',
      width: 40,
      height: 40,
      title: hospital.name,
      label: {
        content: hospital.name,
        color: '#1890FF',
        fontSize: 12,
        borderRadius: 6,
        bgColor: '#ffffff',
        padding: 6,
        borderWidth: 1,
        borderColor: '#1890FF',
        anchorX: 0,
        anchorY: -40
      },
      callout: {
        content: `${hospital.name}\n${hospital.level}\n距您 ${hospital.distance}`,
        color: '#333',
        fontSize: 13,
        borderRadius: 10,
        bgColor: '#fff',
        padding: 12,
        display: 'BYCLICK',
        textAlign: 'center'
      }
    }))
    
    // 添加当前位置标记
    markers.push({
      id: 999,
      latitude: this.data.currentLocation.latitude,
      longitude: this.data.currentLocation.longitude,
      iconPath: '',
      width: 40,
      height: 40,
      title: '我的位置',
      label: {
        content: '我的位置',
        color: '#52C41A',
        fontSize: 12,
        borderRadius: 6,
        bgColor: '#ffffff',
        padding: 6,
        borderWidth: 1,
        borderColor: '#52C41A',
        anchorX: 0,
        anchorY: -40
      }
    })
    
    this.setData({ mapMarkers: markers })
  },

  // 切换地图/列表视图
  toggleMapView() {
    const showMap = !this.data.showMap
    this.setData({ showMap })
    
    if (showMap) {
      wx.showToast({
        title: '地图模式',
        icon: 'none',
        duration: 1500
      })
    }
  },

  // 地图标记点点击
  onMarkerTap(e) {
    const hospitalId = e.markerId
    const hospital = this.data.hospitals.find(h => h.id === hospitalId)
    
    wx.showActionSheet({
      itemList: ['查看详情', '导航前往', '拨打电话'],
      success: (res) => {
        if (res.tapIndex === 0) {
          this.setData({ selectedHospital: hospital })
        } else if (res.tapIndex === 1) {
          this.navigateToHospitalById(hospitalId)
        } else if (res.tapIndex === 2) {
          this.callHospitalById(hospitalId)
        }
      }
    })
  },

  // 导航到指定医院
  navigateToHospitalById(hospitalId) {
    const hospital = this.data.hospitals.find(h => h.id === hospitalId)
    wx.openLocation({
      latitude: hospital.latitude,
      longitude: hospital.longitude,
      name: hospital.name,
      address: hospital.address,
      scale: 18
    })
  },

  // 拨打指定医院电话
  callHospitalById(hospitalId) {
    const hospital = this.data.hospitals.find(h => h.id === hospitalId)
    wx.makePhoneCall({
      phoneNumber: hospital.phone,
      fail: () => {
        wx.showModal({
          title: '演示模式',
          content: `医院电话：${hospital.phone}\n（演示环境不支持拨打电话）`,
          showCancel: false
        })
      }
    })
  },

  // 定位到当前位置
  locateCurrentPosition() {
    wx.showLoading({ title: '定位中...' })
    
    setTimeout(() => {
      wx.hideLoading()
      wx.showToast({
        title: '已定位到当前位置',
        icon: 'success'
      })
    }, 1000)
  },

  // 生成未来7天日期
  generateDates() {
    const dates = []
    const today = new Date()
    const weekDays = ['周日', '周一', '周二', '周三', '周四', '周五', '周六']
    
    for (let i = 0; i < 7; i++) {
      const date = new Date(today)
      date.setDate(today.getDate() + i)
      const month = date.getMonth() + 1
      const day = date.getDate()
      const weekDay = i === 0 ? '今天' : weekDays[date.getDay()]
      
      dates.push({
        date: `${month}月${day}日`,
        weekDay: weekDay,
        fullDate: date.toISOString().split('T')[0],
        isToday: i === 0
      })
    }
    
    this.setData({
      availableDates: dates,
      selectedDate: dates[0].fullDate
    })
  },

  // 加载我的预约
  loadMyAppointments() {
    const appointments = wx.getStorageSync('myAppointments') || []
    this.setData({ myAppointments: appointments })
  },

  // 搜索输入
  onKeywordInput(e) {
    const keyword = e.detail.value
    this.setData({ keyword })
    
    if (keyword) {
      const filtered = this.data.hospitals.filter(h => 
        h.name.includes(keyword) || h.address.includes(keyword)
      )
      this.setData({ filteredHospitals: filtered })
    } else {
      this.setData({ filteredHospitals: this.data.hospitals })
    }
  },

  // 搜索医院
  searchHospital() {
    if (!this.data.keyword) {
      wx.showToast({ title: '请输入搜索关键词', icon: 'none' })
      return
    }
    
    const filtered = this.data.hospitals.filter(h => 
      h.name.includes(this.data.keyword) || h.address.includes(this.data.keyword)
    )
    
    this.setData({ filteredHospitals: filtered })
    
    if (filtered.length === 0) {
      wx.showToast({ title: '未找到相关医院', icon: 'none' })
    }
  },

  // 选择医院
  selectHospital(e) {
    const id = parseInt(e.currentTarget.dataset.id)
    const hospital = this.data.hospitals.find(h => h.id === id)
    
    this.setData({
      selectedHospital: hospital,
      showDoctors: false,
      selectedDepartment: null
    })
  },

  // 选择科室
  selectDepartment(e) {
    const deptId = parseInt(e.currentTarget.dataset.id)
    const dept = this.data.selectedHospital.departments.find(d => d.id === deptId)
    
    this.setData({
      selectedDepartment: dept,
      showDoctors: true
    })
    
    // 模拟加载医生数据
    wx.showLoading({ title: '加载中...' })
    setTimeout(() => {
      wx.hideLoading()
    }, 500)
  },

  // 返回医院列表
  backToHospitals() {
    this.setData({
      selectedHospital: null,
      selectedDepartment: null,
      showDoctors: false
    })
  },

  // 返回科室列表
  backToDepartments() {
    this.setData({
      showDoctors: false,
      selectedDepartment: null
    })
  },

  // 选择医生
  selectDoctor(e) {
    const doctorId = parseInt(e.currentTarget.dataset.id)
    const doctor = this.data.doctors.find(d => d.id === doctorId)
    
    if (!doctor.available) {
      wx.showToast({ title: '该医生今日已约满', icon: 'none' })
      return
    }
    
    this.setData({
      showBooking: true
    })
  },

  // 选择日期
  selectDate(e) {
    const date = e.currentTarget.dataset.date
    this.setData({ selectedDate: date })
  },

  // 选择时间
  selectTime(e) {
    const time = e.currentTarget.dataset.time
    const available = e.currentTarget.dataset.available
    
    if (!available) {
      wx.showToast({ title: '该时段已满', icon: 'none' })
      return
    }
    
    this.setData({ selectedTime: time })
  },

  // 输入患者姓名
  onNameInput(e) {
    this.setData({ patientName: e.detail.value })
  },

  // 输入患者电话
  onPhoneInput(e) {
    this.setData({ patientPhone: e.detail.value })
  },

  // 关闭预约弹窗
  closeBooking() {
    this.setData({ showBooking: false })
  },

    // 确认预约
  confirmBooking() {
    if (!this.data.selectedDate || !this.data.selectedTime) {
      wx.showToast({ title: '请选择就诊时间', icon: 'none' })
      return
    }
    
    if (!this.data.patientName) {
      wx.showToast({ title: '请输入患者姓名', icon: 'none' })
      return
    }
    
    if (!this.data.patientPhone) {
      wx.showToast({ title: '请输入联系电话', icon: 'none' })
      return
    }
    
    // 创建预约记录
    const appointment = {
      id: Date.now(),
      hospital: this.data.selectedHospital,
      department: this.data.selectedDepartment,
      date: this.data.selectedDate,
      time: this.data.selectedTime,
      patientName: this.data.patientName,
      patientPhone: this.data.patientPhone,
      status: '待就诊',
      queueNumber: this.generateQueueNumber(),
      createTime: new Date().toLocaleString()
    }
    
    // 保存预约
    const appointments = this.data.myAppointments
    appointments.unshift(appointment)
    wx.setStorageSync('myAppointments', appointments)
    
    this.setData({
      myAppointments: appointments,
      showBooking: false,
      showBookingSuccess: true,
      currentAppointment: appointment,
      patientName: '',
      patientPhone: '',
      selectedTime: ''
    })
  },

  // 生成排队号码
  generateQueueNumber() {
    const prefix = 'A'
    const num = Math.floor(Math.random() * 900) + 100
    return prefix + num
  },

  // 关闭预约成功详情
  closeBookingSuccess() {
    this.setData({
      showBookingSuccess: false,
      currentAppointment: null
    })
  },

  // 查看我的预约（从成功页面）
  viewAppointmentFromSuccess() {
    this.setData({
      showBookingSuccess: false,
      showDoctors: false,
      selectedDepartment: null
    })
    this.viewMyAppointments()
  },

  // 导航到当前预约医院
  navigateToAppointmentHospital() {
    const appointment = this.data.currentAppointment
    if (appointment && appointment.hospital) {
      wx.openLocation({
        latitude: appointment.hospital.latitude,
        longitude: appointment.hospital.longitude,
        name: appointment.hospital.name,
        address: appointment.hospital.address,
        scale: 18
      })
    }
  },

  // 分享预约信息
  shareAppointment() {
    const appointment = this.data.currentAppointment
    if (appointment) {
      wx.showModal({
        title: '分享预约信息',
        content: `${appointment.hospital.name}\n${appointment.department.name}\n${appointment.date} ${appointment.time}\n患者：${appointment.patientName}\n排队号：${appointment.queueNumber}`,
        confirmText: '复制信息',
        success: (res) => {
          if (res.confirm) {
            wx.setClipboardData({
              data: `医院挂号预约\n医院：${appointment.hospital.name}\n科室：${appointment.department.name}\n时间：${appointment.date} ${appointment.time}\n患者：${appointment.patientName}\n排队号：${appointment.queueNumber}\n地址：${appointment.hospital.address}`,
              success: () => {
                wx.showToast({ title: '已复制到剪贴板', icon: 'success' })
              }
            })
          }
        }
      })
    }
  },

  // 查看我的预约
  viewMyAppointments() {
    if (this.data.myAppointments.length === 0) {
      wx.showToast({ title: '暂无预约记录', icon: 'none' })
      return
    }
    
    const appointment = this.data.myAppointments[0]
    wx.showModal({
      title: '我的预约',
      content: `医院：${appointment.hospital.name}\n科室：${appointment.department.name}\n时间：${appointment.date} ${appointment.time}\n患者：${appointment.patientName}\n状态：${appointment.status}`,
      confirmText: '确定',
      cancelText: '取消预约',
      success: (res) => {
        if (!res.confirm) {
          this.cancelAppointment(appointment.id)
        }
      }
    })
  },

  // 取消预约
  cancelAppointment(id) {
    wx.showModal({
      title: '确认取消',
      content: '确定要取消这个预约吗？',
      confirmColor: '#ff4d4f',
      success: (res) => {
        if (res.confirm) {
          const appointments = this.data.myAppointments.filter(a => a.id !== id)
          wx.setStorageSync('myAppointments', appointments)
          this.setData({ myAppointments: appointments })
          wx.showToast({ title: '已取消预约', icon: 'success' })
        }
      }
    })
  },

  // 导航到医院
  navigateToHospital() {
    const hospital = this.data.selectedHospital
    wx.showModal({
      title: '🧭 导航',
      content: `即将导航到：${hospital.name}\n地址：${hospital.address}\n距离：${hospital.distance}`,
      confirmText: '开始导航',
      confirmColor: '#1890FF',
      cancelText: '取消',
      success: (res) => {
        if (res.confirm) {
          wx.openLocation({
            latitude: hospital.latitude,
            longitude: hospital.longitude,
            name: hospital.name,
            address: hospital.address,
            scale: 18
          })
        }
      }
    })
  },

  // 拨打电话
  callHospital() {
    const hospital = this.data.selectedHospital
    wx.showModal({
      title: '📞 拨打电话',
      content: `${hospital.name}\n咨询电话：${hospital.phone}`,
      confirmText: '拨打',
      confirmColor: '#07C160',
      cancelText: '取消',
      success: (res) => {
        if (res.confirm) {
          wx.makePhoneCall({
            phoneNumber: hospital.phone,
            fail: () => {
              wx.showModal({
                title: '演示模式',
                content: `医院电话：${hospital.phone}\n（演示环境不支持拨打电话）`,
                showCancel: false
              })
            }
          })
        }
      }
    })
  }
})