Page({
  data: {
    medicineList: [],
    todayTotal: 0,
    takenCount: 0,
    pendingCount: 0
  },

  onLoad() {
    this.loadMedicineList()
  },

  onShow() {
    this.loadMedicineList()
  },

  // 加载用药列表
  loadMedicineList() {
    // 优先从本地存储读取
    let list = wx.getStorageSync('medicineList')
    
    // 如果没有数据，使用演示数据（国际赛事版本）
    if (!list || list.length === 0) {
      list = this.getDemoData()
      wx.setStorageSync('medicineList', list)
    }

    // 处理数据：添加状态、图标、下一个标记
    const processedList = this.processMedicineData(list)
    
    // 计算统计
    const stats = this.calculateStats(processedList)

    this.setData({
      medicineList: processedList,
      ...stats
    })
  },

  // 国际赛事演示数据
  getDemoData() {
    const currentHour = new Date().getHours()
    
    return [
      {
        id: 1,
        name: '降压药',
        nameEn: 'Amlodipine',
        dose: '1片 (5mg)',
        frequency: '每日一次',
        time: '08:00',
        enabled: true,
        type: 'pill',
        icon: '💊',
        taken: currentHour > 9,
        instructions: '早晨空腹服用，监测血压'
      },
      {
        id: 2,
        name: '降糖药',
        nameEn: 'Metformin',
        dose: '2片 (500mg)',
        frequency: '每日两次',
        time: '09:00',
        enabled: true,
        type: 'tablet',
        icon: '💠',
        taken: currentHour > 10,
        instructions: '餐后服用，多饮水'
      },
      {
        id: 3,
        name: '钙片',
        nameEn: 'Calcium + D3',
        dose: '1片 (600mg)',
        frequency: '每日一次',
        time: '20:00',
        enabled: true,
        type: 'vitamin',
        icon: '🌟',
        taken: false,
        instructions: '睡前服用，促进吸收'
      },
      {
        id: 4,
        name: '阿司匹林',
        nameEn: 'Aspirin',
        dose: '1片 (100mg)',
        frequency: '每日一次',
        time: '08:30',
        enabled: true,
        type: 'pill',
        icon: '💊',
        taken: currentHour > 10,
        instructions: '饭后服用，保护心血管'
      },
      {
        id: 5,
        name: '维生素C',
        nameEn: 'Vitamin C',
        dose: '1片 (100mg)',
        frequency: '每日两次',
        time: '12:00',
        enabled: false,
        type: 'vitamin',
        icon: '🍊',
        taken: false,
        instructions: '随餐服用，增强免疫力'
      },
      {
        id: 6,
        name: '鱼油胶囊',
        nameEn: 'Fish Oil',
        dose: '2粒 (1000mg)',
        frequency: '每日一次',
        time: '19:00',
        enabled: true,
        type: 'capsule',
        icon: '🐟',
        taken: false,
        instructions: '晚餐时服用，保护心脑'
      }
    ]
  },

  // 常用药品库（演示数据）
  getCommonMedicines() {
    return [
      { name: '降压药', nameEn: 'Amlodipine', dose: '1片 (5mg)', type: 'pill', icon: '💊', instructions: '早晨空腹服用' },
      { name: '降糖药', nameEn: 'Metformin', dose: '2片 (500mg)', type: 'tablet', icon: '💠', instructions: '餐后服用' },
      { name: '阿司匹林', nameEn: 'Aspirin', dose: '1片 (100mg)', type: 'pill', icon: '💊', instructions: '饭后服用' },
      { name: '钙片', nameEn: 'Calcium + D3', dose: '1片 (600mg)', type: 'vitamin', icon: '🌟', instructions: '睡前服用' },
      { name: '维生素C', nameEn: 'Vitamin C', dose: '1片 (100mg)', type: 'vitamin', icon: '🍊', instructions: '随餐服用' },
      { name: '鱼油胶囊', nameEn: 'Fish Oil', dose: '2粒 (1000mg)', type: 'capsule', icon: '🐟', instructions: '晚餐时服用' },
      { name: '维生素D', nameEn: 'Vitamin D3', dose: '1粒 (400IU)', type: 'vitamin', icon: '☀️', instructions: '早餐后服用' },
      { name: '复合维生素', nameEn: 'Multivitamin', dose: '1片', type: 'vitamin', icon: '🌈', instructions: '早餐后服用' },
      { name: '益生菌', nameEn: 'Probiotics', dose: '1袋', type: 'powder', icon: '🦠', instructions: '温水冲服' },
      { name: '氨糖软骨素', nameEn: 'Glucosamine', dose: '2片', type: 'tablet', icon: '🦴', instructions: '随餐服用' },
      { name: '银杏叶片', nameEn: 'Ginkgo Biloba', dose: '1片', type: 'tablet', icon: '🍃', instructions: '饭后服用' },
      { name: '辅酶Q10', nameEn: 'CoQ10', dose: '1粒 (100mg)', type: 'capsule', icon: '❤️', instructions: '随餐服用' },
      { name: '褪黑素', nameEn: 'Melatonin', dose: '1片 (3mg)', type: 'tablet', icon: '🌙', instructions: '睡前30分钟服用' },
      { name: '铁剂', nameEn: 'Iron Supplement', dose: '1片 (65mg)', type: 'tablet', icon: '🔴', instructions: '空腹服用，忌茶' },
      { name: '叶酸', nameEn: 'Folic Acid', dose: '1片 (400mcg)', type: 'tablet', icon: '🌿', instructions: '早餐后服用' },
      { name: '维生素B12', nameEn: 'Vitamin B12', dose: '1片 (500mcg)', type: 'tablet', icon: '🔵', instructions: '舌下含服' },
      { name: '钾片', nameEn: 'Potassium', dose: '1片 (99mg)', type: 'tablet', icon: '⚡', instructions: '饭后服用' },
      { name: '镁片', nameEn: 'Magnesium', dose: '1片 (200mg)', type: 'tablet', icon: '⚪', instructions: '睡前服用' },
      { name: '锌片', nameEn: 'Zinc', dose: '1片 (25mg)', type: 'tablet', icon: '⭐', instructions: '饭后服用' },
      { name: '护肝片', nameEn: 'Liver Support', dose: '2片', type: 'tablet', icon: '🛡️', instructions: '饭后服用' }
    ]
  },

  // 扫码添加药品（演示模式）
  scanMedicine() {
    wx.showLoading({ title: '扫描中...' })
    
    // 模拟扫描过程
    setTimeout(() => {
      wx.hideLoading()
      
      // 模拟扫码结果库
      const mockResults = [
        { 
          name: '硝苯地平缓释片', 
          nameEn: 'Nifedipine', 
          dose: '1片 (20mg)', 
          type: 'pill', 
          icon: '💊', 
          instructions: '早晚各一次，整片吞服，不可嚼碎',
          manufacturer: '拜耳医药'
        },
        { 
          name: '二甲双胍片', 
          nameEn: 'Metformin', 
          dose: '1片 (500mg)', 
          type: 'tablet', 
          icon: '💠', 
          instructions: '随餐服用，逐渐加量，注意胃肠道反应',
          manufacturer: '中美上海施贵宝'
        },
        { 
          name: '阿托伐他汀钙片', 
          nameEn: 'Atorvastatin', 
          dose: '1片 (20mg)', 
          type: 'pill', 
          icon: '💊', 
          instructions: '每晚一次，固定时间服用，定期监测肝功能',
          manufacturer: '辉瑞制药'
        },
        { 
          name: '缬沙坦胶囊', 
          nameEn: 'Valsartan', 
          dose: '1粒 (80mg)', 
          type: 'capsule', 
          icon: '💊', 
          instructions: '每日一次，早晨服用，可空腹或随餐',
          manufacturer: '诺华制药'
        },
        { 
          name: '格列美脲片', 
          nameEn: 'Glimepiride', 
          dose: '1片 (2mg)', 
          type: 'tablet', 
          icon: '💠', 
          instructions: '早餐前服用，注意低血糖风险',
          manufacturer: '赛诺菲'
        }
      ]
      
      const randomMed = mockResults[Math.floor(Math.random() * mockResults.length)]
      
      // 显示扫描结果详情
      wx.showModal({
        title: '📱 扫描成功',
        content: `【${randomMed.name}】\n英文：${randomMed.nameEn}\n规格：${randomMed.dose}\n厂商：${randomMed.manufacturer}\n\n用法：${randomMed.instructions}\n\n是否添加到用药提醒？`,
        confirmText: '添加',
        cancelText: '取消',
        success: (res) => {
          if (res.confirm) {
            this.showScanTimePicker(randomMed)
          }
        }
      })
    }, 1500)
  },

  // 扫码后选择时间
  showScanTimePicker(medicine) {
    const times = [
      { label: '早晨 07:00', value: '07:00' },
      { label: '早晨 08:00', value: '08:00' },
      { label: '上午 09:00', value: '09:00' },
      { label: '中午 12:00', value: '12:00' },
      { label: '下午 18:00', value: '18:00' },
      { label: '晚上 19:00', value: '19:00' },
      { label: '睡前 20:00', value: '20:00' },
      { label: '睡前 21:00', value: '21:00' }
    ]
    
    wx.showActionSheet({
      itemList: times.map(t => t.label),
      title: '选择服用时间',
      success: (res) => {
        const selectedTime = times[res.tapIndex].value
        this.addMedicineToList({
          ...medicine,
          frequency: '每日一次',
          time: selectedTime,
          enabled: true,
          taken: false
        })
      }
    })
  },

  // 手动输入药品 - 按分类展示
  manualInput() {
    wx.showActionSheet({
      itemList: ['💊 心血管类药品', '💠 代谢类药品', '🌟 维生素类', '🔴 营养补充', '✏️ 自定义输入'],
      success: (res) => {
        switch(res.tapIndex) {
          case 0:
            this.showCategoryMeds('cardiovascular')
            break
          case 1:
            this.showCategoryMeds('metabolic')
            break
          case 2:
            this.showCategoryMeds('vitamin')
            break
          case 3:
            this.showCategoryMeds('supplement')
            break
          case 4:
            this.customInput()
            break
        }
      }
    })
  },

  // 按分类显示药品
  showCategoryMeds(category) {
    const commonMeds = this.getCommonMedicines()
    let filteredMeds = []
    
    switch(category) {
      case 'cardiovascular':
        filteredMeds = commonMeds.filter(med => 
          ['降压药', '阿司匹林', '银杏叶片', '辅酶Q10'].includes(med.name)
        )
        break
      case 'metabolic':
        filteredMeds = commonMeds.filter(med => 
          ['降糖药', '氨糖软骨素'].includes(med.name)
        )
        break
      case 'vitamin':
        filteredMeds = commonMeds.filter(med => 
          ['维生素C', '维生素D', '复合维生素', '叶酸', '维生素B12'].includes(med.name)
        )
        break
      case 'supplement':
        filteredMeds = commonMeds.filter(med => 
          ['钙片', '鱼油胶囊', '铁剂', '钾片', '镁片', '锌片', '益生菌', '褪黑素', '护肝片'].includes(med.name)
        )
        break
    }
    
    const items = filteredMeds.map(med => `${med.icon} ${med.name} (${med.dose})`)
    
    wx.showActionSheet({
      itemList: items,
      title: '选择药品',
      success: (res) => {
        const selected = filteredMeds[res.tapIndex]
        this.showTimePicker(selected)
      }
    })
  },

  // 显示时间选择
  showTimePicker(medicine) {
    const times = ['06:00', '07:00', '08:00', '09:00', '12:00', '13:00', '18:00', '19:00', '20:00', '21:00', '22:00']
    
    wx.showActionSheet({
      itemList: times.map(t => `⏰ ${t}`),
      title: '选择服用时间',
      success: (res) => {
        const selectedTime = times[res.tapIndex]
        this.addMedicineToList({
          ...medicine,
          frequency: '每日一次',
          time: selectedTime,
          enabled: true,
          taken: false
        })
      }
    })
  },

  // 自定义输入 - 分步表单
  customInput() {
    // 第一步：输入药品名称
    wx.showModal({
      title: '✏️ 添加药品 (1/3)',
      placeholderText: '请输入药品名称，如：感冒药',
      editable: true,
      success: (res) => {
        if (res.confirm && res.content.trim()) {
          const name = res.content.trim()
          // 第二步：输入剂量
          this.inputDose(name)
        }
      }
    })
  },

  // 输入剂量
  inputDose(name) {
    wx.showModal({
      title: '✏️ 添加药品 (2/3)',
      placeholderText: '请输入剂量，如：1片 (500mg)',
      editable: true,
      success: (res) => {
        if (res.confirm) {
          const dose = res.content.trim() || '1片'
          // 第三步：选择时间
          this.inputTime(name, dose)
        }
      }
    })
  },

  // 选择时间
  inputTime(name, dose) {
    const times = [
      { label: '早晨 07:00', value: '07:00' },
      { label: '早晨 08:00', value: '08:00' },
      { label: '上午 09:00', value: '09:00' },
      { label: '中午 12:00', value: '12:00' },
      { label: '下午 18:00', value: '18:00' },
      { label: '晚上 19:00', value: '19:00' },
      { label: '睡前 20:00', value: '20:00' },
      { label: '睡前 21:00', value: '21:00' }
    ]
    
    wx.showActionSheet({
      itemList: times.map(t => t.label),
      title: '✏️ 添加药品 (3/3) - 选择时间',
      success: (res) => {
        const selectedTime = times[res.tapIndex].value
        const customMed = {
          name: name,
          nameEn: 'Custom Medicine',
          dose: dose,
          type: 'pill',
          icon: '💊',
          instructions: '请遵医嘱服用',
          frequency: '每日一次',
          time: selectedTime,
          enabled: true,
          taken: false
        }
        this.addMedicineToList(customMed)
      }
    })
  },

  // 从常用药品库选择
  selectFromCommon() {
    const commonMeds = this.getCommonMedicines()
    const items = commonMeds.map(med => `${med.icon} ${med.name} (${med.dose})`)
    
    wx.showActionSheet({
      itemList: items,
      title: '选择常用药品（演示数据）',
      success: (res) => {
        const selected = commonMeds[res.tapIndex]
        this.showTimePicker(selected)
      }
    })
  },

  // 添加药品到列表
  addMedicineToList(medicine) {
    const list = wx.getStorageSync('medicineList') || this.data.medicineList
    
    // 生成新ID
    const newId = Math.max(...list.map(item => item.id), 0) + 1
    
    const newMedicine = {
      ...medicine,
      id: newId
    }
    
    const newList = [...list, newMedicine]
    wx.setStorageSync('medicineList', newList)
    
    // 刷新列表
    const processedList = this.processMedicineData(newList)
    const stats = this.calculateStats(processedList)
    
    this.setData({
      medicineList: processedList,
      ...stats
    })
    
    wx.showToast({
      title: '添加成功',
      icon: 'success'
    })
  },

  // 重置演示数据
  resetDemoData() {
    wx.showModal({
      title: '🔄 重置数据',
      content: '确定要重置为演示数据吗？当前数据将被覆盖。',
      confirmText: '重置',
      confirmColor: '#E74C3C',
      cancelText: '取消',
      success: (res) => {
        if (res.confirm) {
          const demoData = this.getDemoData()
          wx.setStorageSync('medicineList', demoData)
          
          const processedList = this.processMedicineData(demoData)
          const stats = this.calculateStats(processedList)
          
          this.setData({
            medicineList: processedList,
            ...stats
          })
          
          wx.showToast({
            title: '已重置',
            icon: 'success'
          })
        }
      }
    })
  },

  // 处理用药数据
  processMedicineData(list) {
    const currentHour = new Date().getHours()
    const currentMinute = new Date().getMinutes()
    const currentTime = currentHour * 60 + currentMinute

    // 按时间排序
    const sortedList = [...list].sort((a, b) => {
      const timeA = this.parseTime(a.time)
      const timeB = this.parseTime(b.time)
      return timeA - timeB
    })

    // 找出下一个待服用的药
    let nextIndex = -1
    for (let i = 0; i < sortedList.length; i++) {
      const medTime = this.parseTime(sortedList[i].time)
      if (!sortedList[i].taken && sortedList[i].enabled && medTime > currentTime) {
        nextIndex = i
        break
      }
    }

    return sortedList.map((item, index) => {
      const medTime = this.parseTime(item.time)
      const timeDiff = medTime - currentTime
      
      let statusText = ''
      let statusClass = ''
      let isNext = index === nextIndex

      if (item.taken) {
        statusText = '已服用'
        statusClass = 'medicine-item__status-text--taken'
      } else if (!item.enabled) {
        statusText = '已暂停'
        statusClass = 'medicine-item__status-text--pending'
      } else if (timeDiff > 0 && timeDiff <= 60) {
        statusText = '即将服用'
        statusClass = 'medicine-item__status-text--soon'
        isNext = true
      } else if (timeDiff < 0) {
        statusText = '已过期'
        statusClass = 'medicine-item__status-text--pending'
      }

      return {
        ...item,
        statusText,
        statusClass,
        isNext
      }
    })
  },

  // 解析时间字符串为分钟数
  parseTime(timeStr) {
    const [hours, minutes] = timeStr.split(':').map(Number)
    return hours * 60 + minutes
  },

  // 计算统计数据
  calculateStats(list) {
    const todayTotal = list.filter(item => item.enabled).length
    const takenCount = list.filter(item => item.taken).length
    const pendingCount = todayTotal - takenCount

    return {
      todayTotal,
      takenCount,
      pendingCount: pendingCount > 0 ? pendingCount : 0
    }
  },

  // 切换提醒开关
  toggleMedicine(e) {
    const id = e.currentTarget.dataset.id
    const enabled = e.detail.value
    
    const list = this.data.medicineList.map(item => {
      if (item.id === id) {
        return { ...item, enabled }
      }
      return item
    })

    // 重新处理数据
    const processedList = this.processMedicineData(list)
    const stats = this.calculateStats(processedList)

    this.setData({
      medicineList: processedList,
      ...stats
    })

    wx.setStorageSync('medicineList', list)
    
    wx.showToast({
      title: enabled ? '提醒已开启' : '提醒已关闭',
      icon: 'success',
      duration: 1500
    })
  },

  // 显示药品详情
  showMedicineDetail(e) {
    const id = e.currentTarget.dataset.id
    const medicine = this.data.medicineList.find(item => item.id === id)
    
    if (!medicine) return

    const content = [
      `药品名称：${medicine.name}`,
      medicine.nameEn ? `英文名称：${medicine.nameEn}` : '',
      `服用剂量：${medicine.dose}`,
      `服用时间：${medicine.time}`,
      `服用频率：${medicine.frequency || '每日一次'}`,
      '',
      `用药说明：`,
      medicine.instructions || '请遵医嘱服用'
    ].filter(Boolean).join('\n')

    wx.showModal({
      title: '💊 药品详情',
      content: content,
      showCancel: false,
      confirmText: '知道了',
      confirmColor: '#667eea'
    })
  },

  // 添加用药
  addMedicine() {
    wx.showActionSheet({
      itemList: ['📱 扫码添加', '✏️ 手动输入', '📋 从常用药品选择'],
      success: (res) => {
        switch(res.tapIndex) {
          case 0:
            this.scanMedicine()
            break
          case 1:
            this.manualInput()
            break
          case 2:
            this.selectFromCommon()
            break
        }
      }
    })
  },

  // 标记已服用
  markAsTaken(e) {
    const id = e.currentTarget.dataset.id
    
    wx.showModal({
      title: '确认服用',
      content: '确认已服用此药物？',
      confirmText: '已服用',
      confirmColor: '#4CAF50',
      cancelText: '取消',
      success: (res) => {
        if (res.confirm) {
          const list = this.data.medicineList.map(item => {
            if (item.id === id) {
              return { ...item, taken: true }
            }
            return item
          })

          const processedList = this.processMedicineData(list)
          const stats = this.calculateStats(processedList)

          this.setData({
            medicineList: processedList,
            ...stats
          })

          wx.setStorageSync('medicineList', list)
          
          wx.showToast({
            title: '已标记服用',
            icon: 'success'
          })
        }
      }
    })
  }
})
