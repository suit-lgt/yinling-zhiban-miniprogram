Page({
  data: {
    selectedType: null,
    paymentTypes: [
      { id: 1, name: '水费', icon: '💧' },
      { id: 2, name: '电费', icon: '⚡' },
      { id: 3, name: '燃气费', icon: '🔥' },
      { id: 4, name: '宽带费', icon: '📶' }
    ],
    form: {
      account: ''
    },
    amounts: [50, 100, 200, 300],
    selectedAmount: 50,
    customAmount: ''
  },
  selectType(e) {
    const id = e.currentTarget.dataset.id
    const type = this.data.paymentTypes.find(t => t.id === id)
    this.setData({
      selectedType: type,
      'form.account': '',
      selectedAmount: 50,
      customAmount: ''
    })
  },
  onAccountInput(e) {
    this.setData({ 'form.account': e.detail.value })
  },
  selectAmount(e) {
    const amount = e.currentTarget.dataset.amount
    this.setData({
      selectedAmount: amount,
      customAmount: ''
    })
  },
  onCustomAmountInput(e) {
    this.setData({ customAmount: e.detail.value })
  },
  onCustomAmountFocus() {
    this.setData({ selectedAmount: 0 })
  },
  payNow() {
    if (!this.data.form.account) {
      wx.showToast({ title: '请输入户号', icon: 'none' })
      return
    }
    
    const amount = this.data.customAmount || this.data.selectedAmount
    if (!amount || amount <= 0) {
      wx.showToast({ title: '请选择缴费金额', icon: 'none' })
      return
    }
    
    wx.showModal({
      title: '确认缴费',
      content: `确认缴纳 ${this.data.selectedType.name} ¥${amount}？`,
      success: (res) => {
        if (res.confirm) {
          wx.showToast({
            title: '缴费成功',
            icon: 'success'
          })
        }
      }
    })
  }
})
