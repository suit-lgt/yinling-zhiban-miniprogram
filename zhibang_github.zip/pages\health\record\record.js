const tabNames = { bloodPressure: '血压', bloodSugar: '血糖', heartRate: '心率' }
const units = { bloodPressure: 'mmHg', bloodSugar: 'mmol/L', heartRate: '次/分' }

Page({
  data: {
    activeTab: 'bloodPressure',
    tabName: '血压',
    records: [],
    currentData: {
      latest: null,
      unit: 'mmHg',
      normalRange: [90, 140]
    },
    currentStatus: 'unknown',
    currentStatusText: '未记录',
    latestRecordTime: '暂无记录',
    chartData: []
  },
  onLoad(options) {
    if (options.type) {
      const tab = options.type
      this.setData({
        activeTab: tab,
        tabName: tabNames[tab] || '血压'
      })
    }
    this.loadData()
  },
  onShow() {
    this.loadData()
  },
  loadData() {
    const type = this.data.activeTab
    const storageKey = `healthRecords_${type}`
    let records = wx.getStorageSync(storageKey) || []
    
    // 如果没有数据，使用演示数据
    if (records.length === 0) {
      records = this.getDemoData(type)
    }
    
    // 处理记录数据
    const processedRecords = records.map(r => ({
      ...r,
      formattedDate: this.formatDate(r.createTime),
      status: this.getStatus(r.value),
      statusText: this.getStatusText(r.value)
    }))
    
    const latest = records.length > 0 ? records[0].value : null
    
    this.setData({
      records: processedRecords,
      'currentData.latest': latest,
      'currentData.unit': units[type],
      latestRecordTime: records.length > 0 ? this.formatDate(records[0].createTime) : '暂无记录',
      currentStatus: this.getStatus(latest),
      currentStatusText: this.getStatusText(latest),
      chartData: this.generateChartData(records)
    })
  },

  // 获取演示数据
  getDemoData(type) {
    const now = Date.now()
    const oneDay = 24 * 60 * 60 * 1000
    
    if (type === 'bloodPressure') {
      return [
        { id: 1, value: '128/82', createTime: now - oneDay * 0.5 },
        { id: 2, value: '132/85', createTime: now - oneDay * 1 },
        { id: 3, value: '125/78', createTime: now - oneDay * 2 },
        { id: 4, value: '135/88', createTime: now - oneDay * 3 },
        { id: 5, value: '130/80', createTime: now - oneDay * 4 },
        { id: 6, value: '118/75', createTime: now - oneDay * 5 },
        { id: 7, value: '122/76', createTime: now - oneDay * 6 }
      ]
    }
    
    if (type === 'bloodSugar') {
      return [
        { id: 1, value: '5.8', createTime: now - oneDay * 0.5 },
        { id: 2, value: '6.2', createTime: now - oneDay * 1 },
        { id: 3, value: '5.6', createTime: now - oneDay * 2 },
        { id: 4, value: '6.5', createTime: now - oneDay * 3 },
        { id: 5, value: '5.9', createTime: now - oneDay * 4 },
        { id: 6, value: '5.4', createTime: now - oneDay * 5 },
        { id: 7, value: '5.7', createTime: now - oneDay * 6 }
      ]
    }
    
    if (type === 'heartRate') {
      return [
        { id: 1, value: '72', createTime: now - oneDay * 0.5 },
        { id: 2, value: '75', createTime: now - oneDay * 1 },
        { id: 3, value: '68', createTime: now - oneDay * 2 },
        { id: 4, value: '78', createTime: now - oneDay * 3 },
        { id: 5, value: '71', createTime: now - oneDay * 4 },
        { id: 6, value: '65', createTime: now - oneDay * 5 },
        { id: 7, value: '70', createTime: now - oneDay * 6 }
      ]
    }
    
    return []
  },
  switchTab(e) {
    const tab = e.currentTarget.dataset.tab
    this.setData({
      activeTab: tab,
      tabName: tabNames[tab]
    })
    this.loadData()
  },
  getStatus(value) {
    if (!value) return 'unknown'
    const type = this.data.activeTab
    
    if (type === 'bloodPressure') {
      const [systolic] = String(value).split('/').map(Number)
      if (systolic < 120) return 'normal'
      if (systolic < 140) return 'warning'
      return 'danger'
    }
    
    if (type === 'bloodSugar') {
      const val = Number(value)
      if (val < 6.1) return 'normal'
      if (val < 7.0) return 'warning'
      return 'danger'
    }
    
    if (type === 'heartRate') {
      const val = Number(value)
      if (val >= 60 && val <= 100) return 'normal'
      return 'warning'
    }
    
    return 'unknown'
  },
  getStatusText(value) {
    const status = this.getStatus(value)
    const texts = { normal: '正常', warning: '偏高', danger: '很高', unknown: '' }
    return texts[status]
  },
  formatDate(timestamp) {
    if (!timestamp) return ''
    const date = new Date(timestamp)
    const month = (date.getMonth() + 1).toString().padStart(2, '0')
    const day = date.getDate().toString().padStart(2, '0')
    const hour = date.getHours().toString().padStart(2, '0')
    const minute = date.getMinutes().toString().padStart(2, '0')
    return `${month}-${day} ${hour}:${minute}`
  },
  generateChartData(records) {
    const days = []
    const dayNames = ['今天', '昨天', '前天', '4天前', '5天前', '6天前', '7天前']
    
    for (let i = 0; i < 7; i++) {
      const record = records[i]
      let val = '--'
      let height = 10
      if (record) {
        const rawVal = String(record.value).split('/')[0]
        val = rawVal
        height = Math.min(100, Math.max(20, parseInt(rawVal) / 2))
      }
      days.push({
        day: dayNames[i],
        value: val,
        height: height
      })
    }
    return days
  },
  addRecord() {
    wx.navigateTo({ url: '/pages/health/add-data/add-data' })
  },
  deleteRecord(e) {
    const id = e.currentTarget.dataset.id
    wx.showModal({
      title: '确认删除',
      content: '确定要删除这条记录吗？',
      success: (res) => {
        if (res.confirm) {
          const type = this.data.activeTab
          const storageKey = `healthRecords_${type}`
          let records = wx.getStorageSync(storageKey) || []
          records = records.filter(r => r.id !== id)
          wx.setStorageSync(storageKey, records)
          wx.showToast({ title: '已删除', icon: 'success' })
          this.loadData()
        }
      }
    })
  }
})
