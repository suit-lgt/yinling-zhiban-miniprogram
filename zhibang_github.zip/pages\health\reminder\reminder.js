Page({
  data: {
    reminderTypes: [
      { id: 1, name: '用药提醒', icon: '💊', count: 3 },
      { id: 2, name: '健康测量提醒', icon: '❤️', count: 2 },
      { id: 3, name: '日程提醒', icon: '📅', count: 5 }
    ],
    soundEnabled: true,
    vibrateEnabled: true,
    notificationEnabled: true,
    advanceIndex: 0,
    advanceOptions: ['不提前', '提前5分钟', '提前10分钟', '提前15分钟']
  },
  onLoad() {
    // 加载设置
    const settings = wx.getStorageSync('reminderSettings')
    if (settings) {
      this.setData({
        soundEnabled: settings.soundEnabled !== false,
        vibrateEnabled: settings.vibrateEnabled !== false,
        notificationEnabled: settings.notificationEnabled !== false,
        advanceIndex: settings.advanceIndex || 0
      })
    }
  },
  selectType(e) {
    const id = e.currentTarget.dataset.id
    const type = this.data.reminderTypes.find(t => t.id === id)
    wx.showToast({
      title: `${type.name}设置`,
      icon: 'none'
    })
  },
  toggleSound(e) {
    this.setData({ soundEnabled: e.detail.value })
    this.saveSettings()
  },
  toggleVibrate(e) {
    this.setData({ vibrateEnabled: e.detail.value })
    this.saveSettings()
  },
  toggleNotification(e) {
    this.setData({ notificationEnabled: e.detail.value })
    this.saveSettings()
  },
  changeAdvance(e) {
    this.setData({ advanceIndex: e.detail.value })
    this.saveSettings()
  },
  saveSettings() {
    const { soundEnabled, vibrateEnabled, notificationEnabled, advanceIndex } = this.data
    wx.setStorageSync('reminderSettings', { soundEnabled, vibrateEnabled, notificationEnabled, advanceIndex })
  }
})
