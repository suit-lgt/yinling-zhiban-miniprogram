// 家人协助页面
Page({
  data: {
    // 家人列表
    familyList: [
      { id: 1, name: '儿子', relation: '大儿子', phone: '13800138001', avatar: '👨', color: '#1890FF' },
      { id: 2, name: '女儿', relation: '小女儿', phone: '13800138002', avatar: '👩', color: '#EB2F96' },
      { id: 3, name: '老伴', relation: '配偶', phone: '13800138003', avatar: '👴', color: '#52C41A' }
    ],
    // 提醒设置
    reminderSettings: {
      medicine: true,
      appointment: true,
      abnormal: true
    },
    // 协助记录
    helpHistory: [
      { id: 1, icon: '📲', title: '屏幕共享 - 儿子', time: '今天 10:30', status: '已完成' },
      { id: 2, icon: '📍', title: '位置共享', time: '昨天 15:20', status: '已完成' },
      { id: 3, icon: '📊', title: '健康报告同步', time: '3天前', status: '已发送' }
    ],
    // 智能检测状态（仅用于显示徽章）
    fallDetection: {
      enabled: false
    }
  },

  onLoad() {
    this.loadFamilyList()
    this.loadReminderSettings()
    this.loadHelpHistory()
    this.loadFallDetectionSettings()
  },

  onShow() {
    // 每次显示页面时刷新检测状态
    this.loadFallDetectionSettings()
  },

  // 加载家人列表
  loadFamilyList() {
    const familyList = wx.getStorageSync('familyList')
    if (familyList && familyList.length > 0) {
      this.setData({ familyList })
    }
  },

  // 加载提醒设置
  loadReminderSettings() {
    const settings = wx.getStorageSync('familyReminderSettings')
    if (settings) {
      this.setData({ reminderSettings: settings })
    }
  },

  // 加载协助记录
  loadHelpHistory() {
    const history = wx.getStorageSync('familyHelpHistory')
    if (history && history.length > 0) {
      this.setData({ helpHistory: history })
    }
  },

  // 加载跌倒检测设置
  loadFallDetectionSettings() {
    const settings = wx.getStorageSync('fallDetectionSettings')
    if (settings) {
      this.setData({ fallDetection: { enabled: settings.enabled } })
    }
  },

  // SOS紧急求助
  handleSOS() {
    const { familyList } = this.data
    if (familyList.length === 0) {
      wx.showToast({ title: '请先添加家人', icon: 'none' })
      return
    }

    wx.showModal({
      title: '🆘 紧急求助',
      content: '即将向所有家人发送求助信息，并拨打紧急联系人电话',
      confirmText: '确认求助',
      confirmColor: '#F5222D',
      cancelText: '取消',
      success: (res) => {
        if (res.confirm) {
          // 发送求助信息给所有家人
          this.sendSOSMessage()
          
          // 记录求助
          this.addHelpHistory('🆘', '紧急求助', '已发送')
          
          wx.showToast({
            title: '已通知所有家人',
            icon: 'success',
            duration: 2000
          })
        }
      }
    })
  },

  // 发送SOS消息
  sendSOSMessage() {
    // 获取当前位置
    wx.getLocation({
      type: 'gcj02',
      success: (res) => {
        const { latitude, longitude } = res
        console.log('SOS位置:', latitude, longitude)
        // 这里可以调用云函数发送消息给所有家人
      },
      fail: () => {
        console.log('获取位置失败')
      }
    })
  },

  // 呼叫家人
  callFamily(e) {
    const index = e.currentTarget.dataset.index
    const family = this.data.familyList[index]
    
    wx.showActionSheet({
      itemList: ['拨打电话', '视频通话', '发送消息'],
      success: (res) => {
        switch (res.tapIndex) {
          case 0:
            wx.makePhoneCall({ phoneNumber: family.phone })
            break
          case 1:
            wx.showToast({ title: '发起视频通话...', icon: 'none' })
            break
          case 2:
            this.sendMessage(family)
            break
        }
      }
    })
  },

  // 发送消息
  sendMessage(family) {
    wx.showModal({
      title: `发送消息给${family.name}`,
      editable: true,
      placeholderText: '请输入消息内容',
      success: (res) => {
        if (res.confirm && res.content) {
          wx.showToast({ title: '消息已发送', icon: 'success' })
          this.addHelpHistory('💬', `发送消息 - ${family.name}`, '已发送')
        }
      }
    })
  },

  // 管理家人
  manageFamily() {
    wx.navigateTo({
      url: '/pages/health/emergency-contact/emergency-contact'
    })
  },

  // 添加家人
  addFamily() {
    wx.navigateTo({
      url: '/pages/health/emergency-contact/emergency-contact?action=add'
    })
  },

  // 请求屏幕共享协助
  requestScreenHelp() {
    wx.showModal({
      title: '📲 屏幕共享',
      content: '发起屏幕共享后，您的子女可以远程看到您的手机屏幕并指导您操作',
      confirmText: '发起共享',
      success: (res) => {
        if (res.confirm) {
          wx.showLoading({ title: '正在连接...' })
          setTimeout(() => {
            wx.hideLoading()
            wx.showToast({ title: '已通知家人', icon: 'success' })
            this.addHelpHistory('📲', '屏幕共享请求', '等待中')
          }, 1500)
        }
      }
    })
  },

  // 跳转到智能检测页面
  goToDetect() {
    wx.navigateTo({
      url: '/pages/health/detect/detect'
    })
  },

  // 发送位置
  sendLocation() {
    wx.showLoading({ title: '获取位置中...' })
    wx.getLocation({
      type: 'gcj02',
      success: (res) => {
        wx.hideLoading()
        const { latitude, longitude } = res
        
        wx.showModal({
          title: '📍 发送位置',
          content: '将您的当前位置发送给所有家人？',
          confirmText: '发送',
          success: (modalRes) => {
            if (modalRes.confirm) {
              wx.showToast({ title: '位置已发送', icon: 'success' })
              this.addHelpHistory('📍', '位置共享', '已发送')
            }
          }
        })
      },
      fail: () => {
        wx.hideLoading()
        wx.showToast({ title: '获取位置失败', icon: 'none' })
      }
    })
  },

  // 请求健康报告
  requestHealthReport() {
    wx.showModal({
      title: '📊 健康报告',
      content: '将您最近的健康数据生成报告发送给家人？',
      confirmText: '生成报告',
      success: (res) => {
        if (res.confirm) {
          wx.showLoading({ title: '生成报告中...' })
          setTimeout(() => {
            wx.hideLoading()
            wx.showToast({ title: '报告已发送', icon: 'success' })
            this.addHelpHistory('📊', '健康报告同步', '已发送')
          }, 1500)
        }
      }
    })
  },

  // 切换提醒设置
  toggleReminder(e) {
    const type = e.currentTarget.dataset.type
    const value = e.detail.value
    const reminderSettings = { ...this.data.reminderSettings, [type]: value }
    
    this.setData({ reminderSettings })
    wx.setStorageSync('familyReminderSettings', reminderSettings)
    
    const typeNames = {
      medicine: '用药提醒',
      appointment: '就诊提醒',
      abnormal: '异常数据提醒'
    }
    
    wx.showToast({
      title: `${typeNames[type]}${value ? '已开启' : '已关闭'}`,
      icon: 'none'
    })
  },

  // 添加协助记录
  addHelpHistory(icon, title, status) {
    const newRecord = {
      id: Date.now(),
      icon,
      title,
      time: new Date().toLocaleString('zh-CN', { month: 'numeric', day: 'numeric', hour: '2-digit', minute: '2-digit' }).replace('/', '-'),
      status
    }
    
    const helpHistory = [newRecord, ...this.data.helpHistory].slice(0, 10)
    this.setData({ helpHistory })
    wx.setStorageSync('familyHelpHistory', helpHistory)
  }
})
