Page({
  data: {
    // 当前位置（演示数据）
    currentLocation: '北京市朝阳区阳光花园小区',
    
    // 目的地
    destination: '',
    
    // 选中的车型
    selectedType: 1,
    
    // 车型列表（纯中文）
    taxiTypes: [
      { 
        id: 1, 
        name: '出租车', 
        price: '¥12起', 
        desc: '打表计价，安全可靠',
        icon: '🚕',
        color: '#1890ff'
      },
      { 
        id: 2, 
        name: '舒适专车', 
        price: '¥25起', 
        desc: '宽敞舒适，品质服务',
        icon: '🚗',
        color: '#52c41a'
      },
      { 
        id: 3, 
        name: '商务专车', 
        price: '¥35起', 
        desc: '高端商务，尊贵体验',
        icon: '🚙',
        color: '#722ed1'
      },
      { 
        id: 4, 
        name: '无障碍车', 
        price: '¥15起', 
        desc: '轮椅友好，贴心服务',
        icon: '♿',
        color: '#eb2f96'
      }
    ],
    
    // 常用目的地（演示数据）
    recentTaxis: [
      { 
        name: '朝阳医院', 
        address: '北京市朝阳区工体南路8号',
        distance: '2.3km',
        icon: '🏥'
      },
      { 
        name: '家乐福超市', 
        address: '北京市朝阳区建国路88号',
        distance: '1.5km',
        icon: '🛒'
      },
      { 
        name: '朝阳公园', 
        address: '北京市朝阳区朝阳公园南路1号',
        distance: '3.2km',
        icon: '🌳'
      },
      { 
        name: '三里屯太古里', 
        address: '北京市朝阳区三里屯路19号',
        distance: '4.1km',
        icon: '🏬'
      },
      { 
        name: '北京朝阳站', 
        address: '北京市朝阳区姚家园北路',
        distance: '5.8km',
        icon: '🚄'
      }
    ],
    
    // 叫车状态
    isCalling: false,
    callStatus: '',
    
    // 司机信息
    driverInfo: null
  },

  onLoad() {
    this.simulateGetLocation()
    this.loadDemoData()
  },

  // 加载演示数据
  loadDemoData() {
    const savedDest = wx.getStorageSync('taxiDestination')
    if (savedDest) {
      this.setData({
        destination: savedDest.name
      })
    }
  },

  // 模拟获取位置
  simulateGetLocation() {
    wx.showLoading({ title: '定位中...' })
    
    setTimeout(() => {
      wx.hideLoading()
      this.setData({
        currentLocation: '北京市朝阳区阳光花园小区'
      })
    }, 1000)
  },

  // 输入目的地
  onDestinationInput(e) {
    const destination = e.detail.value
    const distance = this.calculateDistance(destination)
    const prices = this.calculatePrices(distance)
    
    // 更新车型价格
    const taxiTypes = this.data.taxiTypes.map((type, index) => ({
      ...type,
      price: prices[index].price,
      distance: distance
    }))
    
    this.setData({ 
      destination: destination,
      taxiTypes: taxiTypes
    })
  },
  
  // 计算距离（模拟）
  calculateDistance(destination) {
    const longDistanceKeywords = ['上海', '天津', '河北', '山东', '河南', '山西', '辽宁', '吉林', '黑龙江']
    const mediumDistanceKeywords = ['通州', '顺义', '昌平', '大兴', '房山', '门头沟', '平谷', '密云', '怀柔', '延庆']
    
    // 检查是否长途
    for (let keyword of longDistanceKeywords) {
      if (destination.includes(keyword)) {
        if (destination.includes('上海')) return '1,318km'
        if (destination.includes('天津')) return '137km'
        if (destination.includes('石家庄')) return '292km'
        if (destination.includes('济南')) return '405km'
        if (destination.includes('郑州')) return '695km'
        if (destination.includes('太原')) return '508km'
        if (destination.includes('沈阳')) return '698km'
        return '500km+'
      }
    }
    
    // 检查是否中距离（北京郊区）
    for (let keyword of mediumDistanceKeywords) {
      if (destination.includes(keyword)) {
        return (30 + Math.floor(Math.random() * 40)) + 'km'
      }
    }
    
    // 默认短距离（市区内）
    return (2 + Math.floor(Math.random() * 8)) + 'km'
  },
  
  // 计算各车型价格
  calculatePrices(distance) {
    const numericDistance = parseFloat(distance.replace(/,/g, '').replace('km', ''))
    const isLongDistance = numericDistance > 100
    
    if (isLongDistance) {
      // 长途价格（按公里计价）
      return [
        { price: `¥${Math.round(numericDistance * 2.3)}起` },
        { price: `¥${Math.round(numericDistance * 4.5)}起` },
        { price: `¥${Math.round(numericDistance * 6)}起` },
        { price: `¥${Math.round(numericDistance * 3)}起` }
      ]
    } else {
      // 短途价格（起步价 + 里程费）
      const basePrices = [12, 25, 35, 15]
      const perKmPrices = [2.3, 4.5, 6, 3]
      
      return basePrices.map((base, index) => {
        const total = base + Math.round(numericDistance * perKmPrices[index])
        return { price: `¥${total}起` }
      })
    }
  },

  // 选择车型
  selectType(e) {
    const id = e.currentTarget.dataset.id
    this.setData({ selectedType: id })
    
    const selected = this.data.taxiTypes.find(t => t.id === id)
    wx.showToast({
      title: `已选择${selected.name}`,
      icon: 'none',
      duration: 1500
    })
  },

  // 选择常用目的地
  selectRecent(e) {
    const index = e.currentTarget.dataset.index
    const item = this.data.recentTaxis[index]
    
    const distance = item.distance
    const prices = this.calculatePrices(distance)
    
    const taxiTypes = this.data.taxiTypes.map((type, index) => ({
      ...type,
      price: prices[index].price,
      distance: distance
    }))
    
    this.setData({ 
      destination: item.name,
      taxiTypes: taxiTypes
    })
    
    wx.setStorageSync('taxiDestination', item)
    
    wx.showToast({
      title: `已选择：${item.name}`,
      icon: 'none'
    })
  },

  // 一键叫车（演示版）
  callTaxi() {
    if (!this.data.destination) {
      wx.showToast({ title: '请输入目的地', icon: 'none' })
      return
    }

    const selectedType = this.data.taxiTypes.find(t => t.id === this.data.selectedType)
    
    // 先显示确认弹窗，然后选择支付方式
    wx.showModal({
      title: '🚕 确认叫车',
      content: `车型：${selectedType.name}\n目的地：${this.data.destination}\n预估：${selectedType.price}`,
      confirmText: '确认呼叫',
      confirmColor: '#1890ff',
      cancelText: '取消',
      success: (res) => {
        if (res.confirm) {
          this.selectPaymentMethod(selectedType)
        }
      }
    })
  },
  
  // 选择支付方式
  selectPaymentMethod(selectedType) {
    const paymentMethods = [
      { name: '微信支付', icon: '💚', color: '#07C160' },
      { name: '支付宝', icon: '💙', color: '#1677FF' },
      { name: '银行卡', icon: '💳', color: '#FF6B6B' }
    ]
    
    wx.showActionSheet({
      itemList: paymentMethods.map(m => `${m.icon} ${m.name}`),
      title: '选择支付方式',
      success: (res) => {
        const selectedMethod = paymentMethods[res.tapIndex]
        
        // 显示支付确认
        wx.showModal({
          title: '💳 确认支付',
          content: `支付方式：${selectedMethod.name}\n预估费用：${selectedType.price}\n\n确认后将从您的${selectedMethod.name}扣款`,
          confirmText: '确认支付',
          confirmColor: selectedMethod.color,
          cancelText: '取消',
          success: (payRes) => {
            if (payRes.confirm) {
              wx.showLoading({ title: '正在支付...' })
              
              setTimeout(() => {
                wx.hideLoading()
                wx.showToast({
                  title: '支付成功',
                  icon: 'success',
                  duration: 1500
                })
                
                // 支付成功后开始叫车
                setTimeout(() => {
                  this.simulateCallTaxi()
                }, 1500)
              }, 1500)
            }
          }
        })
      }
    })
  },

  // 模拟叫车流程
  simulateCallTaxi() {
    this.setData({ isCalling: true, callStatus: '正在呼叫附近车辆...' })
    
    wx.showLoading({ title: '正在叫车...' })
    
    setTimeout(() => {
      wx.hideLoading()
      this.setData({ callStatus: '已找到司机，正在赶来...' })
      
      const mockDrivers = [
        { name: '王师傅', plate: '京A·88888', car: '大众帕萨特', color: '黑色', rating: 4.9, trips: 3256 },
        { name: '李师傅', plate: '京B·66666', car: '丰田凯美瑞', color: '白色', rating: 4.8, trips: 2890 },
        { name: '张师傅', plate: '京C·99999', car: '本田雅阁', color: '银色', rating: 5.0, trips: 4102 }
      ]
      
      const driver = mockDrivers[Math.floor(Math.random() * mockDrivers.length)]
      const arriveTime = Math.floor(Math.random() * 5) + 3
      
      this.setData({
        driverInfo: {
          ...driver,
          arriveTime: arriveTime
        }
      })
      
      wx.showToast({
        title: '司机已接单',
        icon: 'success'
      })
    }, 2000)
  },

  // 查看司机详情
  showDriverDetail() {
    const driver = this.data.driverInfo
    wx.showModal({
      title: '司机信息',
      content: `司机：${driver.name}\n评分：${driver.rating}分\n接单：${driver.trips}单\n车牌：${driver.plate}\n车型：${driver.color}${driver.car}\n预计${driver.arriveTime}分钟到达`,
      showCancel: false
    })
  },

  // 联系司机（演示数据）
  contactDriver() {
    const driver = this.data.driverInfo
    
    wx.showActionSheet({
      itemList: ['📞 拨打电话', '💬 发送消息'],
      success: (res) => {
        if (res.tapIndex === 0) {
          // 拨打电话（演示数据）
          wx.showModal({
            title: '拨打电话',
            content: `即将拨打 ${driver.name} 的电话\n📱 138****8888`,
            confirmText: '拨打',
            confirmColor: '#07C160',
            cancelText: '取消',
            success: (res) => {
              if (res.confirm) {
                wx.makePhoneCall({
                  phoneNumber: '13888888888',
                  success: () => {
                    wx.showToast({
                      title: '正在呼叫司机...',
                      icon: 'none'
                    })
                  },
                  fail: () => {
                    wx.showToast({
                      title: '演示模式：电话拨打模拟',
                      icon: 'none',
                      duration: 2000
                    })
                  }
                })
              }
            }
          })
        } else if (res.tapIndex === 1) {
          // 发送消息（演示数据）
          wx.showModal({
            title: '💬 发送消息',
            content: '司机：' + driver.name + '\n\n常用快捷消息：',
            confirmText: '我已到达',
            cancelText: '请稍等',
            success: (res) => {
              if (res.confirm) {
                wx.showToast({
                  title: '消息已发送：我已到达',
                  icon: 'success'
                })
              } else {
                wx.showToast({
                  title: '消息已发送：请稍等',
                  icon: 'success'
                })
              }
            }
          })
        }
      }
    })
  },

  // 取消叫车（演示数据）
  cancelTaxi() {
    wx.showModal({
      title: '取消叫车',
      content: '确定要取消当前订单吗？\n取消后可能需要重新叫车',
      confirmText: '确认取消',
      confirmColor: '#ff4d4f',
      cancelText: '继续等待',
      success: (res) => {
        if (res.confirm) {
          this.setData({
            isCalling: false,
            callStatus: '',
            driverInfo: null
          })
          wx.showToast({
            title: '订单已取消',
            icon: 'success'
          })
        }
      }
    })
  },

  // 分享行程（演示数据）
  shareTrip() {
    const driver = this.data.driverInfo
    wx.showModal({
      title: '分享行程',
      content: `将行程分享给亲友：\n\n司机：${driver.name}\n车牌：${driver.plate}\n车型：${driver.color}${driver.car}\n预计${driver.arriveTime}分钟到达`,
      confirmText: '分享',
      confirmColor: '#1890ff',
      cancelText: '取消',
      success: (res) => {
        if (res.confirm) {
          wx.showToast({
            title: '行程已分享',
            icon: 'success'
          })
        }
      }
    })
  }
})
