// pages/index/index.js
const speechService = require('../../utils/speech-service')
const sparkService = require('../../utils/spark-service')

Page({
  data: {
    userName: '老人',
    // 语音输入状态
    isRecording: false,
    recordDuration: 0,
    recordTimer: null,
    voiceStatus: 'idle', // idle, listening, recognizing, thinking, success
    highlightedText: '', // 高亮后的文本
    // 天气数据
    weather: {
      temp: '--',
      text: '获取中...',
      icon: '100',
      location: '当前位置',
      updateTime: ''
    },
    // 逐时天气预报
    hourlyWeather: [],
    // 天气建议
    weatherAdvice: '',
    lastVoiceText: '',
    responseText: '',
    todayReminders: [
      {
        _id: '1',
        title: '测量血压',
        reminder_time: '08:00',
        category_name: '健康',
        completed: false
      },
      {
        _id: '2',
        title: '服用降压药',
        reminder_time: '12:00',
        category_name: '用药',
        completed: true
      }
    ],
    quickApps: [
      { id: 1, name: '用药提醒', icon: '💊', colorStart: '#FF6B6B', colorEnd: '#EE5A24', action: 'medicine', tag: '健康必备' },
      { id: 2, name: '一键打车', icon: '🚗', colorStart: '#4ECDC4', colorEnd: '#1289A7', action: 'taxi', tag: '' },
      { id: 3, name: '医院挂号', icon: '🏥', colorStart: '#45B7D1', colorEnd: '#2980B9', action: 'hospital', tag: '' },
      { id: 4, name: '健康档案', icon: '📋', colorStart: '#26de81', colorEnd: '#20bf6b', action: 'health', tag: '新增' },
      { id: 5, name: '家人协助', icon: '👨‍👩‍👧', colorStart: '#FC5C7D', colorEnd: '#C0392B', action: 'family', tag: '重要' },
      { id: 6, name: '紧急求助', icon: '🆘', colorStart: '#f7971e', colorEnd: '#E67E22', action: 'phone', tag: '' },
      { id: 7, name: '线上咨询', icon: '💬', colorStart: '#fd79a8', colorEnd: '#e84393', action: 'consult', tag: '便民' },
      { id: 8, name: '反诈宣传', icon: '🛡️', colorStart: '#6C5CE7', colorEnd: '#4834D4', action: 'fraud', tag: '' }
    ],
    healthData: {
      bloodPressure: '120/80',
      bloodSugar: '5.6',
      heartRate: '72'
    }
  },

  onLoad() {
    this.checkHealthData()
    this.loadWeatherData()
  },

  // 加载天气数据
  loadWeatherData() {
    // 使用和风天气免费API - 需要申请API Key
    // 这里使用模拟数据演示，实际使用时替换为真实API调用
    this.getLocationAndWeather()
  },

  // 获取位置并查询天气
  getLocationAndWeather() {
    wx.getLocation({
      type: 'gcj02',
      success: (res) => {
        const { latitude, longitude } = res
        this.fetchWeatherData(latitude, longitude)
      },
      fail: () => {
        // 定位失败使用默认城市（北京）
        this.fetchWeatherData(39.9042, 116.4074)
        wx.showToast({
          title: '使用默认城市天气',
          icon: 'none'
        })
      }
    })
  },

  // 获取天气数据（使用和风天气API）
  fetchWeatherData(lat, lon) {
    // 和风天气API配置
    const KEY = '9511f3391f8c441f86f3cea97bf1709d'
    
    // 如果未配置API Key，使用模拟数据
    if (KEY === 'YOUR_QWEATHER_KEY') {
      this.setMockWeatherData()
      return
    }

    // 实时天气
    wx.request({
      url: `https://devapi.qweather.com/v7/weather/now?location=${lon},${lat}&key=${KEY}`,
      success: (res) => {
        console.log('天气API响应:', res.data)
        if (res.data && res.data.code === '200') {
          const now = res.data.now
          const hour = new Date().getHours()
          this.setData({
            weather: {
              temp: now.temp,
              text: now.text,
              icon: now.icon,
              location: '当前位置',
              updateTime: this.formatTime(new Date())
            },
            weatherTheme: this.getWeatherTheme(hour, now.icon)
          })
        } else {
          console.error('天气API错误:', res.data)
          this.setMockWeatherData()
        }
      },
      fail: (err) => {
        console.error('天气请求失败:', err)
        this.setMockWeatherData()
      }
    })

    // 逐时预报
    wx.request({
      url: `https://devapi.qweather.com/v7/weather/24h?location=${lon},${lat}&key=${KEY}`,
      success: (res) => {
        if (res.data && res.data.code === '200') {
          const hourly = res.data.hourly.slice(0, 5).map(item => ({
            time: item.fxTime.substring(11, 16),
            temp: item.temp,
            icon: item.icon,
            text: item.text
          }))
          this.setData({ hourlyWeather: hourly })
        }
      },
      fail: () => {
        // 使用模拟数据
        this.setData({
          hourlyWeather: [
            { time: '现在', temp: '23', icon: '101', text: '多云' },
            { time: '16时', temp: '24', icon: '101', text: '多云' },
            { time: '17时', temp: '23', icon: '100', text: '晴' },
            { time: '18时', temp: '22', icon: '100', text: '晴' },
            { time: '19时', temp: '20', icon: '150', text: '晴' }
          ]
        })
      }
    })

    // 生活指数
    wx.request({
      url: `https://devapi.qweather.com/v7/indices/1d?type=1&location=${lon},${lat}&key=${KEY}`,
      success: (res) => {
        if (res.data && res.data.code === '200') {
          this.setData({
            weatherAdvice: res.data.daily[0].text
          })
        }
      },
      fail: () => {
        this.setData({ weatherAdvice: '今日天气不错，适合出行' })
      }
    })
  },

  // 根据时间和天气获取背景样式类
  getWeatherTheme(hour, weatherCode) {
    // 时间段判断
    const isMorning = hour >= 5 && hour < 11    // 早晨 5-11点
    const isNoon = hour >= 11 && hour < 15      // 正午 11-15点
    const isAfternoon = hour >= 15 && hour < 18 // 下午 15-18点
    const isEvening = hour >= 18 && hour < 21   // 傍晚 18-21点
    const isNight = hour >= 21 || hour < 5      // 夜间 21-5点
    
    // 天气类型判断
    const isRainy = ['300', '301', '302', '303', '304', '305', '306', '307', '308', '309', '310', '311', '312', '313', '314', '315', '316', '317', '318', '399'].includes(weatherCode)
    const isSnowy = ['400', '401', '402', '403', '404', '405', '406', '407', '408', '409', '410', '499'].includes(weatherCode)
    const isCloudy = ['101', '102', '103', '104'].includes(weatherCode)
    const isSunny = ['100', '150'].includes(weatherCode)
    
    // 返回主题类名
    if (isRainy) return 'theme-rainy'
    if (isSnowy) return 'theme-snowy'
    if (isNight) return 'theme-night'
    if (isEvening) return 'theme-evening'
    if (isAfternoon) return 'theme-afternoon'
    if (isNoon) return 'theme-noon'
    if (isMorning) return 'theme-morning'
    return 'theme-default'
  },

  // 模拟天气数据（用于演示）
  setMockWeatherData() {
    const hour = new Date().getHours()
    const mockData = {
      weather: {
        temp: '23',
        text: '晴间多云',
        icon: '101',
        location: '当前位置',
        updateTime: this.formatTime(new Date())
      },
      hourlyWeather: [
        { time: '现在', temp: '23', icon: '101', text: '多云' },
        { time: '16时', temp: '24', icon: '101', text: '多云' },
        { time: '17时', temp: '23', icon: '100', text: '晴' },
        { time: '18时', temp: '22', icon: '100', text: '晴' },
        { time: '19时', temp: '20', icon: '150', text: '晴' }
      ],
      weatherAdvice: '今日天气不错，适合出行',
      weatherTheme: this.getWeatherTheme(hour, '101')
    }
    this.setData(mockData)
  },

  // 格式化时间
  formatTime(date) {
    const hours = date.getHours().toString().padStart(2, '0')
    const minutes = date.getMinutes().toString().padStart(2, '0')
    return `${hours}:${minutes}`
  },

  // 天气图标映射表
  weatherIconMap: {
    '100': '☀️', '101': '🌤️', '102': '⛅', '103': '☁️',
    '104': '☁️', '150': '🌙', '151': '🌤️', '152': '☁️',
    '300': '🌦️', '301': '🌧️', '302': '⛈️', '303': '⛈️',
    '304': '⛈️', '305': '🌦️', '306': '🌧️', '307': '🌧️',
    '310': '🌧️', '311': '🌧️', '312': '🌧️', '313': '🌧️',
    '314': '🌧️', '315': '🌧️', '316': '🌧️', '317': '🌧️',
    '318': '🌧️', '399': '🌧️', '400': '🌨️', '401': '🌨️',
    '402': '❄️', '403': '❄️', '404': '🌨️', '405': '🌨️',
    '406': '🌨️', '407': '🌨️', '408': '🌨️', '409': '🌨️',
    '410': '❄️', '499': '🌨️', '500': '🌫️', '501': '🌫️',
    '502': '🌫️', '503': '🌫️', '504': '🌫️', '507': '🌫️',
    '508': '🌫️', '509': '🌫️', '510': '🌫️', '511': '🌫️',
    '512': '🌫️', '513': '🌫️', '514': '🌫️', '515': '🌫️'
  },

  // 获取天气图标
  getWeatherIcon(iconCode) {
    return this.weatherIconMap[iconCode] || '☀️'
  },

  checkHealthData() {
    const { bloodPressure, bloodSugar, heartRate } = this.data.healthData
    this.setData({
      hasHealthData: !!(bloodPressure || bloodSugar || heartRate)
    })
  },

  // ========== 语音输入功能 ==========
  
  // 开始录音
  handleVoiceStart() {
    // 检查录音权限
    wx.getSetting({
      success: (res) => {
        if (!res.authSetting['scope.record']) {
          wx.authorize({
            scope: 'scope.record',
            success: () => {
              this.startRecording()
            },
            fail: () => {
              wx.showModal({
                title: '需要录音权限',
                content: '请在设置中开启录音权限',
                confirmText: '去设置',
                success: (res) => {
                  if (res.confirm) {
                    wx.openSetting()
                  }
                }
              })
            }
          })
        } else {
          this.startRecording()
        }
      }
    })
  },
  
  // 开始录音
  startRecording() {
    console.log('开始录音')
    
    // 先重置状态
    if (this.data.recordTimer) {
      clearInterval(this.data.recordTimer)
    }
    
    this.setData({ 
      isRecording: true,
      voiceStatus: 'listening',
      recordDuration: 0,
      lastVoiceText: '',
      highlightedText: ''
    })
    
    // 设置录音结束回调
    speechService.onRecordEnd((text, error) => {
      console.log('录音识别回调:', text, error)
      this.handleVoiceResult(text, error)
    })
    
    // 开始录音
    speechService.startRecord()
    
    // 开始计时
    const timer = setInterval(() => {
      if (!this.data.isRecording) {
        clearInterval(timer)
        return
      }
      this.setData({
        recordDuration: this.data.recordDuration + 1
      })
      
      // 最长录音60秒
      if (this.data.recordDuration >= 60) {
        this.handleVoiceEnd()
      }
    }, 1000)
    
    this.setData({ recordTimer: timer })
    
    // 震动反馈
    wx.vibrateShort({ type: 'light' })
  },
  
  // 结束录音
  handleVoiceEnd() {
    console.log('结束录音')
    
    // 先停止计时器
    if (this.data.recordTimer) {
      clearInterval(this.data.recordTimer)
    }
    
    this.setData({ 
      isRecording: false,
      voiceStatus: 'recognizing',
      recordTimer: null
    })
    
    // 停止录音
    speechService.stopRecord()
  },
  
  // 处理语音识别结果
  handleVoiceResult(text, error) {
    if (error) {
      console.error('识别错误:', error)
      this.setData({
        voiceStatus: 'idle'
      })
      wx.showToast({
        title: '识别失败：' + error,
        icon: 'none'
      })
      return
    }
    
    if (!text || text.trim() === '') {
      this.setData({
        voiceStatus: 'idle'
      })
      wx.showToast({
        title: '没有识别到语音，请重试',
        icon: 'none'
      })
      return
    }
    
    console.log('识别结果：', text)
    
    // 高亮关键词
    const highlightedText = this.highlightKeywords(text)
    
    this.setData({
      lastVoiceText: text,
      highlightedText: highlightedText,
      voiceStatus: 'thinking'
    })
    
    // 处理语音指令
    this.processVoiceCommand(text)
  },

  // 关键词高亮
  highlightKeywords(text) {
    const keywords = [
      { word: '血压', color: '#FFD700' },
      { word: '血糖', color: '#FFD700' },
      { word: '心率', color: '#FFD700' },
      { word: '健康', color: '#FFD700' },
      { word: '打车', color: '#FFD700' },
      { word: '医院', color: '#FFD700' },
      { word: '挂号', color: '#FFD700' },
      { word: '吃药', color: '#FFD700' },
      { word: '药', color: '#FFD700' },
      { word: '提醒', color: '#FFD700' },
      { word: '天气', color: '#FFD700' },
      { word: '温度', color: '#FFD700' },
      { word: '出租车', color: '#FFD700' },
      { word: '叫车', color: '#FFD700' },
      { word: '看病', color: '#FFD700' },
      { word: '子女', color: '#FFD700' },
      { word: '电话', color: '#FFD700' },
      { word: '紧急', color: '#FF6B6B' },
      { word: 'SOS', color: '#FF6B6B' },
      { word: '帮助', color: '#FFD700' }
    ]
    
    let highlightedText = text
    keywords.forEach(({ word, color }) => {
      const regex = new RegExp(word, 'g')
      highlightedText = highlightedText.replace(regex, `<span style="color: ${color}; font-weight: bold; text-shadow: 0 0 10rpx rgba(255, 215, 0, 0.5);">${word}</span>`)
    })
    
    return highlightedText
  },
  
  // 处理语音指令 - 使用星火大模型
  async processVoiceCommand(text) {
    try {
      // 先检查是否是快捷指令
      const quickType = sparkService.getQuickReply(text)
      
      if (quickType === 'weather') {
        const { weather } = this.data
        const reply = `当前天气${weather.text}，温度${weather.temp}度。${weather.temp > 28 ? '天气较热，注意防暑降温，多喝水。' : weather.temp < 15 ? '天气较冷，注意保暖，适当添衣。' : '天气适宜，适合外出活动。'}`
        this.setData({ responseText: reply })
        wx.hideLoading()
        return
      }
      
      // 调用星火大模型
      const result = await sparkService.chat(text)
      
      if (result.success) {
        this.setData({
          responseText: result.answer,
          voiceStatus: 'success'
        })
        
        // 3秒后重置状态
        setTimeout(() => {
          this.setData({
            voiceStatus: 'idle'
          })
        }, 3000)
        
        // 根据回复内容执行相应操作
        this.executeAfterReply(text, result.answer)
      } else {
        throw new Error(result.message)
      }
    } catch (err) {
      console.error('AI对话失败', err)
      
      // 降级到本地规则匹配
      this.fallbackCommand(text)
    }
  },
  
  // 根据AI回复执行操作
  executeAfterReply(question, answer) {
    // 如果AI建议去某个页面，延迟后自动跳转
    if (answer.includes('健康') && answer.includes('记录')) {
      setTimeout(() => {
        wx.navigateTo({ url: '/pages/health/health' })
      }, 2000)
    } else if (answer.includes('打车') || answer.includes('出行')) {
      setTimeout(() => {
        wx.navigateTo({ url: '/pages/health/taxi/taxi' })
      }, 2000)
    } else if (answer.includes('医院') || answer.includes('挂号')) {
      setTimeout(() => {
        wx.navigateTo({ url: '/pages/health/hospital/hospital' })
      }, 2000)
    } else if (answer.includes('药') || answer.includes('提醒')) {
      setTimeout(() => {
        wx.navigateTo({ url: '/pages/health/medicine/medicine' })
      }, 2000)
    }
  },
  
  // 降级方案：本地规则匹配
  fallbackCommand(text) {
    const commands = [
      { 
        keywords: ['血压', '血糖', '心率', '健康'],
        reply: '为您打开健康数据页面，您可以记录和查看血压、血糖、心率等信息。'
      },
      {
        keywords: ['打车', '出租车', '叫车'],
        reply: '正在为您打开打车服务...'
      },
      {
        keywords: ['医院', '挂号', '看病'],
        reply: '为您打开医院挂号服务。'
      },
      {
        keywords: ['吃药', '药', '提醒'],
        reply: '为您打开用药提醒功能。'
      },
      {
        keywords: ['天气', '温度'],
        reply: '您可以查看首页的天气信息。'
      }
    ]
    
    const matched = commands.find(cmd => 
      cmd.keywords.some(kw => text.includes(kw))
    )
    
    this.setData({
      responseText: matched ? matched.reply : `您说："${text}"。抱歉，我暂时没听懂，请再说一遍。`,
      voiceStatus: 'success'
    })
    
    // 3秒后重置状态
    setTimeout(() => {
      this.setData({
        voiceStatus: 'idle'
      })
    }, 3000)
  },

  // 朗读回复
  speakResponse() {
    const { responseText } = this.data
    if (responseText) {
      speechService.speak(responseText)
      wx.showToast({
        title: '正在朗读...',
        icon: 'none'
      })
    }
  },

  // 执行操作
  executeAction() {
    wx.showToast({
      title: '执行操作',
      icon: 'none'
    })
  },

  // 切换提醒完成状态
  toggleComplete(e) {
    const id = e.currentTarget.dataset.id
    const reminders = this.data.todayReminders.map(item => {
      if (item._id === id) {
        return { ...item, completed: !item.completed }
      }
      return item
    })
    this.setData({ todayReminders: reminders })
  },

  // 快捷功能点击
  handleQuickClick(e) {
    const app = e.currentTarget.dataset.app
    const pathMap = {
      medicine: '/pages/health/medicine/medicine',
      taxi: '/pages/health/taxi/taxi',
      hospital: '/pages/health/hospital/hospital',
      phone: '/pages/health/emergency-contact/emergency-contact',
      fraud: '/pages/health/fraud/fraud',
      health: '/pages/health/record/record',
      family: '/pages/health/remote/remote',
      express: '/pages/health/express/express',
      consult: '/pages/consult/consult'
    }
    
    if (app.action === 'phone') {
      this.handleSOS()
    } else {
      const path = pathMap[app.action]
      if (path) {
        wx.navigateTo({ url: path })
      } else {
        wx.showToast({ title: '功能开发中', icon: 'none' })
      }
    }
  },

  // 跳转到通知
  goToNotification() {
    wx.showToast({
      title: '通知功能开发中',
      icon: 'none'
    })
  },

  // 跳转到健康页面
  goToHealth() {
    wx.switchTab({ url: '/pages/health/health' })
  },

  // SOS紧急求助
  handleSOS() {
    wx.showModal({
      title: '紧急求助',
      content: '确定要拨打紧急求助电话吗？',
      confirmText: '拨打',
      confirmColor: '#E74C3C',
      success: (res) => {
        if (res.confirm) {
          wx.makePhoneCall({
            phoneNumber: '120',
            success: () => {
              wx.showToast({ title: '正在拨打 120' })
            }
          })
        }
      }
    })
  }
})
