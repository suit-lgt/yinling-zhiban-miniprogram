Page({
  data: {},
  onLoad() {}
})
