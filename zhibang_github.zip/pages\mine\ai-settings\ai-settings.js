Page({
  data: {
    currentModel: 'zhipu',
    models: [
      { id: 'zhipu', name: '智谱GLM-4', icon: '🧠', desc: '性价比最高，推荐使用' },
      { id: 'qwen', name: '阿里通义千问', icon: '💬', desc: '阿里云出品，稳定可靠' },
      { id: 'wenxin', name: '百度文心一言', icon: '📚', desc: '百度AI，了解中文' }
    ],
    apiKey: '',
    autoSpeak: false,
    continuousMode: false
  },
  onLoad() {
    this.loadSettings()
  },
  loadSettings() {
    const model = wx.getStorageSync('ai_model') || 'zhipu'
    const autoSpeak = wx.getStorageSync('voiceEnabled') === true
    const continuousMode = wx.getStorageSync('ai_continuous') === true
    const savedKey = wx.getStorageSync(`api_key_${model}`) || ''
    
    this.setData({
      currentModel: model,
      autoSpeak,
      continuousMode,
      apiKey: savedKey
    })
  },
  selectModel(e) {
    const id = e.currentTarget.dataset.id
    const savedKey = wx.getStorageSync(`api_key_${id}`) || ''
    this.setData({
      currentModel: id,
      apiKey: savedKey
    })
    wx.setStorageSync('ai_model', id)
  },
  onApiKeyInput(e) {
    this.setData({ apiKey: e.detail.value })
  },
  saveApiKey() {
    if (!this.data.apiKey.trim()) {
      wx.showToast({ title: '请输入API Key', icon: 'none' })
      return
    }
    wx.setStorageSync(`api_key_${this.data.currentModel}`, this.data.apiKey)
    wx.showToast({ title: '配置已保存', icon: 'success' })
  },
  toggleAutoSpeak(e) {
    this.setData({ autoSpeak: e.detail.value })
    wx.setStorageSync('voiceEnabled', e.detail.value)
  },
  toggleContinuous(e) {
    this.setData({ continuousMode: e.detail.value })
    wx.setStorageSync('ai_continuous', e.detail.value)
  },
  clearHistory() {
    wx.showModal({
      title: '确认清空',
      content: '确定要清空所有对话历史吗？',
      success: (res) => {
        if (res.confirm) {
          wx.removeStorageSync('chatHistory')
          wx.showToast({ title: '已清空', icon: 'success' })
        }
      }
    })
  }
})
