Page({
  data: {
    selectedType: 1,
    feedbackTypes: [
      { id: 1, name: '功能建议' },
      { id: 2, name: '问题反馈' },
      { id: 3, name: '体验问题' },
      { id: 4, name: '其他' }
    ],
    content: '',
    contact: ''
  },
  selectType(e) {
    const id = e.currentTarget.dataset.id
    this.setData({ selectedType: id })
  },
  onContentInput(e) {
    this.setData({ content: e.detail.value })
  },
  onContactInput(e) {
    this.setData({ contact: e.detail.value })
  },
  submitFeedback() {
    if (!this.data.content.trim()) {
      wx.showToast({ title: '请输入反馈内容', icon: 'none' })
      return
    }
    
    wx.showLoading({ title: '提交中...' })
    
    setTimeout(() => {
      wx.hideLoading()
      wx.showToast({
        title: '感谢您的反馈',
        icon: 'success'
      })
      setTimeout(() => {
        wx.navigateBack()
      }, 1500)
    }, 1000)
  }
})
