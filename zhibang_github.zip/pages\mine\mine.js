Page({
  data: {
    userInfo: {},
    isLoggedIn: false,
    loginDays: 0,
    stats: { total: 0 },
    emergencyContactsCount: 0,
    isDark: false,
    voiceEnabled: false,
    tabVibrate: true,
    tabSound: false
  },

  onLoad() {
    this.loadUserInfo()
    this.loadStats()
    this.loadSettings()
    this.loadEmergencyContacts()
  },

  onShow() {
    this.loadUserInfo()
    this.loadStats()
    this.loadSettings()
    this.loadEmergencyContacts()
  },

  loadUserInfo() {
    const user = wx.getStorageSync('user')
    if (user) {
      this.setData({
        userInfo: user,
        isLoggedIn: true,
        loginDays: wx.getStorageSync('loginDays') || 1
      })
    } else {
      this.setData({
        userInfo: {},
        isLoggedIn: false,
        loginDays: 0
      })
    }
  },

  loadStats() {
    const memos = wx.getStorageSync('memos') || []
    this.setData({ stats: { total: memos.length } })
  },

  loadSettings() {
    this.setData({
      isDark: wx.getStorageSync('isDarkMode') || false,
      voiceEnabled: wx.getStorageSync('voiceEnabled') || false,
      tabVibrate: wx.getStorageSync('tabVibrate') !== false,
      tabSound: wx.getStorageSync('tabSound') || false
    })
  },

  loadEmergencyContacts() {
    const contacts = wx.getStorageSync('emergencyContacts') || []
    this.setData({ emergencyContactsCount: contacts.length })
  },

  goToProfile() {
    if (this.data.isLoggedIn) {
      wx.navigateTo({ url: '/pages/mine/profile/profile' })
    } else {
      wx.showToast({ title: '登录功能开发中', icon: 'none' })
    }
  },

  goToEmergencyContact() {
    wx.navigateTo({ url: '/pages/health/emergency-contact/emergency-contact' })
  },

  goToMedicine() {
    wx.navigateTo({ url: '/pages/health/medicine/medicine' })
  },

  goToFeedback() {
    wx.navigateTo({ url: '/pages/mine/feedback/feedback' })
  },

  goToAbout() {
    wx.navigateTo({ url: '/pages/mine/about/about' })
  },

  goToAISettings() {
    wx.navigateTo({ url: '/pages/mine/ai-settings/ai-settings' })
  },

  goToMemo() {
    wx.switchTab({ url: '/pages/tools/tools' })
  },

  toggleDark(e) {
    const isDark = e.detail.value
    this.setData({ isDark })
    wx.setStorageSync('isDarkMode', isDark)
    wx.showToast({ title: isDark ? '深色模式已开启' : '深色模式已关闭', icon: 'none' })
  },

  toggleVoice(e) {
    const voiceEnabled = e.detail.value
    this.setData({ voiceEnabled })
    wx.setStorageSync('voiceEnabled', voiceEnabled)
    wx.showToast({ title: voiceEnabled ? '语音播报已开启' : '语音播报已关闭', icon: 'none' })
  },

  toggleTabVibrate(e) {
    const tabVibrate = e.detail.value
    this.setData({ tabVibrate })
    wx.setStorageSync('tabVibrate', tabVibrate)
    if (tabVibrate) {
      wx.vibrateShort({ type: 'light' })
    }
  },

  toggleTabSound(e) {
    const tabSound = e.detail.value
    this.setData({ tabSound })
    wx.setStorageSync('tabSound', tabSound)
    wx.showToast({ title: tabSound ? '提示音效已开启' : '提示音效已关闭', icon: 'none' })
  },

  handleLogout() {
    wx.showModal({
      title: '提示',
      content: '确定要退出登录吗？',
      success: (res) => {
        if (res.confirm) {
          wx.removeStorageSync('user')
          wx.removeStorageSync('user_token')
          this.setData({
            userInfo: {},
            isLoggedIn: false,
            loginDays: 0,
            stats: { total: 0 }
          })
          wx.showToast({ title: '已退出登录', icon: 'success' })
        }
      }
    })
  }
})
