Page({
  data: {
    userInfo: {
      name: '',
      phone: '',
      avatar: '',
      gender: 0,
      birthday: '',
      address: ''
    },
    genderIndex: 0,
    genders: ['保密', '男', '女']
  },
  onLoad() {
    this.loadUserInfo()
  },
  loadUserInfo() {
    const user = wx.getStorageSync('userInfo')
    if (user) {
      this.setData({
        userInfo: { ...this.data.userInfo, ...user },
        genderIndex: user.gender || 0
      })
    }
  },
  onNameInput(e) {
    this.setData({ 'userInfo.name': e.detail.value })
  },
  onAddressInput(e) {
    this.setData({ 'userInfo.address': e.detail.value })
  },
  changeGender(e) {
    const index = e.detail.value
    this.setData({
      genderIndex: index,
      'userInfo.gender': index
    })
  },
  changeBirthday(e) {
    this.setData({ 'userInfo.birthday': e.detail.value })
  },
  saveProfile() {
    wx.setStorageSync('userInfo', this.data.userInfo)
    wx.showToast({
      title: '保存成功',
      icon: 'success'
    })
    setTimeout(() => {
      wx.navigateBack()
    }, 1500)
  }
})
