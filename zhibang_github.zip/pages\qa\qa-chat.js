Page({
  data: {
    messages: [],
    inputText: '',
    inputMode: 'voice',
    isThinking: false,
    isRecording: false,
    hintMessage: '',
    speakingIndex: -1,
    scrollToView: ''
  },

  onLoad() {
    this.loadHistory()
  },

  onUnload() {
    this.stopSpeaking()
    if (this.hintTimer) clearTimeout(this.hintTimer)
  },

  loadHistory() {
    const history = wx.getStorageSync('chatHistory') || []
    if (history.length > 0) {
      this.setData({ messages: history.slice(-10) })
    }
  },

  saveHistory() {
    wx.setStorageSync('chatHistory', this.data.messages)
  },

  switchMode(e) {
    const mode = e.currentTarget.dataset.mode
    this.setData({ inputMode: mode })
  },

  onInput(e) {
    this.setData({ inputText: e.detail.value })
  },

  sendExample(e) {
    const text = e.currentTarget.dataset.text
    this.sendMessage(text)
  },

  sendMessage(text) {
    const messageText = String(text || this.data.inputText || '').trim()
    if (!messageText) return

    const messages = this.data.messages
    messages.push({
      role: 'user',
      content: messageText
    })

    this.setData({ 
      messages: messages,
      inputText: '',
      isThinking: true
    }, () => {
      this.scrollToBottom()
    })

    this.saveHistory()

    // 模拟AI回复
    setTimeout(() => {
      const responses = [
        '您好！我是银龄智能助手，很高兴为您服务。',
        '这是一个很好的问题，让我为您解答。',
        '根据您的描述，我建议您咨询专业医生。',
        '您可以在健康中心查看相关数据。',
        '如需帮助，请随时告诉我。'
      ]
      const response = responses[Math.floor(Math.random() * responses.length)]
      
      messages.push({
        role: 'assistant',
        content: response
      })

      this.setData({ 
        messages: messages,
        isThinking: false
      }, () => {
        this.scrollToBottom()
      })

      this.saveHistory()
    }, 1500)
  },

  startRecord() {
    this.setData({ isRecording: true })
    wx.showToast({ title: '开始录音', icon: 'none' })
  },

  stopRecord() {
    this.setData({ isRecording: false })
    // 模拟语音识别结果
    setTimeout(() => {
      this.sendMessage('今天天气怎么样？')
    }, 500)
  },

  speakMessage(e) {
    const { index, content } = e.currentTarget.dataset
    if (this.data.speakingIndex === index) {
      this.stopSpeaking()
      this.setData({ speakingIndex: -1 })
    } else {
      this.setData({ speakingIndex: index })
      wx.showToast({ title: '朗读: ' + content.substring(0, 10) + '...', icon: 'none' })
    }
  },

  stopSpeaking() {
    // 停止语音播放
  },

  clearChat() {
    wx.showModal({
      title: '提示',
      content: '确定要清空对话历史吗？',
      success: (res) => {
        if (res.confirm) {
          this.setData({ messages: [] })
          wx.removeStorageSync('chatHistory')
          wx.showToast({ title: '已清空', icon: 'success' })
        }
      }
    })
  },

  showHint(message) {
    this.setData({ hintMessage: message })
    if (this.hintTimer) clearTimeout(this.hintTimer)
    this.hintTimer = setTimeout(() => {
      this.setData({ hintMessage: '' })
    }, 3000)
  },

  scrollToBottom() {
    const len = this.data.messages.length
    if (len > 0) {
      this.setData({ scrollToView: 'msg-' + (len - 1) })
    }
  }
})
