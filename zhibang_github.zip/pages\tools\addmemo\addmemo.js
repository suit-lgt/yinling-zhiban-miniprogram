Page({
  data: {
    memo: {
      title: '',
      reminder_date: '',
      reminder_time: '08:00'
    },
    displayDate: '选择日期',
    templates: [
      { title: '该吃药了', icon: '💊', time: '08:00' },
      { title: '测量血压', icon: '❤️', time: '09:00' },
      { title: '去医院复诊', icon: '🏥', time: '10:00' },
      { title: '买东西', icon: '🛒', time: '10:00' },
      { title: '取快递', icon: '📦', time: '11:00' },
      { title: '给子女打电话', icon: '📞', time: '19:00' },
      { title: '锻炼身体', icon: '🏃', time: '07:00' },
      { title: '洗澡', icon: '🛁', time: '20:00' }
    ]
  },
  onLoad(options) {
    const now = new Date()
    const dateStr = now.toISOString().split('T')[0]
    this.setData({
      'memo.reminder_date': dateStr,
      displayDate: this.formatDisplayDate(dateStr)
    })
  },
  formatDisplayDate(dateStr) {
    if (!dateStr) return '选择日期'
    const date = new Date(dateStr)
    const today = new Date()
    const tomorrow = new Date(today)
    tomorrow.setDate(tomorrow.getDate() + 1)
    
    if (date.toDateString() === today.toDateString()) return '今天'
    if (date.toDateString() === tomorrow.toDateString()) return '明天'
    
    const month = date.getMonth() + 1
    const day = date.getDate()
    return `${month}月${day}日`
  },
  changeDate(e) {
    const date = e.detail.value
    this.setData({
      'memo.reminder_date': date,
      displayDate: this.formatDisplayDate(date)
    })
  },
  changeTime(e) {
    this.setData({ 'memo.reminder_time': e.detail.value })
  },
  selectTemplate(e) {
    const { title, time } = e.currentTarget.dataset
    this.setData({
      'memo.title': title,
      'memo.reminder_time': time
    })
  },
  onTitleInput(e) {
    this.setData({ 'memo.title': e.detail.value })
  },
  save() {
    if (!this.data.memo.reminder_date) {
      wx.showToast({ title: '请选择日期', icon: 'none' })
      return
    }
    if (!this.data.memo.title.trim()) {
      wx.showToast({ title: '请输入标题', icon: 'none' })
      return
    }
    
    // 保存到本地存储
    const memos = wx.getStorageSync('memos') || []
    memos.push({
      id: Date.now(),
      ...this.data.memo
    })
    wx.setStorageSync('memos', memos)
    
    wx.showToast({ title: '保存成功', icon: 'success' })
    setTimeout(() => {
      wx.navigateBack()
    }, 1000)
  },
  cancel() {
    wx.navigateBack()
  }
})
