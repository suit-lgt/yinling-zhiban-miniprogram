Page({
  data: {
    weekDays: ['日', '一', '二', '三', '四', '五', '六'],
    currentYear: new Date().getFullYear(),
    currentMonth: new Date().getMonth(),
    currentDay: new Date().getDate(),
    calendarDays: [],
    selectedDate: '',
    selectedMemos: [],
    formatSelectedDate: '',
    allMemos: []
  },
  onLoad() {
    this.loadMemos()
    this.generateCalendar()
    const today = new Date()
    const dateStr = this.formatDate(today.getFullYear(), today.getMonth(), today.getDate())
    this.selectDate({ day: today.getDate(), date: dateStr })
  },
  onShow() {
    this.loadMemos()
    this.generateCalendar()
  },
  loadMemos() {
    const memos = wx.getStorageSync('memos') || []
    this.setData({ allMemos: memos })
  },
  formatDate(year, month, day) {
    return `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`
  },
  generateCalendar() {
    const { currentYear, currentMonth, currentDay } = this.data
    const firstDay = new Date(currentYear, currentMonth, 1).getDay()
    const daysInMonth = new Date(currentYear, currentMonth + 1, 0).getDate()
    const today = new Date()
    
    const calendarDays = []
    
    for (let i = 0; i < firstDay; i++) {
      calendarDays.push({ day: '' })
    }
    
    for (let i = 1; i <= daysInMonth; i++) {
      const dateStr = this.formatDate(currentYear, currentMonth, i)
      const hasMemo = this.data.allMemos.some(m => m.reminder_date === dateStr)
      
      calendarDays.push({
        day: i,
        date: dateStr,
        isToday: i === today.getDate() && currentMonth === today.getMonth() && currentYear === today.getFullYear(),
        isSelected: dateStr === this.data.selectedDate,
        hasMemo
      })
    }
    
    this.setData({ calendarDays })
  },
  prevMonth() {
    let { currentMonth, currentYear } = this.data
    if (currentMonth === 0) {
      currentMonth = 11
      currentYear--
    } else {
      currentMonth--
    }
    this.setData({ currentMonth, currentYear }, () => {
      this.generateCalendar()
    })
  },
  nextMonth() {
    let { currentMonth, currentYear } = this.data
    if (currentMonth === 11) {
      currentMonth = 0
      currentYear++
    } else {
      currentMonth++
    }
    this.setData({ currentMonth, currentYear }, () => {
      this.generateCalendar()
    })
  },
  selectDate(e) {
    const { day, date } = e.currentTarget.dataset
    if (!day || !date) return
    
    const weekDays = ['星期日', '星期一', '星期二', '星期三', '星期四', '星期五', '星期六']
    const d = new Date(date)
    const month = d.getMonth() + 1
    const dayNum = d.getDate()
    const weekDay = weekDays[d.getDay()]
    
    const selectedMemos = this.data.allMemos
      .filter(m => m.reminder_date === date)
      .map(m => ({
        ...m,
        icon: this.getCategoryIcon(m.title)
      }))
    
    this.setData({
      selectedDate: date,
      formatSelectedDate: `${month}月${dayNum}日 ${weekDay}`,
      selectedMemos
    })
    
    this.generateCalendar()
  },
  getCategoryIcon(title) {
    if (title.includes('药')) return '💊'
    if (title.includes('血压') || title.includes('健康')) return '❤️'
    if (title.includes('医院')) return '🏥'
    if (title.includes('买') || title.includes('东西')) return '🛒'
    if (title.includes('快递')) return '📦'
    if (title.includes('电话')) return '📞'
    if (title.includes('锻炼') || title.includes('运动')) return '🏃'
    if (title.includes('洗澡')) return '🛁'
    return '📝'
  },
  addMemo() {
    wx.navigateTo({ url: '/pages/tools/addmemo/addmemo' })
  },
  toggleComplete(e) {
    const id = e.currentTarget.dataset.id
    let memos = wx.getStorageSync('memos') || []
    memos = memos.map(m => {
      if (m.id === id) {
        return { ...m, completed: !m.completed }
      }
      return m
    })
    wx.setStorageSync('memos', memos)
    this.loadMemos()
    this.selectDate({ day: new Date(this.data.selectedDate).getDate(), date: this.data.selectedDate })
  },
  goBack() {
    wx.navigateBack()
  }
})
