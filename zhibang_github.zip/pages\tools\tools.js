Page({
  data: {
    currentStatus: 'all',
    statusTabs: [
      { id: 'all', name: '全部' },
      { id: 'completed', name: '已完成' },
      { id: 'pending', name: '未完成' }
    ],
    memos: [],
    stats: {
      total: 0,
      completed: 0,
      pending: 0,
      today: 0
    }
  },

  onLoad() {
    this.loadMemos()
    this.loadStats()
  },

  onShow() {
    this.loadMemos()
    this.loadStats()
  },

  loadMemos() {
    const memos = wx.getStorageSync('memos') || []
    this.setData({ memos })
  },

  loadStats() {
    const memos = wx.getStorageSync('memos') || []
    const completed = memos.filter(m => m.completed).length
    this.setData({
      stats: {
        total: memos.length,
        completed: completed,
        pending: memos.length - completed,
        today: 0
      }
    })
  },

  get filteredMemos() {
    const { memos, currentStatus } = this.data
    if (currentStatus === 'all') {
      return memos
    } else if (currentStatus === 'completed') {
      return memos.filter(m => m.completed)
    } else {
      return memos.filter(m => !m.completed)
    }
  },

  switchStatus(e) {
    const statusId = e.currentTarget.dataset.id
    this.setData({ currentStatus: statusId })
  },

  getStatusCount(statusId) {
    const { stats } = this.data
    if (statusId === 'all') return stats.total
    if (statusId === 'completed') return stats.completed
    if (statusId === 'pending') return stats.pending
    return 0
  },

  getCategoryIcon(category) {
    const icons = {
      health: '🏥',
      service: '🍱',
      social: '👥',
      daily: '🏠'
    }
    return icons[category] || '📝'
  },

  getEmptyText() {
    const { currentStatus } = this.data
    if (currentStatus === 'completed') return '暂无已完成的事项'
    if (currentStatus === 'pending') return '暂无未完成的事项'
    return '暂无备忘录'
  },

  formatDateTime(memo) {
    const parts = []
    if (memo.reminder_date) {
      parts.push(memo.reminder_date)
    }
    if (memo.reminder_time) {
      parts.push(memo.reminder_time)
    }
    return parts.join(' ')
  },

  addMemo() {
    wx.navigateTo({
      url: '/pages/tools/addmemo/addmemo'
    })
  },

  editMemo(e) {
    const id = e.currentTarget.dataset.id
    wx.navigateTo({
      url: '/pages/tools/addmemo/addmemo?id=' + id
    })
  },

  toggleComplete(e) {
    const { id, completed } = e.currentTarget.dataset
    const memos = this.data.memos.map(m => {
      if (m._id === id) {
        return { ...m, completed: !completed }
      }
      return m
    })
    this.setData({ memos })
    wx.setStorageSync('memos', memos)
    this.loadStats()
    wx.showToast({
      title: !completed ? '已完成' : '待办',
      icon: 'success'
    })
  }
})
