import Vue from 'vue'
import VueRouter from 'vue-router'

Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    name: 'Index',
    component: () => import('@/pages/index/index.vue')
  },
  {
    path: '/tools',
    name: 'Tools',
    component: () => import('@/pages/tools/tools.vue')
  },
  {
    path: '/tools/addmemo',
    name: 'AddMemo',
    component: () => import('@/pages/tools/addmemo/addmemo.vue')
  },
  {
    path: '/tools/calendar',
    name: 'Calendar',
    component: () => import('@/pages/tools/calendar/calendar.vue')
  },
  {
    path: '/health',
    name: 'Health',
    component: () => import('@/pages/health/health.vue')
  },
  {
    path: '/health/record',
    name: 'HealthRecord',
    component: () => import('@/pages/health/record/record.vue')
  },
  {
    path: '/health/add-data',
    name: 'AddData',
    component: () => import('@/pages/health/add-data/add-data.vue')
  },
  {
    path: '/health/medicine',
    name: 'Medicine',
    component: () => import('@/pages/health/medicine/medicine.vue')
  },
  {
    path: '/health/reminder',
    name: 'Reminder',
    component: () => import('@/pages/health/reminder/reminder.vue')
  },
  {
    path: '/health/emergency-contact',
    name: 'EmergencyContact',
    component: () => import('@/pages/health/emergency-contact/emergency-contact.vue')
  },
  {
    path: '/health/remote',
    name: 'Remote',
    component: () => import('@/pages/health/remote/remote.vue')
  },
  {
    path: '/health/fall',
    name: 'Fall',
    component: () => import('@/pages/health/fall/fall.vue')
  },
  {
    path: '/health/fraud',
    name: 'Fraud',
    component: () => import('@/pages/health/fraud/fraud.vue')
  },
  {
    path: '/health/express',
    name: 'Express',
    component: () => import('@/pages/health/express/express.vue')
  },
  {
    path: '/health/payment',
    name: 'Payment',
    component: () => import('@/pages/health/payment/payment.vue')
  },
  {
    path: '/health/hospital',
    name: 'Hospital',
    component: () => import('@/pages/health/hospital/hospital.vue')
  },
  {
    path: '/health/taxi',
    name: 'Taxi',
    component: () => import('@/pages/health/taxi/taxi.vue')
  },

  {
    path: '/mine',
    name: 'Mine',
    component: () => import('@/pages/mine/mine.vue')
  },
  {
    path: '/mine/profile',
    name: 'Profile',
    component: () => import('@/pages/mine/profile/profile.vue')
  },
  {
    path: '/mine/about',
    name: 'About',
    component: () => import('@/pages/mine/about/about.vue')
  },
  {
    path: '/mine/feedback',
    name: 'Feedback',
    component: () => import('@/pages/mine/feedback/feedback.vue')
  },
  {
    path: '/mine/ai-settings',
    name: 'AISettings',
    component: () => import('@/pages/mine/ai-settings/ai-settings.vue')
  },
  {
    path: '/guide',
    name: 'Guide',
    component: () => import('@/pages/guide/guide.vue')
  },
  {
    path: '/qa',
    name: 'QA',
    component: () => import('@/pages/qa/qa-chat.vue')
  },
  {
    path: '/detail',
    name: 'Detail',
    component: () => import('@/pages/detail/detail.vue')
  },
  {
    path: '/cate',
    name: 'Cate',
    component: () => import('@/pages/cate/cate.vue')
  }
]

const router = new VueRouter({
  mode: 'hash',
  routes
})

export default router
