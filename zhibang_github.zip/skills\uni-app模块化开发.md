# uni-app 模块化开发指南

本文档为银龄智伴APP的模块化开发规范，基于uni-app (Vue 2)框架。

## 一、项目结构

### 1.1 目录规范
```
项目根目录/
├── src/                      # 源码目录
│   ├── main.js              # 入口文件
│   ├── App.vue              # 根组件
│   ├── manifest.json        # 应用配置
│   ├── pages.json           # 页面路由配置
│   ├── uni.scss             # 全局样式变量
│   ├── common/              # 公共模块
│   │   ├── components/      # 公共组件（yl-前缀）
│   │   ├── css/             # 全局CSS
│   │   └── utils/           # 工具函数
│   │       ├── theme.js    # 主题管理
│   │       ├── storage.js  # 存储工具
│   │       └── rules/      # 全局规则 ⭐
│   ├── api/                 # API接口层
│   │   ├── index.js        # 主API
│   │   └── speech.js       # 语音API
│   ├── pages/              # 主包页面（19个）
│   ├── pagesA/             # 分包 - 登录注册
│   ├── pagesB/             # 分包 - 使用指南
│   └── static/             # 静态资源
├── package.json
└── vue.config.js
```

### 1.2 模块划分
| 模块 | 目录 | 说明 |
|------|------|------|
| 首页 | pages/index/ | 欢迎、天气、AI助手、备忘录 |
| 健康 | pages/health/ | 健康主页面及12个子功能 |
| 问答 | pages/qa/ | 智能问答 |
| 备忘录 | pages/tools/ | 备忘录管理 |
| 我的 | pages/mine/ | 个人中心 |
| 登录注册 | pagesA/login/ | 用户认证 |
| 使用指南 | pagesB/cate/ | 新手引导 |

---

## 二、分包机制

### 2.1 分包原则
- 主包大小控制在 **2MB** 以内
- 登录注册、使用指南等低频功能放入分包
- 分包按需加载，提升首屏速度

### 2.2 pages.json 配置
```json
{
  "pages": [
    {
      "path": "pages/index/index",
      "style": { "navigationBarTitleText": "银龄智伴" }
    }
  ],
  "subPackages": [
    {
      "root": "pagesA",
      "pages": [
        { "path": "login/login", "style": { "navigationBarTitleText": "登录" } },
        { "path": "login/register", "style": { "navigationBarTitleText": "注册" } }
      ]
    },
    {
      "root": "pagesB",
      "pages": [
        { "path": "cate/use/use1", "style": { "navigationBarTitleText": "使用指南1" } }
      ]
    }
  ],
  "tabBar": {
    "color": "#999999",
    "selectedColor": "#15559E",
    "list": [
      { "pagePath": "pages/index/index", "text": "首页", "iconPath": "..." },
      { "pagePath": "pages/health/health", "text": "健康", "iconPath": "..." }
    ]
  }
}
```

---

## 三、路由规范

### 3.1 跳转方式
```javascript
// 页面跳转（保留历史）
uni.navigateTo({
  url: '/pages/health/medicine/medicine'
})

// 页面跳转（替换当前页）
uni.redirectTo({
  url: '/pages/login/login'
})

// 返回上一页
uni.navigateBack()

// 跳转TabBar页
uni.switchTab({
  url: '/pages/index/index'
})

// 打开分包页面
uni.navigateTo({
  url: '/pagesA/login/login'
})
```

### 3.2 路由规范
- ✅ 统一在 pages.json 管理路由
- ✅ 使用路径别名（如 @/pages/health）
- ❌ 禁止硬编码完整路径
- ❌ 禁止使用相对路径跳转

---

## 四、组件规范

### 4.1 公共组件结构
```
src/common/components/
├── yl-button.vue      # 按钮组件
├── yl-card.vue        # 卡片组件
├── yl-input.vue       # 输入框组件
├── yl-modal.vue       # 模态框组件
└── yl-list.vue        # 列表组件
```

### 4.2 组件开发规范
```vue
<template>
  <view class="yl-button" :class="[`yl-button--${type}`, { 'yl-button--disabled': disabled }]">
    <slot></slot>
  </view>
</template>

<script>
export default {
  name: 'yl-button',
  props: {
    type: { type: String, default: 'primary' },
    disabled: { type: Boolean, default: false }
  }
}
</script>

<style lang="scss">
.yl-button {
  // 样式实现
}
</style>
```

### 4.3 组件使用规范
- 公共组件以 `yl-` 前缀命名
- 组件内部样式使用 scoped
- 组件Props必须定义类型和默认值
- 事件发射使用 this.$emit()

---

## 五、状态管理

### 5.1 uni.$emit 事件通信
```javascript
// 发送事件
uni.$emit('updateTheme', { mode: 'dark' })

// 监听事件
uni.$on('updateTheme', (data) => {
  console.log('主题更新:', data.mode)
})

// 移除监听
uni.$off('updateTheme')
```

### 5.2 本地存储封装
```javascript
// src/common/utils/storage.js
const STORAGE_KEYS = {
  USER: 'user',
  MEMO_LIST: 'memoList',
  THEME: 'app_theme',
  FONT_SIZE: 'app_font_size',
  IS_DARK: 'isDarkMode'
}

export const storage = {
  get(key) {
    const value = uni.getStorageSync(key)
    return value ? JSON.parse(value) : null
  },
  set(key, value) {
    uni.setStorageSync(key, JSON.stringify(value))
  },
  remove(key) {
    uni.removeStorageSync(key)
  }
}
```

### 5.3 状态管理规范
- ✅ 使用 uni.$emit 进行跨页面通信
- ✅ 页面级状态在 onLoad 获取，onUnload 清理
- ✅ 持久化数据使用 storage.js 封装
- ❌ 禁止跨模块直接引用组件
- ❌ 禁止使用 Vuex（uni-app场景不需要）

---

## 六、API 规范

### 6.1 API 目录结构
```
src/api/
├── index.js        # 主API入口，导出所有接口
├── http.js         # 请求封装（拦截器、错误处理）
├── weather.js      # 天气API
├── user.js         # 用户API
└── speech.js       # 语音API
```

### 6.2 请求封装
```javascript
// src/api/http.js
const baseURL = 'https://api.example.com'

const request = (options) => {
  return new Promise((resolve, reject) => {
    uni.request({
      url: baseURL + options.url,
      method: options.method || 'GET',
      data: options.data || {},
      header: {
        'Content-Type': 'application/json',
        ...options.header
      },
      success: (res) => {
        if (res.statusCode === 200) {
          resolve(res.data)
        } else {
          reject(res)
        }
      },
      fail: (err) => {
        reject(err)
      }
    })
  })
}

export default request
```

### 6.3 API 调用规范
```javascript
// src/api/user.js
import request from './http'

export const userAPI = {
  login(data) {
    return request({ url: '/user/login', method: 'POST', data })
  },
  getUserInfo(id) {
    return request({ url: `/user/${id}` })
  }
}
```

---

## 七、样式规范

### 7.1 uni.scss 全局变量
```scss
// src/uni.scss

// 颜色变量
$primary: #3792ED;
$primary-dark: #15559E;
$success: #27AE60;
$warning: #F39C12;
$danger: #E74C3C;

// 文字颜色
$text-main: #333333;
$text-secondary: #666666;
$text-placeholder: #999999;

// 背景色
$bg-color: #FFFFFF;
$bg-gray: #F5F5F5;

// 间距
$spacing-sm: 8px;
$spacing-md: 16px;
$spacing-lg: 24px;

// 圆角
$radius-sm: 4px;
$radius-md: 8px;
$radius-lg: 12px;

// 按钮高度
$btn-height: 56px;
$btn-min-height: 48px;
```

### 7.2 样式使用规范
- ✅ 使用 uni.scss 变量，禁止硬编码颜色
- ✅ 使用 rpx 进行尺寸适配
- ✅ 公共样式提取到 common/css/
- ❌ 避免使用 !important

---

## 八、模块解耦规范

### 8.1 模块独立性原则
每个功能模块（如健康模块）应保持独立：

```
pages/health/          # 健康模块
├── health.vue         # 模块主页面
├── medicine/          # 用药提醒子功能
├── record/            # 健康记录子功能
└── components/       # 模块私有组件
```

### 8.2 模块间通信
- 使用 uni.$emit 进行事件通信
- 避免直接 import 其他模块的组件
- 通过统一的接口（rules/module-interface.js）定义交互

### 8.3 解耦检查清单
- [ ] 模块内部组件是否只在本模块使用？
- [ ] 跨模块调用是否通过事件通信？
- [ ] 是否避免了硬编码路径引用？
- [ ] 修改一个模块会影响其他模块吗？

---

## 九、性能优化

### 9.1 加载优化
- 分包加载，减少主包体积
- 图片使用懒加载
- 接口数据缓存

### 9.2 渲染优化
- 避免在 template 中使用复杂表达式
- 列表渲染使用 key
- 合理使用 v-show 和 v-if

### 9.3 交互优化
- 按钮点击添加节流
- 长列表使用 scroll-view
- 避免频繁调用 setData

---

## 十、版本管理

| 版本 | 日期 | 更新内容 |
|------|------|----------|
| 1.0 | 2024-01 | 初始版本 |

---

*本文档为银龄智伴APP开发团队共用规范*
