const http = {
  get(url, params) {
    console.log('GET:', url, params)
    return Promise.resolve({})
  },
  post(url, data) {
    console.log('POST:', url, data)
    return Promise.resolve({ success: true })
  },
  put(url, data) {
    console.log('PUT:', url, data)
    return Promise.resolve({ success: true })
  },
  delete(url) {
    console.log('DELETE:', url)
    return Promise.resolve({ success: true })
  }
}

export default http
