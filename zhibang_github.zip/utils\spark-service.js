/**
 * 讯飞星火认知大模型服务
 * 用于AI智能问答
 */

const config = require('../config/speech-config')

class SparkService {
  constructor() {
    this.chatHistory = []
  }
  
  /**
   * 生成鉴权URL
   */
  generateAuthUrl() {
    const { appId, apiKey, apiSecret, host, uri } = config.xfyun.spark
    const hostUrl = `wss://${host}${uri}`
    
    const crypto = require('crypto')
    const url = new URL(hostUrl)
    const date = new Date().toUTCString()
    
    // 签名原始字符串
    const signatureOrigin = `host: ${url.host}\ndate: ${date}\nGET ${url.pathname} HTTP/1.1`
    
    // HMAC-SHA256签名
    const signature = crypto
      .createHmac('sha256', apiSecret)
      .update(signatureOrigin)
      .digest('base64')
    
    // 构建authorization
    const authOrigin = `api_key="${apiKey}", algorithm="hmac-sha256", headers="host date request-line", signature="${signature}"`
    const authorization = Buffer.from(authOrigin).toString('base64')
    
    return `${hostUrl}?authorization=${encodeURIComponent(authorization)}&date=${encodeURIComponent(date)}&host=${url.host}`
  }
  
  /**
   * AI问答
   * @param {string} question 用户问题
   * @param {function} onMessage 收到消息的回调
   */
  async chat(question, onMessage) {
    const { appId, model, modelDomain } = config.xfyun.spark
    const domain = modelDomain[model] || 'lite'
    
    return new Promise((resolve, reject) => {
      // 构建请求参数
      const params = {
        header: {
          app_id: appId,
          uid: wx.getStorageSync('userId') || 'anonymous'
        },
        parameter: {
          chat: {
            domain: domain,
            temperature: 0.5,
            max_tokens: 2048
          }
        },
        payload: {
          message: {
            text: [
              {
                role: 'system',
                content: '你是一个专为老年人设计的智能助手，名字叫"银龄智伴"。你的回答要简洁、温暖、易懂，避免使用复杂的专业术语。你可以帮助老年人查询天气、记录健康数据、提醒用药、叫车出行等。'
              },
              ...this.chatHistory,
              {
                role: 'user',
                content: question
              }
            ]
          }
        }
      }
      
      // 调用云函数
      wx.cloud.callFunction({
        name: 'sparkChat',
        data: params
      }).then(res => {
        if (res.result && res.result.code === 0) {
          const answer = res.result.data
          
          // 保存对话历史
          this.chatHistory.push(
            { role: 'user', content: question },
            { role: 'assistant', content: answer }
          )
          
          // 限制历史记录长度
          if (this.chatHistory.length > 10) {
            this.chatHistory = this.chatHistory.slice(-10)
          }
          
          resolve({
            success: true,
            answer: answer
          })
        } else {
          reject(new Error(res.result?.message || '请求失败'))
        }
      }).catch(err => {
        console.error('星火API调用失败', err)
        reject(err)
      })
    })
  }
  
  /**
   * 清除对话历史
   */
  clearHistory() {
    this.chatHistory = []
  }
  
  /**
   * 处理老年人常见问题的快捷回复
   */
  getQuickReply(text) {
    const patterns = [
      {
        keywords: ['天气', '温度', '下雨'],
        type: 'weather'
      },
      {
        keywords: ['血压', '血糖', '心率', '健康'],
        type: 'health'
      },
      {
        keywords: ['吃药', '药', '提醒'],
        type: 'medicine'
      },
      {
        keywords: ['打车', '出租车', '叫车'],
        type: 'taxi'
      },
      {
        keywords: ['医院', '挂号', '看病'],
        type: 'hospital'
      },
      {
        keywords: ['紧急', '救命', '120'],
        type: 'emergency'
      }
    ]
    
    for (const pattern of patterns) {
      if (pattern.keywords.some(kw => text.includes(kw))) {
        return pattern.type
      }
    }
    
    return null
  }
}

// 导出单例
module.exports = new SparkService()
