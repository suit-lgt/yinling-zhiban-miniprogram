/**
 * 语音服务
 * 使用百度语音识别 API 实现语音识别
 * 适用于国际赛事演示，响应快速、交互效果好
 */

class SpeechService {
  constructor() {
    this.recorderManager = wx.getRecorderManager()
    this.isRecording = false
    this.recordTempFilePath = ''
    this.onRecordEndCallback = null
    this.recordTimer = null
    this.recordDuration = 0
    
    this.initRecorder()
  }
  
  /**
   * 初始化录音管理器
   */
  initRecorder() {
    this.recorderManager.onStart(() => {
      console.log('录音开始')
      this.isRecording = true
      this.recordDuration = 0
      
      // 启动计时器
      this.recordTimer = setInterval(() => {
        this.recordDuration++
      }, 1000)
    })
    
    this.recorderManager.onStop(async (res) => {
      console.log('录音结束', res)
      this.isRecording = false
      this.recordTempFilePath = res.tempFilePath
      
      // 清除计时器
      if (this.recordTimer) {
        clearInterval(this.recordTimer)
        this.recordTimer = null
      }
      
      // 调用语音识别
      if (this.onRecordEndCallback) {
        this.onRecordEndCallback(null, '识别中...')
      }
      
      try {
        const result = await this.recognize(res.tempFilePath)
        if (this.onRecordEndCallback) {
          this.onRecordEndCallback(result.text, result.error)
        }
      } catch (error) {
        if (this.onRecordEndCallback) {
          this.onRecordEndCallback(null, error.message)
        }
      }
    })
    
    this.recorderManager.onError((err) => {
      console.error('录音错误', err)
      this.isRecording = false
      
      if (this.recordTimer) {
        clearInterval(this.recordTimer)
        this.recordTimer = null
      }
      
      if (this.onRecordEndCallback) {
        this.onRecordEndCallback(null, err.message)
      }
    })
  }
  
  /**
   * 开始录音
   */
  startRecord() {
    if (this.isRecording) {
      console.log('已经在录音中')
      return
    }
    
    // 清除之前的计时器
    if (this.recordTimer) {
      clearInterval(this.recordTimer)
      this.recordTimer = null
    }
    
    console.log('开始录音')
    const recorderConfig = {
      duration: 60000,
      sampleRate: 16000,
      numberOfChannels: 1,
      encodeBitRate: 96000,
      format: 'pcm',
    }
    this.recorderManager.start(recorderConfig)
  }
  
  /**
   * 停止录音
   */
  stopRecord() {
    console.log('停止录音')
    if (this.isRecording) {
      this.recorderManager.stop()
    }
  }
  
  /**
   * 设置录音结束回调
   * @param {Function} callback - 回调函数(text, error)
   */
  onRecordEnd(callback) {
    this.onRecordEndCallback = callback
  }
  
  /**
   * 语音识别 - 使用百度语音云函数
   * @param {String} filePath - 录音文件路径
   */
  async recognize(filePath) {
    try {
      // 读取文件为 base64
      const base64Audio = await this.readFile(filePath)
      
      console.log('发送语音识别请求，音频长度:', base64Audio.length)
      
      // 调用云函数进行语音识别
      const { result } = await wx.cloud.callFunction({
        name: 'baiduSpeech',
        data: {
          audioBase64: base64Audio
        }
      })
      
      console.log('语音识别结果:', result)
      return result
    } catch (error) {
      console.error('语音识别失败', error)
      return {
        success: false,
        error: error.message
      }
    }
  }
  
  /**
   * 读取文件内容
   */
  readFile(filePath) {
    return new Promise((resolve, reject) => {
      // 使用 wx.getFileSystemManager 读取文件为 ArrayBuffer
      const fs = wx.getFileSystemManager()
      fs.readFile({
        filePath: filePath,
        encoding: 'base64',
        success: (res) => {
          // 返回 base64 字符串
          resolve(res.data)
        },
        fail: (err) => {
          console.error('读取文件失败:', err)
          reject(err)
        }
      })
    })
  }
  
  /**
   * 模拟语音识别（用于测试）
   */
  mockRecognize() {
    const mockTexts = [
      '今天天气怎么样',
      '帮我记录血压',
      '我要打车去医院',
      '提醒我下午吃药',
      '播放音乐',
      '给子女打电话'
    ]
    const randomText = mockTexts[Math.floor(Math.random() * mockTexts.length)]
    
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve({
          success: true,
          text: randomText,
          mock: true
        })
      }, 1000)
    })
  }
  
  /**
   * 检查语音服务是否可用
   */
  isAvailable() {
    return true // 百度语音方案始终可用
  }
  
  /**
   * 获取录音时长
   */
  getRecordDuration() {
    return this.recordDuration
  }
}

// 导出单例
module.exports = new SpeechService()
