const path = require('path')

module.exports = {
  transpileDependencies: ['@dcloudio/uni-ui'],
  chainWebpack: config => {
    config.module
      .rule('svg')
      .exclude.add(path.resolve(__dirname, 'src/static'))
      .end()
  },
  css: {
    loaderOptions: {
      scss: {
        additionalData: `@import "./src/uni.scss";`
      }
    }
  },
  devServer: {
    port: 8080,
    open: true,
    proxy: {
      '/api': {
        target: 'https://api.example.com',
        changeOrigin: true,
        pathRewrite: {
          '^/api': ''
        }
      }
    }
  }
}
